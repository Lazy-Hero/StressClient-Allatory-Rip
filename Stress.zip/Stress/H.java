import net.minecraftforge.fml.common.Mod$EventHandler;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;
import net.minecraftforge.fml.common.Mod;

// 
// Decompiled by Procyon v0.5.36
// 

@Mod(modid = "stressclient", version = "b1")
public class H
{
    @Mod$EventHandler
    public void ALLATORIxDEMO(final FMLInitializationEvent a) {
        (l.p.H.g = new l.p.H()).b();
    }
}
