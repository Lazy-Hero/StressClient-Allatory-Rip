// 
// Decompiled by Procyon v0.5.36
// 

package l.p.l;

import java.util.Iterator;
import l.p.l.p.D;
import l.p.l.p.d;
import l.p.l.p.f;
import l.p.l.p.G;
import l.p.l.l.j;
import l.p.l.p.m;
import l.p.l.p.I;
import l.p.l.p.l;
import l.p.l.t.F;
import l.p.l.p.C;
import l.p.l.d.g;
import l.p.l.p.e;
import l.p.l.d.A;
import l.p.l.t.c;
import l.p.l.p.k;
import l.p.l.t.a;
import java.util.Comparator;
import java.util.Collections;
import java.util.List;
import java.util.ArrayList;

public class i
{
    public ArrayList<H> ALLATORIxDEMO;
    
    public void ALLATORIxDEMO(final List<H> a) {
        Collections.sort((List<Object>)a, (Comparator<? super Object>)new L(this));
    }
    
    public ArrayList<H> ALLATORIxDEMO() {
        return this.ALLATORIxDEMO;
    }
    
    public i() {
        (this.ALLATORIxDEMO = new ArrayList<H>()).clear();
        this.ALLATORIxDEMO.add(new a());
        this.ALLATORIxDEMO.add(new l.p.l.l.i());
        this.ALLATORIxDEMO.add(new l.p.l.p.i());
        this.ALLATORIxDEMO.add(new k());
        this.ALLATORIxDEMO.add(new c());
        this.ALLATORIxDEMO.add(new A());
        this.ALLATORIxDEMO.add(new e());
        this.ALLATORIxDEMO.add(new g());
        this.ALLATORIxDEMO.add(new l.p.l.p.g());
        this.ALLATORIxDEMO.add(new l.p.l.t.g());
        this.ALLATORIxDEMO.add(new l.p.l.d.i());
        this.ALLATORIxDEMO.add(new C());
        this.ALLATORIxDEMO.add(new l.p.l.l.c());
        this.ALLATORIxDEMO.add(new l.p.l.t.H());
        this.ALLATORIxDEMO.add(new F());
        this.ALLATORIxDEMO.add(new l());
        this.ALLATORIxDEMO.add(new I());
        this.ALLATORIxDEMO.add(new l.p.l.p.F());
        this.ALLATORIxDEMO.add(new m());
        this.ALLATORIxDEMO.add(new l.p.l.p.L());
        this.ALLATORIxDEMO.add(new l.p.l.t.e());
        this.ALLATORIxDEMO.add(new j());
        this.ALLATORIxDEMO.add(new l.p.l.d.c());
        this.ALLATORIxDEMO.add(new l.p.l.p.a());
        this.ALLATORIxDEMO.add(new G());
        this.ALLATORIxDEMO.add(new f());
        this.ALLATORIxDEMO.add(new l.p.l.d.I());
        this.ALLATORIxDEMO.add(new l.p.l.t.A());
        this.ALLATORIxDEMO.add(new d());
        this.ALLATORIxDEMO.add(new l.p.l.d.H());
        this.ALLATORIxDEMO.add(new l.p.l.p.j());
        this.ALLATORIxDEMO.add(new D());
        this.ALLATORIxDEMO.add(new l.p.l.d.a());
        this.ALLATORIxDEMO.add(new l.p.l.l.I());
        this.ALLATORIxDEMO.add(new l.p.l.p.c());
        this.ALLATORIxDEMO.add(new l.p.l.t.d());
        this.ALLATORIxDEMO.add(new l.p.l.p.A());
        this.ALLATORIxDEMO.add(new l.p.l.l.F());
        this.ALLATORIxDEMO.add(new l.p.l.l.a());
        this.ALLATORIxDEMO.add(new l.p.l.l.d());
        this.ALLATORIxDEMO(this.ALLATORIxDEMO);
    }
    
    public ArrayList<H> ALLATORIxDEMO(final l.p.l.I a) {
        final ArrayList<H> list = new ArrayList<H>();
        final Iterator<H> iterator = this.ALLATORIxDEMO.iterator();
    Label_0016:
        while (true) {
            Iterator<H> iterator2 = iterator;
            while (iterator2.hasNext()) {
                final H e;
                if ((e = iterator.next()).ALLATORIxDEMO() != a) {
                    continue Label_0016;
                }
                iterator2 = iterator;
                list.add(e);
            }
            break;
        }
        return list;
    }
    
    public H ALLATORIxDEMO(final String a) {
        final Iterator<H> iterator = this.ALLATORIxDEMO.iterator();
        while (iterator.hasNext()) {
            final H h;
            if ((h = iterator.next()).ALLATORIxDEMO().equalsIgnoreCase(a)) {
                return h;
            }
        }
        return null;
    }
}
