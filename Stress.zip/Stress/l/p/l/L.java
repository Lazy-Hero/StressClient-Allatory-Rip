// 
// Decompiled by Procyon v0.5.36
// 

package l.p.l;

import net.minecraft.client.Minecraft;
import java.util.Comparator;

class L implements Comparator<H>
{
    final /* synthetic */ i ALLATORIxDEMO;
    
    L(final i a) {
        this.ALLATORIxDEMO = a;
    }
    
    public int ALLATORIxDEMO(H a, H a) {
        a = (H)Minecraft.func_71410_x().field_71466_p.func_78256_a(a.ALLATORIxDEMO());
        a = (H)Minecraft.func_71410_x().field_71466_p.func_78256_a(a.ALLATORIxDEMO());
        if (a > a) {
            return -1;
        }
        if (a < a) {
            return 1;
        }
        return 0;
    }
}
