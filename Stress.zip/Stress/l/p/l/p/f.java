// 
// Decompiled by Procyon v0.5.36
// 

package l.p.l.p;

import l.p.p.i;
import l.p.l.I;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import l.p.t.B;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.GlStateManager;
import org.lwjgl.opengl.GL11;
import net.minecraft.entity.Entity;
import net.minecraftforge.client.event.RenderWorldLastEvent;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.entity.item.EntityArmorStand;
import java.util.Iterator;
import net.minecraft.entity.EntityLivingBase;
import java.util.ArrayList;
import net.minecraft.entity.player.EntityPlayer;
import java.util.List;
import l.p.l.H;

public class f extends H
{
    public List<EntityPlayer> ALLATORIxDEMO() {
        final ArrayList<EntityPlayer> list = new ArrayList<EntityPlayer>();
        final Iterator<EntityPlayer> iterator2;
        Iterator<EntityPlayer> iterator = iterator2 = f.ALLATORIxDEMO.field_71441_e.func_72910_y().iterator();
        while (iterator.hasNext()) {
            final EntityPlayer next;
            if (!((next = iterator2.next()) instanceof EntityPlayer)) {
                iterator = iterator2;
            }
            else {
                final EntityPlayer a = next;
                if (!this.ALLATORIxDEMO((EntityLivingBase)a)) {
                    iterator = iterator2;
                }
                else {
                    list.add(a);
                    iterator = iterator2;
                }
            }
        }
        return list;
    }
    
    public boolean ALLATORIxDEMO(final EntityLivingBase a) {
        return !(a instanceof EntityArmorStand) && !(a instanceof EntityPlayerSP) && a != l.p.t.H.ALLATORIxDEMO.ALLATORIxDEMO();
    }
    
    @SubscribeEvent
    @Override
    public void ALLATORIxDEMO(RenderWorldLastEvent a) {
        if (this.b()) {
            return;
        }
        a = (RenderWorldLastEvent)f.ALLATORIxDEMO.field_71441_e.func_72910_y().iterator();
    Label_0025:
        while (true) {
            RenderWorldLastEvent renderWorldLastEvent = a;
            while (((Iterator)renderWorldLastEvent).hasNext()) {
                final Entity entity;
                if (!((entity = ((Iterator<Entity>)a).next()) instanceof EntityPlayer) || entity == f.ALLATORIxDEMO.field_71439_g) {
                    continue Label_0025;
                }
                l.p.H.g.c.ALLATORIxDEMO(this, "Red").B();
                l.p.H.g.c.ALLATORIxDEMO(this, "Green").B();
                l.p.H.g.c.ALLATORIxDEMO(this, "Blue").B();
                l.p.H.g.c.ALLATORIxDEMO(this, "Alpha").B();
                GL11.glPushMatrix();
                GL11.glLineWidth(2.0f);
                GlStateManager.func_179090_x();
                GlStateManager.func_179097_i();
                GL11.glTranslated(entity.field_70165_t - Minecraft.func_71410_x().func_175598_ae().field_78730_l, entity.field_70163_u - Minecraft.func_71410_x().func_175598_ae().field_78731_m, entity.field_70161_v - Minecraft.func_71410_x().func_175598_ae().field_78728_n);
                GL11.glColor4f((float)l.p.H.g.c.ALLATORIxDEMO(this, "Red").B(), (float)l.p.H.g.c.ALLATORIxDEMO(this, "Green").B(), (float)l.p.H.g.c.ALLATORIxDEMO(this, "Blue").B(), (float)l.p.H.g.c.ALLATORIxDEMO(this, "Alpha").B());
                final double n = 1.8;
                final double n2 = 0.3;
                final double n3 = 0.0;
                final double n4 = -0.3;
                l.p.t.B.b(new AxisAlignedBB(n2, n, n2, n4, n3, n4));
                GlStateManager.func_179098_w();
                GlStateManager.func_179126_j();
                GlStateManager.func_179121_F();
                GlStateManager.func_179117_G();
                renderWorldLastEvent = a;
            }
            break;
        }
    }
    
    public f() {
        super("BoxESP", "", I.c);
        l.p.H.g.c.ALLATORIxDEMO(new i("Red", this, 0.1, 0.0, 1.0, false));
        l.p.H.g.c.ALLATORIxDEMO(new i("Green", this, 0.1, 0.0, 1.0, false));
        l.p.H.g.c.ALLATORIxDEMO(new i("Blue", this, 0.1, 0.0, 1.0, false));
        final l.p.p.H c = l.p.H.g.c;
        final String a = "Alpha";
        final double a2 = 0.0;
        final double n = 1.0;
        c.ALLATORIxDEMO(new i(a, this, n, a2, n, false));
    }
}
