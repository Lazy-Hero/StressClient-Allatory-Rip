// 
// Decompiled by Procyon v0.5.36
// 

package l.p.l.p;

import org.lwjgl.opengl.GL11;
import net.minecraft.util.math.AxisAlignedBB;

public class B
{
    public static void b(final AxisAlignedBB a) {
        GL11.glBegin(1);
        GL11.glVertex3d(a.field_72340_a, a.field_72337_e, a.field_72339_c);
        GL11.glVertex3d(a.field_72336_d, a.field_72337_e, a.field_72339_c);
        GL11.glVertex3d(a.field_72336_d, a.field_72337_e, a.field_72339_c);
        GL11.glVertex3d(a.field_72336_d, a.field_72337_e, a.field_72334_f);
        GL11.glVertex3d(a.field_72336_d, a.field_72337_e, a.field_72334_f);
        GL11.glVertex3d(a.field_72340_a, a.field_72337_e, a.field_72334_f);
        GL11.glVertex3d(a.field_72340_a, a.field_72337_e, a.field_72334_f);
        GL11.glVertex3d(a.field_72340_a, a.field_72337_e, a.field_72339_c);
        GL11.glVertex3d(a.field_72340_a, a.field_72338_b, a.field_72339_c);
        GL11.glVertex3d(a.field_72336_d, a.field_72338_b, a.field_72339_c);
        GL11.glVertex3d(a.field_72336_d, a.field_72338_b, a.field_72339_c);
        GL11.glVertex3d(a.field_72336_d, a.field_72338_b, a.field_72334_f);
        GL11.glVertex3d(a.field_72336_d, a.field_72338_b, a.field_72334_f);
        GL11.glVertex3d(a.field_72340_a, a.field_72338_b, a.field_72334_f);
        GL11.glVertex3d(a.field_72340_a, a.field_72338_b, a.field_72334_f);
        GL11.glVertex3d(a.field_72340_a, a.field_72338_b, a.field_72339_c);
        GL11.glVertex3d(a.field_72340_a, a.field_72338_b, a.field_72339_c);
        GL11.glVertex3d(a.field_72340_a, a.field_72337_e, a.field_72339_c);
        GL11.glVertex3d(a.field_72336_d, a.field_72338_b, a.field_72339_c);
        GL11.glVertex3d(a.field_72336_d, a.field_72337_e, a.field_72339_c);
        GL11.glVertex3d(a.field_72336_d, a.field_72338_b, a.field_72334_f);
        GL11.glVertex3d(a.field_72336_d, a.field_72337_e, a.field_72334_f);
        GL11.glVertex3d(a.field_72340_a, a.field_72338_b, a.field_72334_f);
        GL11.glVertex3d(a.field_72340_a, a.field_72337_e, a.field_72334_f);
        GL11.glEnd();
    }
    
    public static void ALLATORIxDEMO(final AxisAlignedBB a) {
        GL11.glBegin(7);
        GL11.glVertex3d(a.field_72340_a, a.field_72338_b, a.field_72339_c);
        GL11.glVertex3d(a.field_72340_a, a.field_72337_e, a.field_72339_c);
        GL11.glVertex3d(a.field_72336_d, a.field_72337_e, a.field_72339_c);
        GL11.glVertex3d(a.field_72336_d, a.field_72338_b, a.field_72339_c);
        GL11.glVertex3d(a.field_72336_d, a.field_72338_b, a.field_72339_c);
        GL11.glVertex3d(a.field_72336_d, a.field_72337_e, a.field_72339_c);
        GL11.glVertex3d(a.field_72336_d, a.field_72337_e, a.field_72334_f);
        GL11.glVertex3d(a.field_72336_d, a.field_72338_b, a.field_72334_f);
        GL11.glVertex3d(a.field_72340_a, a.field_72338_b, a.field_72334_f);
        GL11.glVertex3d(a.field_72336_d, a.field_72338_b, a.field_72334_f);
        GL11.glVertex3d(a.field_72336_d, a.field_72337_e, a.field_72334_f);
        GL11.glVertex3d(a.field_72340_a, a.field_72337_e, a.field_72334_f);
        GL11.glVertex3d(a.field_72340_a, a.field_72338_b, a.field_72339_c);
        GL11.glVertex3d(a.field_72340_a, a.field_72338_b, a.field_72334_f);
        GL11.glVertex3d(a.field_72340_a, a.field_72337_e, a.field_72334_f);
        GL11.glVertex3d(a.field_72340_a, a.field_72337_e, a.field_72339_c);
        GL11.glVertex3d(a.field_72340_a, a.field_72338_b, a.field_72339_c);
        GL11.glVertex3d(a.field_72336_d, a.field_72338_b, a.field_72339_c);
        GL11.glVertex3d(a.field_72336_d, a.field_72338_b, a.field_72334_f);
        GL11.glVertex3d(a.field_72340_a, a.field_72338_b, a.field_72334_f);
        GL11.glVertex3d(a.field_72340_a, a.field_72337_e, a.field_72339_c);
        GL11.glVertex3d(a.field_72340_a, a.field_72337_e, a.field_72334_f);
        GL11.glVertex3d(a.field_72336_d, a.field_72337_e, a.field_72334_f);
        GL11.glVertex3d(a.field_72336_d, a.field_72337_e, a.field_72339_c);
        GL11.glEnd();
    }
}
