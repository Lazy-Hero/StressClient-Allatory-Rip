// 
// Decompiled by Procyon v0.5.36
// 

package l.p.l.p;

import l.p.l.I;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraft.client.gui.FontRenderer;
import java.util.Iterator;
import net.minecraft.client.gui.Gui;
import org.lwjgl.opengl.GL11;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.Minecraft;
import net.minecraftforge.client.event.RenderGameOverlayEvent$Text;
import java.awt.Color;
import l.p.l.H;

public class c extends H
{
    public static Color ALLATORIxDEMO(final long a, float a, final int a) {
        a = (float)new Color((int)Long.parseLong(Integer.toHexString(Color.HSBtoRGB((System.nanoTime() + a * a) / 1.0E10f % 1.0f, a, 1.0f)), 16));
        return new Color(((Color)a).getRed() / 255.0f, ((Color)a).getGreen() / 255.0f, ((Color)a).getBlue() / 255.0f, ((Color)a).getAlpha() / 255.0f);
    }
    
    @SubscribeEvent
    public void b(RenderGameOverlayEvent$Text a) {
        a = (RenderGameOverlayEvent$Text)new ScaledResolution(Minecraft.func_71410_x());
        GL11.glPushMatrix();
        final float n = 1.2f;
        GL11.glScalef(n, n, 1.0f);
        final String a2 = "Cracked by BlueMouse";
        final int n2 = 2;
        ALLATORIxDEMO(a2, n2, n2);
        GL11.glPopMatrix();
        ALLATORIxDEMO(new StringBuilder().insert(0, "Fps:").append(Minecraft.func_175610_ah()).toString(), 2, 15);
        final int n3 = ((ScaledResolution)a).func_78328_b() - c.ALLATORIxDEMO.field_71466_p.field_78288_b - 1;
        final int func_78256_a = c.ALLATORIxDEMO.field_71466_p.func_78256_a(c.ALLATORIxDEMO.field_71439_g.func_180425_c().toString().replace("BlockPos", ""));
        final int n4 = 1;
        final int n5 = func_78256_a + n4;
        final int func_78328_b = ((ScaledResolution)a).func_78328_b();
        final int n6 = 0;
        Gui.func_73734_a(n4, n3, n5, func_78328_b, new Color(n6, n6, n6, 100).getRGB());
        ALLATORIxDEMO(c.ALLATORIxDEMO.field_71439_g.func_180425_c().toString().replace("7x\u0015i\u001fH\rP\u0015d\u001bf\u001fk", ""), 1, ((ScaledResolution)a).func_78328_b() - c.ALLATORIxDEMO.field_71466_p.field_78288_b);
        int a3 = 1;
        try {
            final Iterator<H> iterator = l.p.H.g.ALLATORIxDEMO.ALLATORIxDEMO().iterator();
            while (iterator.hasNext()) {
                final H h;
                if (!(h = iterator.next()).ALLATORIxDEMO().equalsIgnoreCase("HUD") && h.ALLATORIxDEMO() && h.g) {
                    final FontRenderer field_71466_p = Minecraft.func_71410_x().field_71466_p;
                    final int func_78326_a = ((ScaledResolution)a).func_78326_a();
                    final FontRenderer fontRenderer = field_71466_p;
                    final H h2 = h;
                    final int n7 = func_78326_a - fontRenderer.func_78256_a(h2.ALLATORIxDEMO()) - 2;
                    final int n8 = a3;
                    final int func_78326_a2 = ((ScaledResolution)a).func_78326_a();
                    final int n9 = a3 + 9;
                    final int n10 = 0;
                    Gui.func_73734_a(n7, n8, func_78326_a2, n9, new Color(n10, n10, n10, 100).getRGB());
                    ALLATORIxDEMO(h2.ALLATORIxDEMO(), ((ScaledResolution)a).func_78326_a() - field_71466_p.func_78256_a(h.ALLATORIxDEMO()) - 1, a3);
                    a3 = n8 + field_71466_p.field_78288_b;
                }
            }
        }
        catch (Exception ex) {}
    }
    
    public c() {
        final boolean a = true;
        super("HUD", "", I.c);
        this.ALLATORIxDEMO(a);
    }
    
    public static void ALLATORIxDEMO(final String a, int a, final int a) {
        a = a;
        int n;
        int i = n = 0;
        String s = a;
        while (i < s.length()) {
            Minecraft.func_71410_x().field_71466_p.func_175063_a(a.charAt(n) + "", (float)a, (float)a, ALLATORIxDEMO(n * 3500000L, 1.0f, 100).getRGB());
            a += Minecraft.func_71410_x().field_71466_p.func_78263_a(a.charAt(n));
            i = ++n;
            s = a;
        }
    }
}
