// 
// Decompiled by Procyon v0.5.36
// 

package l.p.l.p;

import l.p.p.i;
import l.p.l.I;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.util.math.Vec3d;
import org.lwjgl.opengl.GL11;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import java.util.Iterator;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraftforge.client.event.RenderWorldLastEvent;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.entity.item.EntityArmorStand;
import net.minecraft.entity.EntityLivingBase;
import l.p.l.H;

public class L extends H
{
    public boolean ALLATORIxDEMO(final EntityLivingBase a) {
        return !(a instanceof EntityArmorStand) && !(a instanceof EntityPlayerSP) && a != l.p.t.H.ALLATORIxDEMO.ALLATORIxDEMO();
    }
    
    @SubscribeEvent
    @Override
    public void ALLATORIxDEMO(final RenderWorldLastEvent a) {
        if (this.b()) {
            return;
        }
        final Iterator<EntityPlayer> iterator2;
        Iterator<EntityPlayer> iterator = iterator2 = this.ALLATORIxDEMO().iterator();
        while (iterator.hasNext()) {
            final EntityPlayer a2;
            if (!((a2 = iterator2.next()) instanceof EntityPlayer) || a2 != L.ALLATORIxDEMO.field_71439_g) {}
            this.ALLATORIxDEMO((Entity)a2, a.getPartialTicks());
            iterator = iterator2;
        }
        super.ALLATORIxDEMO(a);
    }
    
    public void ALLATORIxDEMO(Entity a, final float a, final float a, final float a, final float a, final float a) {
        l.p.H.g.c.ALLATORIxDEMO(this, "Red").B();
        l.p.H.g.c.ALLATORIxDEMO(this, "Green").B();
        l.p.H.g.c.ALLATORIxDEMO(this, "Blue").B();
        l.p.H.g.c.ALLATORIxDEMO(this, "Alpha").B();
        final double field_78730_l = l.p.t.H.ALLATORIxDEMO.ALLATORIxDEMO().func_175598_ae().field_78730_l;
        final double field_78731_m = l.p.t.H.ALLATORIxDEMO.ALLATORIxDEMO().func_175598_ae().field_78731_m;
        final double field_78728_n = l.p.t.H.ALLATORIxDEMO.ALLATORIxDEMO().func_175598_ae().field_78728_n;
        final Entity entity = a;
        final double n = entity.field_70142_S + (a.field_70165_t - a.field_70142_S) * a - field_78730_l;
        final double field_70137_T = entity.field_70137_T;
        final Entity entity2 = a;
        final double n2 = field_70137_T + (entity2.field_70163_u - a.field_70137_T) * a + a.field_70131_O / 2.0f - field_78731_m;
        final double n3 = entity2.field_70136_U + (a.field_70161_v - a.field_70136_U) * a - field_78728_n;
        GL11.glBlendFunc(770, 771);
        GL11.glEnable(3042);
        GL11.glEnable(2848);
        GL11.glDisable(2896);
        GL11.glLineWidth(2.5f);
        GL11.glDisable(3553);
        GL11.glDisable(2929);
        GL11.glDepthMask(false);
        GL11.glColor4f((float)l.p.H.g.c.ALLATORIxDEMO(this, "Red").B(), (float)l.p.H.g.c.ALLATORIxDEMO(this, "Green").B(), (float)l.p.H.g.c.ALLATORIxDEMO(this, "Blue").B(), (float)l.p.H.g.c.ALLATORIxDEMO(this, "Alpha").B());
        a = null;
        final double n4 = 0.0;
        a = (Entity)new Vec3d(n4, n4, 1.0).func_178789_a(-(float)Math.toRadians(l.p.t.H.ALLATORIxDEMO.ALLATORIxDEMO().field_70125_A)).func_178785_b(-(float)Math.toRadians(l.p.t.H.ALLATORIxDEMO.ALLATORIxDEMO().field_70177_z));
        GL11.glBegin(1);
        final double n5 = n;
        final double n6 = n2;
        GL11.glVertex3d(((Vec3d)a).field_72450_a, l.p.t.H.ALLATORIxDEMO.ALLATORIxDEMO().func_70047_e() + ((Vec3d)a).field_72448_b, ((Vec3d)a).field_72449_c);
        GL11.glVertex3d(n5, n6, n3);
        GL11.glEnd();
        GL11.glEnable(3553);
        GL11.glEnable(2929);
        GL11.glEnable(2896);
        GL11.glDepthMask(true);
        GlStateManager.func_179117_G();
    }
    
    public List<EntityPlayer> ALLATORIxDEMO() {
        final ArrayList<EntityPlayer> list = new ArrayList<EntityPlayer>();
        final Iterator<EntityPlayer> iterator2;
        Iterator<EntityPlayer> iterator = iterator2 = L.ALLATORIxDEMO.field_71441_e.func_72910_y().iterator();
        while (iterator.hasNext()) {
            final EntityPlayer next;
            if (!((next = iterator2.next()) instanceof EntityPlayer)) {
                iterator = iterator2;
            }
            else {
                final EntityPlayer a = next;
                if (!this.ALLATORIxDEMO((EntityLivingBase)a)) {
                    iterator = iterator2;
                }
                else {
                    list.add(a);
                    iterator = iterator2;
                }
            }
        }
        return list;
    }
    
    private /* synthetic */ void ALLATORIxDEMO(final Entity a, final float a) {
        final float n = 1.0f;
        this.ALLATORIxDEMO(a, n, n, n, 0.5f, a);
    }
    
    public L() {
        super("Tracers", "", I.c);
        l.p.H.g.c.ALLATORIxDEMO(new i("Red", this, 0.1, 0.0, 1.0, false));
        l.p.H.g.c.ALLATORIxDEMO(new i("Green", this, 0.1, 0.0, 1.0, false));
        l.p.H.g.c.ALLATORIxDEMO(new i("Blue", this, 0.1, 0.0, 1.0, false));
        final l.p.p.H c = l.p.H.g.c;
        final String a = "Alpha";
        final double a2 = 0.0;
        final double n = 1.0;
        c.ALLATORIxDEMO(new i(a, this, n, a2, n, false));
    }
}
