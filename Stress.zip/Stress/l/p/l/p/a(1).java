// 
// Decompiled by Procyon v0.5.36
// 

package l.p.l.p;

import java.util.Iterator;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraft.entity.Entity;
import net.minecraft.entity.item.EntityItem;
import net.minecraftforge.client.event.RenderWorldLastEvent;
import net.minecraftforge.common.MinecraftForge;
import l.p.l.I;
import l.p.l.H;

public class a extends H
{
    public a() {
        super("ItemESP", "", I.c);
    }
    
    @Override
    public void b() {
        MinecraftForge.EVENT_BUS.register((Object)this);
    }
    
    @SubscribeEvent
    public void b(RenderWorldLastEvent a) {
        a = (RenderWorldLastEvent)a.ALLATORIxDEMO.field_71441_e.func_72910_y().iterator();
    Label_0015:
        while (true) {
            RenderWorldLastEvent renderWorldLastEvent = a;
            while (((Iterator)renderWorldLastEvent).hasNext()) {
                final Entity entity;
                if (!((entity = ((Iterator<Entity>)a).next()) instanceof EntityItem)) {
                    continue Label_0015;
                }
                renderWorldLastEvent = a;
                entity.func_184195_f(true);
            }
            break;
        }
    }
    
    @Override
    public void B() {
        MinecraftForge.EVENT_BUS.unregister((Object)this);
        if (a.ALLATORIxDEMO.field_71441_e == null || a.ALLATORIxDEMO.field_71439_g == null) {
            return;
        }
        final Iterator<Entity> iterator2;
        Iterator<Entity> iterator = iterator2 = a.ALLATORIxDEMO.field_71441_e.func_72910_y().iterator();
        while (iterator.hasNext()) {
            iterator2.next().func_184195_f(false);
            iterator = iterator2;
        }
    }
}
