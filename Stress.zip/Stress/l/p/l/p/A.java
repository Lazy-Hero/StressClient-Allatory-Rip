// 
// Decompiled by Procyon v0.5.36
// 

package l.p.l.p;

import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import java.util.Iterator;
import net.minecraft.client.renderer.RenderHelper;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraftforge.client.event.RenderWorldLastEvent;
import net.minecraft.entity.EntityLiving;
import net.minecraft.entity.Entity;
import l.p.l.I;
import l.p.l.H;

public class A extends H
{
    public A() {
        super("MobChams", "", I.c);
    }
    
    void ALLATORIxDEMO(final Entity a, final float a) {
        if (a instanceof EntityLiving) {
            if (a == null || a == l.p.t.H.ALLATORIxDEMO.ALLATORIxDEMO()) {
                return;
            }
            if (a == l.p.t.H.ALLATORIxDEMO.ALLATORIxDEMO().func_175606_aa() && l.p.t.H.ALLATORIxDEMO.ALLATORIxDEMO().field_74320_O == 0) {
                return;
            }
            l.p.t.H.ALLATORIxDEMO.ALLATORIxDEMO().field_71460_t.func_175072_h();
            l.p.t.H.ALLATORIxDEMO.ALLATORIxDEMO().func_175598_ae().func_188388_a(a, a, false);
            l.p.t.H.ALLATORIxDEMO.ALLATORIxDEMO().field_71460_t.func_180436_i();
        }
    }
    
    @SubscribeEvent
    @Override
    public void ALLATORIxDEMO(final RenderWorldLastEvent a) {
        GlStateManager.func_179086_m(256);
        RenderHelper.func_74519_b();
        final Iterator<Entity> iterator2;
        Iterator<Entity> iterator = iterator2 = A.ALLATORIxDEMO.field_71441_e.func_72910_y().iterator();
        while (iterator.hasNext()) {
            final Entity a2 = iterator2.next();
            iterator = iterator2;
            this.ALLATORIxDEMO(a2, a.getPartialTicks());
        }
        super.ALLATORIxDEMO(a);
    }
}
