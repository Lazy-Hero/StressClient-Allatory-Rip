// 
// Decompiled by Procyon v0.5.36
// 

package l.p.l.p;

import java.util.Iterator;
import l.p.l.I;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import net.minecraft.client.renderer.Tessellator;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraft.tileentity.TileEntityEnderChest;
import net.minecraft.tileentity.TileEntityChest;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.MathHelper;
import net.minecraft.block.Block;
import org.lwjgl.opengl.GL11;
import net.minecraft.client.renderer.GlStateManager$DestFactor;
import net.minecraft.client.renderer.GlStateManager$SourceFactor;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.entity.Entity;
import net.minecraft.entity.item.EntityMinecartChest;
import net.minecraftforge.client.event.RenderWorldLastEvent;
import net.minecraft.client.renderer.BufferBuilder;
import l.p.l.H;

public class G extends H
{
    public static void ALLATORIxDEMO(final BufferBuilder a, final double a, final double a, final double a, final double a, final double a, final double a, final float a, final float a, final float a, final float a) {
        a.func_181662_b(a, a, a).func_181666_a(a, a, a, 0.0f).func_181675_d();
        a.func_181662_b(a, a, a).func_181666_a(a, a, a, a).func_181675_d();
        a.func_181662_b(a, a, a).func_181666_a(a, a, a, a).func_181675_d();
        a.func_181662_b(a, a, a).func_181666_a(a, a, a, a).func_181675_d();
        a.func_181662_b(a, a, a).func_181666_a(a, a, a, a).func_181675_d();
        a.func_181662_b(a, a, a).func_181666_a(a, a, a, a).func_181675_d();
        a.func_181662_b(a, a, a).func_181666_a(a, a, a, a).func_181675_d();
        a.func_181662_b(a, a, a).func_181666_a(a, a, a, a).func_181675_d();
        a.func_181662_b(a, a, a).func_181666_a(a, a, a, a).func_181675_d();
        a.func_181662_b(a, a, a).func_181666_a(a, a, a, a).func_181675_d();
        a.func_181662_b(a, a, a).func_181666_a(a, a, a, a).func_181675_d();
        a.func_181662_b(a, a, a).func_181666_a(a, a, a, 0.0f).func_181675_d();
        a.func_181662_b(a, a, a).func_181666_a(a, a, a, a).func_181675_d();
        a.func_181662_b(a, a, a).func_181666_a(a, a, a, 0.0f).func_181675_d();
        a.func_181662_b(a, a, a).func_181666_a(a, a, a, a).func_181675_d();
        a.func_181662_b(a, a, a).func_181666_a(a, a, a, 0.0f).func_181675_d();
        a.func_181662_b(a, a, a).func_181666_a(a, a, a, a).func_181675_d();
        a.func_181662_b(a, a, a).func_181666_a(a, a, a, 0.0f).func_181675_d();
    }
    
    public static void b(final BufferBuilder a, final double a, final double a, final double a, final double a, final double a, final double a, final float a, final float a, final float a, final float a) {
        a.func_181662_b(a, a, a).func_181666_a(a, a, a, a).func_181675_d();
        a.func_181662_b(a, a, a).func_181666_a(a, a, a, a).func_181675_d();
        a.func_181662_b(a, a, a).func_181666_a(a, a, a, a).func_181675_d();
        a.func_181662_b(a, a, a).func_181666_a(a, a, a, a).func_181675_d();
        a.func_181662_b(a, a, a).func_181666_a(a, a, a, a).func_181675_d();
        a.func_181662_b(a, a, a).func_181666_a(a, a, a, a).func_181675_d();
        a.func_181662_b(a, a, a).func_181666_a(a, a, a, a).func_181675_d();
        a.func_181662_b(a, a, a).func_181666_a(a, a, a, a).func_181675_d();
        a.func_181662_b(a, a, a).func_181666_a(a, a, a, a).func_181675_d();
        a.func_181662_b(a, a, a).func_181666_a(a, a, a, a).func_181675_d();
        a.func_181662_b(a, a, a).func_181666_a(a, a, a, a).func_181675_d();
        a.func_181662_b(a, a, a).func_181666_a(a, a, a, a).func_181675_d();
        a.func_181662_b(a, a, a).func_181666_a(a, a, a, a).func_181675_d();
        a.func_181662_b(a, a, a).func_181666_a(a, a, a, a).func_181675_d();
        a.func_181662_b(a, a, a).func_181666_a(a, a, a, a).func_181675_d();
        a.func_181662_b(a, a, a).func_181666_a(a, a, a, a).func_181675_d();
        a.func_181662_b(a, a, a).func_181666_a(a, a, a, a).func_181675_d();
        a.func_181662_b(a, a, a).func_181666_a(a, a, a, a).func_181675_d();
        a.func_181662_b(a, a, a).func_181666_a(a, a, a, a).func_181675_d();
        a.func_181662_b(a, a, a).func_181666_a(a, a, a, a).func_181675_d();
        a.func_181662_b(a, a, a).func_181666_a(a, a, a, a).func_181675_d();
        a.func_181662_b(a, a, a).func_181666_a(a, a, a, a).func_181675_d();
        a.func_181662_b(a, a, a).func_181666_a(a, a, a, a).func_181675_d();
        a.func_181662_b(a, a, a).func_181666_a(a, a, a, a).func_181675_d();
    }
    
    @SubscribeEvent
    public void b(RenderWorldLastEvent a) {
        a = (RenderWorldLastEvent)G.ALLATORIxDEMO.field_71441_e.field_72996_f.iterator();
    Label_0017:
        while (true) {
            RenderWorldLastEvent renderWorldLastEvent = a;
            while (((Iterator)renderWorldLastEvent).hasNext()) {
                final Entity entity;
                if (!((entity = ((Iterator<Entity>)a).next()) instanceof EntityMinecartChest)) {
                    continue Label_0017;
                }
                GlStateManager.func_179147_l();
                GlStateManager.func_187428_a(GlStateManager$SourceFactor.SRC_ALPHA, GlStateManager$DestFactor.ONE_MINUS_SRC_ALPHA, GlStateManager$SourceFactor.ONE, GlStateManager$DestFactor.ZERO);
                GL11.glDisable(3553);
                GL11.glDisable(2929);
                GL11.glDisable(2896);
                GlStateManager.func_187441_d(3.0f);
                GlStateManager.func_179090_x();
                GlStateManager.func_179132_a(true);
                final Entity entity2 = entity;
                final float n = (float)(entity2.func_180425_c().func_177958_n() - G.ALLATORIxDEMO.func_175598_ae().field_78730_l);
                final float n2 = (float)(entity2.func_180425_c().func_177956_o() - G.ALLATORIxDEMO.func_175598_ae().field_78731_m);
                final float n3 = (float)(entity2.func_180425_c().func_177952_p() - G.ALLATORIxDEMO.func_175598_ae().field_78728_n);
                final double n4 = n;
                final double n5 = n2;
                final double n6 = n3;
                final double n7 = n + Block.field_185505_j.field_72336_d;
                final double n8 = n2 + Block.field_185505_j.field_72337_e;
                final double n9 = n3 + Block.field_185505_j.field_72334_f;
                final float n10;
                final double func_151237_a = MathHelper.func_151237_a((double)(n10 = (float)(G.ALLATORIxDEMO.field_71439_g.func_174818_b(entity.func_180425_c()) / 100.0)), 0.1, 0.4);
                final double func_151237_a2 = MathHelper.func_151237_a((double)n10, 0.1, 0.4);
                b(new AxisAlignedBB(n4, n5, n6, n7, n8, n9), (float)func_151237_a2, (float)(0.0 - func_151237_a2), 0.0f, (float)func_151237_a);
                ALLATORIxDEMO(new AxisAlignedBB(n4, n5, n6, n7, n8, n9), (float)func_151237_a2, (float)(0.0 - func_151237_a2), 0.0f, (float)func_151237_a);
                GL11.glEnable(2929);
                GlStateManager.func_179132_a(false);
                GlStateManager.func_179098_w();
                GlStateManager.func_179084_k();
                renderWorldLastEvent = a;
            }
            break;
        }
        a = (RenderWorldLastEvent)G.ALLATORIxDEMO.field_71441_e.field_147482_g.iterator();
        Label_0364:
        while (true) {
            RenderWorldLastEvent renderWorldLastEvent2 = a;
            while (((Iterator)renderWorldLastEvent2).hasNext()) {
                final TileEntity tileEntity2;
                final TileEntity tileEntity = tileEntity2 = ((Iterator<TileEntity>)a).next();
                final float n11 = (float)(tileEntity.func_174877_v().func_177958_n() - G.ALLATORIxDEMO.func_175598_ae().field_78730_l);
                final float n12 = (float)(tileEntity.func_174877_v().func_177956_o() - G.ALLATORIxDEMO.func_175598_ae().field_78731_m);
                final float n13 = (float)(tileEntity.func_174877_v().func_177952_p() - G.ALLATORIxDEMO.func_175598_ae().field_78728_n);
                final double n14 = n11;
                final double n15 = n12;
                final double n16 = n13;
                final double n17 = n11;
                tileEntity.func_145838_q();
                final double n18 = n17 + Block.field_185505_j.field_72336_d;
                final double n19 = n12;
                tileEntity2.func_145838_q();
                final double n20 = n19 + Block.field_185505_j.field_72337_e;
                final double n21 = n13;
                tileEntity2.func_145838_q();
                final double n22 = n21 + Block.field_185505_j.field_72334_f;
                double n23 = 0.0;
                double n24 = 0.0;
                double n25 = 0.0;
                double n26 = 0.0;
                if (!(tileEntity instanceof TileEntityChest) && !(tileEntity2 instanceof TileEntityEnderChest)) {
                    continue Label_0364;
                }
                if (tileEntity2 instanceof TileEntityChest) {
                    n23 = ((((TileEntityChest)tileEntity2).field_145991_k != null) ? 1.0 : 0.0);
                    n24 = ((((TileEntityChest)tileEntity2).field_145990_j != null) ? 0.875 : 0.0);
                    n25 = ((((TileEntityChest)tileEntity2).field_145992_i != null) ? 1.0 : 0.0);
                    n26 = ((((TileEntityChest)tileEntity2).field_145988_l != null) ? 0.875 : 0.0);
                }
                final double n27 = n11 + 0.0625 - n23;
                final double n28 = n12;
                final double n29 = n13 + 0.0625 - n25;
                final double n30 = n11 + 0.9375 - n24;
                final double n31 = n12 + 0.875;
                final double n32 = n13 + 0.9375 - n26;
                GlStateManager.func_179147_l();
                GlStateManager.func_187428_a(GlStateManager$SourceFactor.SRC_ALPHA, GlStateManager$DestFactor.ONE_MINUS_SRC_ALPHA, GlStateManager$SourceFactor.ONE, GlStateManager$DestFactor.ZERO);
                GL11.glDisable(3553);
                GL11.glDisable(2929);
                GL11.glDisable(2896);
                GlStateManager.func_187441_d(3.0f);
                GlStateManager.func_179090_x();
                GlStateManager.func_179132_a(false);
                if (tileEntity2 instanceof TileEntityChest) {
                    final float n33;
                    final double func_151237_a3 = MathHelper.func_151237_a((double)(n33 = (float)(G.ALLATORIxDEMO.field_71439_g.func_174818_b(tileEntity2.func_174877_v()) / 100.0)), 0.1, 0.4);
                    final double func_151237_a4 = MathHelper.func_151237_a((double)n33, 0.1, 0.4);
                    b(new AxisAlignedBB(n27, n28, n29, n30, n31, n32), (float)func_151237_a4, (float)(10.0 - func_151237_a4), 1.0f, (float)func_151237_a3);
                    ALLATORIxDEMO(new AxisAlignedBB(n27, n28, n29, n30, n31, n32), (float)func_151237_a4, (float)(10.0 - func_151237_a4), 1.0f, (float)func_151237_a3);
                }
                else if (tileEntity2 instanceof TileEntityEnderChest) {
                    final float n34;
                    final double func_151237_a5 = MathHelper.func_151237_a((double)(n34 = (float)(G.ALLATORIxDEMO.field_71439_g.func_174818_b(tileEntity2.func_174877_v()) / 100.0)), 0.1, 0.4);
                    final double func_151237_a6 = MathHelper.func_151237_a((double)n34, 0.1, 0.4);
                    b(new AxisAlignedBB(n27, n28, n29, n30, n31, n32), (float)(1.0 - func_151237_a6), (float)func_151237_a6, 1.0f, (float)func_151237_a5);
                    ALLATORIxDEMO(new AxisAlignedBB(n27, n28, n29, n30, n31, n32), (float)(1.0 - func_151237_a6), (float)func_151237_a6, 1.0f, (float)func_151237_a5);
                }
                GL11.glEnable(2929);
                GlStateManager.func_179132_a(true);
                GlStateManager.func_179098_w();
                GlStateManager.func_179084_k();
                renderWorldLastEvent2 = a;
            }
            break;
        }
    }
    
    public static void b(final double a, final double a, final double a, final double a, final double a, final double a, final float a, final float a, final float a, final float a) {
        final Tessellator func_178181_a = Tessellator.func_178181_a();
        final BufferBuilder func_178180_c = func_178181_a.func_178180_c();
        func_178180_c.func_181668_a(7, DefaultVertexFormats.field_181706_f);
        b(func_178180_c, a, a, a, a, a, a, a, a, a, a);
        func_178181_a.func_78381_a();
    }
    
    public G() {
        super("ChestESP", "rthygfhjfgh", I.c);
    }
    
    public static void b(final AxisAlignedBB a, final float a, final float a, final float a, final float a) {
        b(a.field_72340_a, a.field_72338_b, a.field_72339_c, a.field_72336_d, a.field_72337_e, a.field_72334_f, a, a, a, a);
    }
    
    public static void ALLATORIxDEMO(final AxisAlignedBB a, final float a, final float a, final float a, final float a) {
        ALLATORIxDEMO(a.field_72340_a, a.field_72338_b, a.field_72339_c, a.field_72336_d, a.field_72337_e, a.field_72334_f, a, a, a, a);
    }
    
    public static void ALLATORIxDEMO(final double a, final double a, final double a, final double a, final double a, final double a, final float a, final float a, final float a, final float a) {
        final Tessellator func_178181_a = Tessellator.func_178181_a();
        final BufferBuilder func_178180_c = func_178181_a.func_178180_c();
        func_178180_c.func_181668_a(3, DefaultVertexFormats.field_181706_f);
        ALLATORIxDEMO(func_178180_c, a, a, a, a, a, a, a, a, a, a);
        func_178181_a.func_78381_a();
    }
}
