// 
// Decompiled by Procyon v0.5.36
// 

package l.p.l.p;

import net.minecraft.entity.player.EntityPlayer;
import l.p.l.I;
import java.util.Iterator;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraft.entity.Entity;
import net.minecraftforge.client.event.RenderWorldLastEvent;
import l.p.l.H;

public class g extends H
{
    @SubscribeEvent
    public void b(RenderWorldLastEvent a) {
        a = (RenderWorldLastEvent)g.ALLATORIxDEMO.field_71441_e.func_72910_y().iterator();
    Label_0015:
        while (true) {
            RenderWorldLastEvent renderWorldLastEvent = a;
            while (((Iterator)renderWorldLastEvent).hasNext()) {
                final Entity a2 = ((Iterator<Entity>)a).next();
                if (!this.ALLATORIxDEMO(a2)) {
                    continue Label_0015;
                }
                renderWorldLastEvent = a;
                a2.func_184195_f(true);
            }
            break;
        }
    }
    
    @Override
    public void B() {
        MinecraftForge.EVENT_BUS.unregister((Object)this);
        if (g.ALLATORIxDEMO.field_71441_e == null || g.ALLATORIxDEMO.field_71439_g == null) {
            return;
        }
        final Iterator<Entity> iterator2;
        Iterator<Entity> iterator = iterator2 = g.ALLATORIxDEMO.field_71441_e.func_72910_y().iterator();
        while (iterator.hasNext()) {
            iterator2.next().func_184195_f(false);
            iterator = iterator2;
        }
    }
    
    public g() {
        super("PlayerESP", "", I.c);
    }
    
    public boolean ALLATORIxDEMO(final Entity a) {
        return a instanceof EntityPlayer && a != g.ALLATORIxDEMO.field_71439_g;
    }
    
    @Override
    public void b() {
        MinecraftForge.EVENT_BUS.register((Object)this);
    }
}
