// 
// Decompiled by Procyon v0.5.36
// 

package l.p.l.p;

import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.client.renderer.EntityRenderer;
import net.minecraft.util.math.Vec3d;
import org.lwjgl.opengl.GL11;
import net.minecraft.client.Minecraft;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraftforge.client.event.RenderLivingEvent$Specials$Pre;
import l.p.p.i;
import l.p.l.I;
import l.p.l.H;

public class F extends H
{
    public F() {
        super("NameTags", "", I.c);
        l.p.H.g.c.ALLATORIxDEMO(new i("Sneaking", this, true));
        l.p.H.g.c.ALLATORIxDEMO(new i("Upscale", this, true));
    }
    
    @SubscribeEvent
    public void ALLATORIxDEMO(final RenderLivingEvent$Specials$Pre a) {
        final EntityLivingBase entity;
        if (!((entity = a.getEntity()) instanceof EntityPlayer) || entity == Minecraft.func_71410_x().field_71439_g) {
            return;
        }
        if (entity.field_70128_L || entity.func_110143_aJ() < 0.0f || entity.func_82150_aj()) {
            return;
        }
        GL11.glPushMatrix();
        final Vec3d vec3d = new Vec3d(a.getX(), a.getY() + entity.field_70131_O / 1.5, a.getZ());
        Minecraft.func_71410_x().func_175598_ae();
        GL11.glTranslated(vec3d.field_72450_a, vec3d.field_72448_b + 1.2999999523162842, vec3d.field_72449_c);
        if (l.p.H.g.c.ALLATORIxDEMO(this, "Upscale").E()) {
            final double a2 = 1.0;
            final Vec3d vec3d2 = vec3d;
            final double n = 0.0;
            final double max = Math.max(a2, vec3d2.func_72438_d(new Vec3d(n, n, n)) / 6.0);
            GL11.glScaled(max, max, max);
        }
        final int i = (int)Math.ceil(entity.func_110143_aJ());
        final FontRenderer field_71466_p = Minecraft.func_71410_x().field_71466_p;
        final String string = new StringBuilder().insert(0, "§7").append(entity.func_145748_c_().func_150254_d()).append((i > 12) ? " §a" : ((i > 6) ? " §e" : " §c")).append(i).toString();
        final float n2 = 0.0f;
        EntityRenderer.func_189692_a(field_71466_p, string, n2, n2, n2, 0, Minecraft.func_71410_x().func_175598_ae().field_78735_i, Minecraft.func_71410_x().func_175598_ae().field_78732_j, Minecraft.func_71410_x().field_71474_y.field_74320_O == 2, !l.p.H.g.c.ALLATORIxDEMO(this, "Sneaking").E() && entity.func_70093_af());
        GL11.glPopMatrix();
        a.setCanceled(true);
    }
}
