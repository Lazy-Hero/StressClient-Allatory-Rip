// 
// Decompiled by Procyon v0.5.36
// 

package l.p.l.p;

import l.p.t.B;
import l.p.p.i;
import l.p.l.I;
import java.util.function.ToIntFunction;
import net.minecraft.item.Item;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraft.client.gui.FontRenderer;
import java.util.Iterator;
import net.minecraft.client.renderer.RenderItem;
import net.minecraft.item.ItemStack;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraftforge.client.event.RenderGameOverlayEvent$Text;
import l.p.l.H;

public class m extends H
{
    @SubscribeEvent
    @Override
    public void ALLATORIxDEMO(RenderGameOverlayEvent$Text a) {
        a = (RenderGameOverlayEvent$Text)new ScaledResolution(l.p.t.H.ALLATORIxDEMO.ALLATORIxDEMO());
        final RenderItem func_175599_af = l.p.t.H.ALLATORIxDEMO.ALLATORIxDEMO().func_175599_af();
        GlStateManager.func_179094_E();
        GlStateManager.func_179098_w();
        final int func_78326_a = ((ScaledResolution)a).func_78326_a();
        final RenderGameOverlayEvent$Text renderGameOverlayEvent$Text = a;
        a = (RenderGameOverlayEvent$Text)(func_78326_a - ((ScaledResolution)renderGameOverlayEvent$Text).func_78326_a() + 50);
        int n = 2;
        final int n2 = ((ScaledResolution)renderGameOverlayEvent$Text).func_78328_b() - 40 - (l.p.t.H.ALLATORIxDEMO.ALLATORIxDEMO().func_70090_H() ? 10 : 0);
        int n3 = 0;
        final Iterator iterator2;
        Iterator<ItemStack> iterator = (Iterator<ItemStack>)(iterator2 = l.p.t.H.ALLATORIxDEMO.ALLATORIxDEMO().field_70460_b.iterator());
        while (iterator.hasNext()) {
            final ItemStack itemStack = iterator2.next();
            ++n;
            final ItemStack itemStack2 = itemStack;
            if (itemStack.func_190926_b()) {
                iterator = (Iterator<ItemStack>)iterator2;
            }
            else {
                final RenderGameOverlayEvent$Text renderGameOverlayEvent$Text2 = (RenderGameOverlayEvent$Text)(a - 70);
                n3 += 20;
                final int n4 = (int)(renderGameOverlayEvent$Text2 + (11 - n));
                GlStateManager.func_179126_j();
                final RenderItem renderItem = func_175599_af;
                final ItemStack itemStack3 = itemStack2;
                renderItem.func_180450_b(itemStack3, n4 + n3, n2);
                renderItem.func_180453_a(l.p.t.H.ALLATORIxDEMO.ALLATORIxDEMO(), itemStack2, n4 + n3, n2, "");
                GlStateManager.func_179098_w();
                GlStateManager.func_179140_f();
                GlStateManager.func_179097_i();
                final String s = (itemStack3.func_190916_E() > 5) ? (itemStack2.func_190916_E() + "") : "";
                final FontRenderer allatorIxDEMO = l.p.t.H.ALLATORIxDEMO.ALLATORIxDEMO();
                final int n5 = n4 + 19 - 2;
                final FontRenderer allatorIxDEMO2 = l.p.t.H.ALLATORIxDEMO.ALLATORIxDEMO();
                final String s2 = s;
                allatorIxDEMO.func_175063_a(s2, (float)(n5 - allatorIxDEMO2.func_78256_a(s2) + n3), (float)(n2 + 9), 16777215);
                if (l.p.H.g.c.ALLATORIxDEMO(this, "Damage").E()) {
                    final int n6 = 100 - (int)((1.0f - (itemStack2.func_77958_k() - (float)itemStack2.func_77952_i()) / itemStack2.func_77958_k()) * 100.0f);
                    l.p.t.H.ALLATORIxDEMO.ALLATORIxDEMO().func_175063_a(n6 + "", (float)(n4 + 8 - l.p.t.H.ALLATORIxDEMO.ALLATORIxDEMO().func_78256_a(n6 + "") / 2 + n3), (float)(n2 - 11), l.p.H.B);
                }
                GlStateManager.func_179126_j();
                GlStateManager.func_179140_f();
                iterator = (Iterator<ItemStack>)iterator2;
            }
        }
        GlStateManager.func_179126_j();
        GlStateManager.func_179140_f();
        GlStateManager.func_179121_F();
    }
    
    int ALLATORIxDEMO(final Item a) {
        return l.p.t.H.ALLATORIxDEMO.ALLATORIxDEMO().field_184439_c.stream().filter(a -> a.func_77973_b() == a).mapToInt(ItemStack::func_190916_E).sum();
    }
    
    public m() {
        final int a = 30000;
        final int a2 = 0;
        super("ArmorHUD", "", I.c);
        l.p.H.g.c.ALLATORIxDEMO(new i("Damage", this, true));
        l.p.H.B = l.p.t.B.ALLATORIxDEMO(a, a2);
    }
}
