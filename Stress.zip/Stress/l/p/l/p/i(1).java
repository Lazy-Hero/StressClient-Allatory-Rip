// 
// Decompiled by Procyon v0.5.36
// 

package l.p.l.p;

import net.minecraft.client.renderer.entity.RenderManager;
import l.p.t.E;
import net.minecraftforge.common.MinecraftForge;
import l.p.l.I;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraft.util.math.AxisAlignedBB;
import java.util.Iterator;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import l.p.t.m;
import net.minecraft.util.math.BlockPos;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLiving;
import net.minecraft.util.math.Vec3d;
import net.minecraft.item.ItemPotion;
import org.lwjgl.opengl.GL11;
import net.minecraft.item.ItemFishingRod;
import net.minecraft.item.ItemLingeringPotion;
import net.minecraft.item.ItemSplashPotion;
import net.minecraft.item.ItemEnderPearl;
import net.minecraft.item.ItemEgg;
import net.minecraft.item.ItemSnowball;
import net.minecraft.item.ItemBow;
import net.minecraft.client.Minecraft;
import net.minecraftforge.client.event.RenderWorldLastEvent;
import l.p.l.H;

public class i extends H
{
    private transient int ALLATORIxDEMO;
    
    @SubscribeEvent
    public void b(RenderWorldLastEvent a) {
        if (this.b()) {
            return;
        }
        final EntityPlayer field_71439_g;
        final ItemStack func_70448_g;
        if ((func_70448_g = (field_71439_g = (EntityPlayer)Minecraft.func_71410_x().field_71439_g).field_71071_by.func_70448_g()) == null) {
            return;
        }
        final Item func_77973_b;
        if (!((func_77973_b = func_70448_g.func_77973_b()) instanceof ItemBow) && !(func_77973_b instanceof ItemSnowball) && !(func_77973_b instanceof ItemEgg) && !(func_77973_b instanceof ItemEnderPearl) && !(func_77973_b instanceof ItemSplashPotion) && !(func_77973_b instanceof ItemLingeringPotion) && !(func_77973_b instanceof ItemFishingRod)) {
            return;
        }
        final boolean b = func_70448_g.func_77973_b() instanceof ItemBow;
        final EntityPlayer entityPlayer = field_71439_g;
        double n = entityPlayer.field_70142_S + (field_71439_g.field_70165_t - field_71439_g.field_70142_S) * a.getPartialTicks() - Math.cos((float)Math.toRadians(field_71439_g.field_70177_z)) * 0.07999999821186066;
        final double field_70137_T = entityPlayer.field_70137_T;
        final EntityPlayer entityPlayer2 = field_71439_g;
        double n2 = field_70137_T + (entityPlayer2.field_70163_u - field_71439_g.field_70137_T) * a.getPartialTicks() + field_71439_g.func_70047_e() - 0.04;
        double n3 = entityPlayer2.field_70136_U + (field_71439_g.field_70161_v - field_71439_g.field_70136_U) * a.getPartialTicks() - Math.sin((float)Math.toRadians(field_71439_g.field_70177_z)) * 0.07999999821186066;
        a = (RenderWorldLastEvent)(b ? 1.0f : 0.4f);
        final EntityPlayer entityPlayer3 = field_71439_g;
        final float n4 = (float)Math.toRadians(entityPlayer3.field_70177_z);
        final float n5 = (float)Math.toRadians(entityPlayer3.field_70125_A);
        final double n6 = -Math.sin(n4) * Math.cos(n5) * (double)a;
        final double n7 = -Math.sin(n5) * (double)a;
        final double n8 = Math.cos(n4) * Math.cos(n5) * (double)a;
        final double n9 = n6;
        final double n10 = n9 * n9;
        final double n11 = n7;
        final double n12 = n10 + n11 * n11;
        final double n13 = n8;
        final double sqrt = Math.sqrt(n12 + n13 * n13);
        final double n14 = n6 / sqrt;
        final double n15 = n7 / sqrt;
        final double n16 = n8 / sqrt;
        double n17;
        double n18;
        double n19;
        if (b) {
            final RenderWorldLastEvent renderWorldLastEvent = a = (RenderWorldLastEvent)((72000 - field_71439_g.func_184605_cv()) / 20.0f);
            if ((a = (RenderWorldLastEvent)((renderWorldLastEvent * renderWorldLastEvent + a * 2.0f) / 3.0f)) > 1.0f || a <= 0.1f) {
                a = (RenderWorldLastEvent)1.0f;
            }
            a *= (RenderWorldLastEvent)3.0f;
            n17 = n14 * (double)a;
            n18 = n15 * (double)a;
            n19 = n16 * (double)a;
        }
        else {
            n17 = n14 * 1.5;
            n18 = n15 * 1.5;
            n19 = n16 * 1.5;
        }
        GL11.glPushAttrib(24837);
        GL11.glDisable(2896);
        GL11.glDisable(3553);
        GL11.glEnable(3042);
        GL11.glBlendFunc(770, 771);
        GL11.glDisable(2929);
        GL11.glDepthMask(false);
        GL11.glEnable(2848);
        GL11.glLineWidth(2.0f);
        a = (RenderWorldLastEvent)Minecraft.func_71410_x().func_175598_ae();
        final double a2 = b ? 0.005 : ((func_77973_b instanceof ItemPotion) ? 0.04 : ((func_77973_b instanceof ItemFishingRod) ? 0.015 : 0.003));
        final Vec3d a3 = new Vec3d(field_71439_g.field_70165_t, field_71439_g.field_70163_u + field_71439_g.func_70047_e(), field_71439_g.field_70161_v);
        boolean b2 = false;
        final boolean allatorIxDEMO;
        if (allatorIxDEMO = this.ALLATORIxDEMO(a3, new Vec3d(n, n2, n3), new Vec3d(n17, n18, n19), a2)) {
            GL11.glColor4f(0.9f, 0.2f, 0.1f, 0.5f);
        }
        else {
            GL11.glColor4f(0.0f, 0.9f, 0.8f, 0.5f);
        }
        GL11.glBegin(3);
        int n20;
        int i = n20 = 0;
    Label_0915_Outer:
        while (i < 1000) {
            double n23;
            RenderWorldLastEvent renderWorldLastEvent2;
            if (Minecraft.func_71410_x().field_71441_e.func_72933_a(a3, new Vec3d(n, n2, n3)) != null) {
                if (allatorIxDEMO) {
                    final float n21 = 0.3f;
                    final float n22 = 0.1f;
                    GL11.glColor4f(n21, n22, n22, 0.5f);
                    n23 = n;
                    renderWorldLastEvent2 = a;
                }
                else {
                    final float n24 = 0.1f;
                    final float n25 = 0.3f;
                    GL11.glColor4f(n24, n25, n25, 0.5f);
                    n23 = n;
                    renderWorldLastEvent2 = a;
                }
            }
            else if (allatorIxDEMO) {
                GL11.glColor4f(0.9f, 0.2f, 0.1f, 0.5f);
                n23 = n;
                renderWorldLastEvent2 = a;
            }
            else {
                GL11.glColor4f(0.0f, 0.9f, 0.8f, 0.5f);
                n23 = n;
                renderWorldLastEvent2 = a;
            }
            GL11.glVertex3d(n23 - ((RenderManager)renderWorldLastEvent2).field_78730_l, n2 - ((RenderManager)a).field_78731_m, n3 - ((RenderManager)a).field_78728_n);
            n += n17 * 0.1;
            n2 += n18 * 0.1;
            n3 += n19 * 0.1;
            n17 *= 0.999;
            final double n26 = n18 * 0.999;
            n19 *= 0.999;
            n18 = n26 - a2;
            final Iterator<Entity> iterator = (Iterator<Entity>)Minecraft.func_71410_x().field_71441_e.field_72996_f.iterator();
            while (true) {
                while (iterator.hasNext()) {
                    final Entity entity;
                    if ((entity = iterator.next()) instanceof EntityLiving) {
                        final AxisAlignedBB func_174813_aQ = entity.func_174813_aQ();
                        final double n27 = 0.35;
                        if (!func_174813_aQ.func_72314_b(n27, n27, n27).func_72318_a(new Vec3d(n, n2, n3))) {
                            continue Label_0915_Outer;
                        }
                        final boolean b3 = b2 = true;
                        if (b3) {
                            break Label_0915_Outer;
                        }
                        final Iterator<EntityPlayer> iterator2 = (Iterator<EntityPlayer>)Minecraft.func_71410_x().field_71441_e.field_73010_i.iterator();
                        while (true) {
                            while (iterator2.hasNext()) {
                                final EntityPlayer entityPlayer4;
                                if ((entityPlayer4 = iterator2.next()) != Minecraft.func_71410_x().field_71439_g) {
                                    final AxisAlignedBB func_174813_aQ2 = entityPlayer4.func_174813_aQ();
                                    final double n28 = 0.35;
                                    if (!func_174813_aQ2.func_72314_b(n28, n28, n28).func_72318_a(new Vec3d(n, n2, n3))) {
                                        continue Label_0915_Outer;
                                    }
                                    final boolean b4 = b2 = true;
                                    if (b4) {
                                        break Label_0915_Outer;
                                    }
                                    if (m.ALLATORIxDEMO(Minecraft.func_71410_x().field_71441_e.func_180495_p(new BlockPos(new Vec3d(n, n2, n3))).func_177230_c())) {
                                        break Label_0915_Outer;
                                    }
                                    i = ++n20;
                                    continue Label_0915_Outer;
                                }
                            }
                            final boolean b4 = b2;
                            continue;
                        }
                    }
                }
                final boolean b3 = b2;
                continue;
            }
        }
        GL11.glEnd();
        GL11.glPushMatrix();
        GL11.glTranslated(n - ((RenderManager)a).field_78730_l, n2 - ((RenderManager)a).field_78731_m, n3 - ((RenderManager)a).field_78728_n);
        GL11.glCallList(this.ALLATORIxDEMO);
        GL11.glPopMatrix();
        GL11.glPopAttrib();
    }
    
    public i() {
        final int allatorIxDEMO = 0;
        super("Trajectories", "", I.c);
        this.ALLATORIxDEMO = allatorIxDEMO;
    }
    
    boolean ALLATORIxDEMO(Vec3d a, Vec3d a, Vec3d a, final double a) {
        a = (Vec3d)0;
        int n;
        int i = n = 0;
    Label_0141_Outer:
        while (i < 250) {
            a = a.func_178787_e(a.func_186678_a(0.4));
            a = new Vec3d(a.field_72450_a * 0.996, a.field_72448_b * 0.996 - a * 4.0, a.field_72449_c * 0.996);
            final Iterator<Entity> iterator = (Iterator<Entity>)Minecraft.func_71410_x().field_71441_e.field_72996_f.iterator();
            while (true) {
                while (iterator.hasNext()) {
                    final Entity entity;
                    if ((entity = iterator.next()) instanceof EntityLiving) {
                        final AxisAlignedBB func_174813_aQ = entity.func_174813_aQ();
                        final double n2 = 0.35;
                        if (!func_174813_aQ.func_72314_b(n2, n2, n2).func_72318_a(a)) {
                            continue Label_0141_Outer;
                        }
                        final Vec3d vec3d = a = (Vec3d)1;
                        if (vec3d != 0) {
                            return (boolean)a;
                        }
                        final Iterator<EntityPlayer> iterator2 = (Iterator<EntityPlayer>)Minecraft.func_71410_x().field_71441_e.field_73010_i.iterator();
                        while (true) {
                            while (iterator2.hasNext()) {
                                final EntityPlayer entityPlayer;
                                if ((entityPlayer = iterator2.next()) != Minecraft.func_71410_x().field_71439_g) {
                                    final AxisAlignedBB func_174813_aQ2 = entityPlayer.func_174813_aQ();
                                    final double n3 = 0.35;
                                    if (!func_174813_aQ2.func_72314_b(n3, n3, n3).func_72318_a(a)) {
                                        continue Label_0141_Outer;
                                    }
                                    final Vec3d vec3d2 = a = (Vec3d)1;
                                    if (vec3d2 != 0) {
                                        return (boolean)a;
                                    }
                                    if (m.ALLATORIxDEMO(Minecraft.func_71410_x().field_71441_e.func_180495_p(new BlockPos(a)).func_177230_c())) {
                                        return (boolean)a;
                                    }
                                    i = ++n;
                                    continue Label_0141_Outer;
                                }
                            }
                            final Vec3d vec3d2 = a;
                            continue;
                        }
                    }
                }
                final Vec3d vec3d = a;
                continue;
            }
        }
        return (boolean)a;
    }
    
    @Override
    public void b() {
        MinecraftForge.EVENT_BUS.register((Object)this);
        GL11.glNewList(this.ALLATORIxDEMO = GL11.glGenLists(1), 4864);
        final double n = -0.5;
        final double n2 = 0.5;
        E.ALLATORIxDEMO(new AxisAlignedBB(n, n, n, n2, n2, n2));
        GL11.glEndList();
    }
    
    @Override
    public void B() {
        MinecraftForge.EVENT_BUS.unregister((Object)this);
        GL11.glDeleteLists(this.ALLATORIxDEMO, 1);
    }
}
