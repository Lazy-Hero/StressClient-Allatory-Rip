// 
// Decompiled by Procyon v0.5.36
// 

package l.p.l.p;

import l.p.l.I;
import net.minecraft.client.gui.GuiScreen;
import l.p.l.H;

public class l extends H
{
    @Override
    public void b() {
        final boolean a = false;
        super.b();
        l.ALLATORIxDEMO.func_147108_a((GuiScreen)l.p.H.g.J);
        this.ALLATORIxDEMO(a);
    }
    
    public l() {
        final int a = 54;
        super("ClickGUI", "Allows you to enable and disable modules", I.c);
        this.ALLATORIxDEMO(a);
    }
}
