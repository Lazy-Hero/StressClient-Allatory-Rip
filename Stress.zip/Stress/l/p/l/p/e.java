// 
// Decompiled by Procyon v0.5.36
// 

package l.p.l.p;

import net.minecraft.client.Minecraft;
import l.p.l.I;
import l.p.l.H;

public class e extends H
{
    private transient float ALLATORIxDEMO;
    
    public e() {
        super("Full Bright", "", I.c);
    }
    
    @Override
    public void B() {
        if (this.ALLATORIxDEMO < 1.0) {
            Minecraft.func_71410_x().field_71474_y.field_74333_Y = this.ALLATORIxDEMO;
            return;
        }
        Minecraft.func_71410_x().field_71474_y.field_74333_Y = 0.5f;
    }
    
    @Override
    public void b() {
        this.ALLATORIxDEMO = Minecraft.func_71410_x().field_71474_y.field_74333_Y;
        Minecraft.func_71410_x().field_71474_y.field_74333_Y = 8.0f;
    }
}
