// 
// Decompiled by Procyon v0.5.36
// 

package l.p.l.p;

import l.p.l.I;
import java.util.Iterator;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraft.entity.EntityLiving;
import net.minecraft.entity.Entity;
import net.minecraft.entity.monster.EntityMob;
import net.minecraftforge.client.event.RenderWorldLastEvent;
import l.p.l.H;

public class d extends H
{
    @SubscribeEvent
    public void b(RenderWorldLastEvent a) {
        a = (RenderWorldLastEvent)d.ALLATORIxDEMO.field_71441_e.func_72910_y().iterator();
    Label_0015:
        while (true) {
            RenderWorldLastEvent renderWorldLastEvent = a;
            while (((Iterator)renderWorldLastEvent).hasNext()) {
                final Entity entity;
                if ((entity = ((Iterator<Entity>)a).next()) instanceof EntityMob) {
                    entity.func_184195_f(true);
                }
                if (!(entity instanceof EntityLiving)) {
                    continue Label_0015;
                }
                renderWorldLastEvent = a;
                entity.func_184195_f(true);
            }
            break;
        }
    }
    
    @Override
    public void b() {
        MinecraftForge.EVENT_BUS.register((Object)this);
    }
    
    @Override
    public void B() {
        MinecraftForge.EVENT_BUS.unregister((Object)this);
        if (d.ALLATORIxDEMO.field_71441_e == null || d.ALLATORIxDEMO.field_71439_g == null) {
            return;
        }
        final Iterator<Entity> iterator2;
        Iterator<Entity> iterator = iterator2 = d.ALLATORIxDEMO.field_71441_e.func_72910_y().iterator();
        while (iterator.hasNext()) {
            iterator2.next().func_184195_f(false);
            iterator = iterator2;
        }
    }
    
    public d() {
        super("MobESP", "", I.c);
    }
}
