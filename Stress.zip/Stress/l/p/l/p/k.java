// 
// Decompiled by Procyon v0.5.36
// 

package l.p.l.p;

import l.p.l.I;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraft.util.math.BlockPos;
import net.minecraft.client.renderer.GlStateManager;
import l.p.t.B;
import net.minecraft.block.Block;
import net.minecraft.util.math.RayTraceResult$Type;
import net.minecraftforge.client.event.RenderWorldLastEvent;
import l.p.l.H;

public class k extends H
{
    @SubscribeEvent
    @Override
    public void ALLATORIxDEMO(final RenderWorldLastEvent a) {
        if (l.p.t.H.ALLATORIxDEMO.ALLATORIxDEMO().field_71476_x == null) {
            return;
        }
        if (l.p.t.H.ALLATORIxDEMO.ALLATORIxDEMO().field_71476_x.field_72313_a == RayTraceResult$Type.BLOCK) {
            final Block func_177230_c = k.ALLATORIxDEMO.field_71441_e.func_180495_p(k.ALLATORIxDEMO.field_71476_x.func_178782_a()).func_177230_c();
            final BlockPos func_178782_a = l.p.t.H.ALLATORIxDEMO.ALLATORIxDEMO().field_71476_x.func_178782_a();
            if (Block.func_149682_b(func_177230_c) == 0) {
                return;
            }
            final BlockPos a2 = func_178782_a;
            final float a3 = 0.0f;
            final float n = 1.0f;
            l.p.t.B.ALLATORIxDEMO(a2, n, a3, n);
        }
        GlStateManager.func_179117_G();
        super.ALLATORIxDEMO(a);
    }
    
    public k() {
        super("BlockOverlay", "", I.c);
    }
    
    @Override
    public String b() {
        return "Show of selected block.";
    }
}
