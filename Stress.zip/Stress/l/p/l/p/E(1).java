// 
// Decompiled by Procyon v0.5.36
// 

package l.p.l.p;

import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import java.util.Iterator;
import java.awt.Color;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraftforge.client.event.RenderGameOverlayEvent$Text;
import l.p.l.I;
import l.p.l.H;

public class E extends H
{
    @Override
    public String b() {
        return "Show all players around you.";
    }
    
    public E() {
        super("PlayerRadar", "", I.i);
    }
    
    @SubscribeEvent
    @Override
    public void ALLATORIxDEMO(final RenderGameOverlayEvent$Text a) {
        int n = 25;
        final ScaledResolution scaledResolution = new ScaledResolution(l.p.t.H.ALLATORIxDEMO.ALLATORIxDEMO());
        final Iterator<EntityPlayer> iterator = E.ALLATORIxDEMO.field_71441_e.func_72910_y().iterator();
    Label_0032:
        while (true) {
            Iterator<EntityPlayer> iterator2 = iterator;
            while (iterator2.hasNext()) {
                final EntityPlayer next;
                if (!((next = iterator.next()) instanceof EntityPlayer)) {
                    continue Label_0032;
                }
                final EntityPlayer entityPlayer = next;
                final int i = (int)l.p.t.H.ALLATORIxDEMO.ALLATORIxDEMO().func_70032_d((Entity)entityPlayer);
                final float func_110143_aJ = entityPlayer.func_110143_aJ();
                new StringBuilder().insert(0, " §2[").append(func_110143_aJ).append("] ").toString();
                String str;
                EntityPlayer entityPlayer2;
                if (func_110143_aJ >= 12.0) {
                    str = new StringBuilder().insert(0, " §2[").append(func_110143_aJ).append("] ").toString();
                    entityPlayer2 = entityPlayer;
                }
                else if (func_110143_aJ >= 4.0) {
                    str = new StringBuilder().insert(0, " §6[").append(func_110143_aJ).append("] ").toString();
                    entityPlayer2 = entityPlayer;
                }
                else {
                    str = new StringBuilder().insert(0, " §4[").append(func_110143_aJ).append("] ").toString();
                    entityPlayer2 = entityPlayer;
                }
                l.p.t.H.ALLATORIxDEMO.ALLATORIxDEMO().func_78276_b(new StringBuilder().insert(0, entityPlayer2.func_146103_bH().getName()).append(str).append("§7[").append(i).append("]").toString(), 1, n, new Color(200, 30, 100).getRGB());
                n += 12;
                iterator2 = iterator;
            }
            break;
        }
        super.ALLATORIxDEMO(a);
    }
}
