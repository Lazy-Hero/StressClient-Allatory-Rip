// 
// Decompiled by Procyon v0.5.36
// 

package l.p.l.p;

import java.util.Iterator;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import l.p.t.E;
import net.minecraft.block.Block;
import net.minecraft.client.renderer.GlStateManager;
import org.lwjgl.opengl.GL11;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.tileentity.TileEntityShulkerBox;
import net.minecraftforge.client.event.RenderWorldLastEvent;
import l.p.p.i;
import l.p.l.I;
import l.p.l.H;

public class j extends H
{
    public j() {
        super("ShulkerESP", "pupupipup", I.c);
        l.p.H.g.c.ALLATORIxDEMO(new i("Red", this, 0.1, 0.0, 1.0, false));
        l.p.H.g.c.ALLATORIxDEMO(new i("Green", this, 0.1, 0.0, 1.0, false));
        l.p.H.g.c.ALLATORIxDEMO(new i("Blue", this, 0.1, 0.0, 1.0, false));
        final l.p.p.H c = l.p.H.g.c;
        final String a = "Alpha";
        final double a2 = 0.0;
        final double n = 1.0;
        c.ALLATORIxDEMO(new i(a, this, n, a2, n, false));
    }
    
    @SubscribeEvent
    public void b(RenderWorldLastEvent a) {
        if (this.b()) {
            return;
        }
        a = (RenderWorldLastEvent)j.ALLATORIxDEMO.field_71441_e.field_147482_g.iterator();
    Label_0025:
        while (true) {
            RenderWorldLastEvent renderWorldLastEvent = a;
            while (((Iterator)renderWorldLastEvent).hasNext()) {
                final TileEntity tileEntity;
                if (!((tileEntity = ((Iterator<TileEntity>)a).next()) instanceof TileEntityShulkerBox)) {
                    continue Label_0025;
                }
                l.p.H.g.c.ALLATORIxDEMO(this, "Red").B();
                l.p.H.g.c.ALLATORIxDEMO(this, "Green").B();
                l.p.H.g.c.ALLATORIxDEMO(this, "Blue").B();
                l.p.H.g.c.ALLATORIxDEMO(this, "Alpha").B();
                GL11.glPushAttrib(24580);
                GL11.glDisable(3553);
                GL11.glDisable(2929);
                GL11.glDisable(2896);
                GL11.glEnable(3042);
                GL11.glBlendFunc(770, 771);
                GL11.glEnable(2848);
                GL11.glPushMatrix();
                final float n = 3.0f;
                GL11.glTranslated(tileEntity.func_174877_v().func_177958_n() - j.ALLATORIxDEMO.func_175598_ae().field_78730_l, tileEntity.func_174877_v().func_177956_o() - j.ALLATORIxDEMO.func_175598_ae().field_78731_m, tileEntity.func_174877_v().func_177952_p() - j.ALLATORIxDEMO.func_175598_ae().field_78728_n);
                GlStateManager.func_187441_d(n);
                GL11.glColor4f((float)l.p.H.g.c.ALLATORIxDEMO(this, "Red").B(), (float)l.p.H.g.c.ALLATORIxDEMO(this, "Green").B(), (float)l.p.H.g.c.ALLATORIxDEMO(this, "Blue").B(), (float)l.p.H.g.c.ALLATORIxDEMO(this, "Alpha").B());
                E.b(Block.field_185505_j);
                GL11.glPopMatrix();
                GL11.glPopAttrib();
                GlStateManager.func_179117_G();
                renderWorldLastEvent = a;
            }
            break;
        }
    }
}
