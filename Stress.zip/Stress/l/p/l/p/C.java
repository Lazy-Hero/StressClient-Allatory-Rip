// 
// Decompiled by Procyon v0.5.36
// 

package l.p.l.p;

import l.p.l.I;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent$PlayerTickEvent;
import l.p.l.H;

public class C extends H
{
    @SubscribeEvent
    @Override
    public void ALLATORIxDEMO(final TickEvent$PlayerTickEvent a) {
        l.p.t.H.ALLATORIxDEMO.ALLATORIxDEMO().func_72894_k(0.0f);
    }
    
    public C() {
        super("AntiRain", "Kills Rain", I.c);
    }
}
