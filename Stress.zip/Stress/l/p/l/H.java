// 
// Decompiled by Procyon v0.5.36
// 

package l.p.l;

import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.client.event.RenderGameOverlayEvent$Text;
import net.minecraftforge.client.event.RenderWorldLastEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent$ClientTickEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent$PlayerTickEvent;
import net.minecraft.client.Minecraft;

public class H
{
    protected static Minecraft ALLATORIxDEMO;
    private String h;
    private String B;
    public boolean g;
    private I c;
    private int J;
    private boolean i;
    
    public String b() {
        return this.B;
    }
    
    public void ALLATORIxDEMO(final TickEvent$PlayerTickEvent a) {
    }
    
    public void ALLATORIxDEMO(final boolean a) {
        this.i = a;
        if (this.i) {
            this.b();
            return;
        }
        this.B();
    }
    
    public void ALLATORIxDEMO(final int a) {
        this.J = a;
    }
    
    public String ALLATORIxDEMO() {
        return this.h;
    }
    
    public boolean ALLATORIxDEMO() {
        return this.i;
    }
    
    public boolean ALLATORIxDEMO(final String a) {
        return false;
    }
    
    public void ALLATORIxDEMO() {
        this.i = !this.i;
        if (this.i) {
            this.b();
            return;
        }
        this.B();
    }
    
    public void ALLATORIxDEMO(final TickEvent$ClientTickEvent a) {
    }
    
    public void ALLATORIxDEMO(final RenderWorldLastEvent a) {
    }
    
    public void E() {
    }
    
    static {
        H.ALLATORIxDEMO = Minecraft.func_71410_x();
    }
    
    public void ALLATORIxDEMO(final RenderGameOverlayEvent$Text a) {
    }
    
    public boolean b() {
        return H.ALLATORIxDEMO.field_71439_g == null || H.ALLATORIxDEMO.field_71441_e == null;
    }
    
    public I ALLATORIxDEMO() {
        return this.c;
    }
    
    public H(final String a, final String a, final I a) {
        final boolean i = false;
        final int j = 0;
        final boolean g = true;
        this.g = g;
        this.h = a;
        this.B = a;
        this.J = j;
        this.c = a;
        this.i = i;
    }
    
    public void ALLATORIxDEMO(final String a) {
        this.B = a;
    }
    
    public void b(final boolean a) {
        this.i = a;
    }
    
    public void b() {
        MinecraftForge.EVENT_BUS.register((Object)this);
    }
    
    public int ALLATORIxDEMO() {
        return this.J;
    }
    
    public void B() {
        MinecraftForge.EVENT_BUS.unregister((Object)this);
    }
}
