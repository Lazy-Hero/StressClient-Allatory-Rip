// 
// Decompiled by Procyon v0.5.36
// 

package l.p.l.l;

import l.p.l.I;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent$PlayerTickEvent;
import l.p.l.H;

public class j extends H
{
    @Override
    public void B() {
        if (j.ALLATORIxDEMO.field_71439_g == null) {
            return;
        }
        j.ALLATORIxDEMO.field_71439_g.field_70144_Y = 0.0f;
    }
    
    @SubscribeEvent
    public void b(final TickEvent$PlayerTickEvent a) {
        if (j.ALLATORIxDEMO.field_71439_g == null) {
            return;
        }
        j.ALLATORIxDEMO.field_71439_g.field_70144_Y = 1.0f;
    }
    
    public j() {
        super("NoPush", "", I.i);
    }
}
