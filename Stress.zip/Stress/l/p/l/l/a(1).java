// 
// Decompiled by Procyon v0.5.36
// 

package l.p.l.l;

import l.p.l.I;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraft.client.settings.KeyBinding;
import net.minecraftforge.fml.common.gameevent.TickEvent$PlayerTickEvent;
import l.p.l.H;

public class a extends H
{
    @SubscribeEvent
    @Override
    public void ALLATORIxDEMO(final TickEvent$PlayerTickEvent a) {
        if (this.b()) {
            return;
        }
        KeyBinding.func_74510_a(l.p.t.H.ALLATORIxDEMO.ALLATORIxDEMO().field_74351_w.func_151463_i(), true);
        super.ALLATORIxDEMO(a);
    }
    
    @Override
    public void B() {
        MinecraftForge.EVENT_BUS.unregister((Object)this);
        KeyBinding.func_74510_a(l.p.t.H.ALLATORIxDEMO.ALLATORIxDEMO().field_74351_w.func_151463_i(), false);
        super.B();
    }
    
    public a() {
        super("AutoWalk", "BBBBBBBBBBBBB", I.J);
    }
}
