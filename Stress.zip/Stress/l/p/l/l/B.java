// 
// Decompiled by Procyon v0.5.36
// 

package l.p.l.l;

import l.p.l.I;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraft.network.Packet;
import net.minecraft.network.play.client.CPacketPlayer;
import net.minecraftforge.fml.common.gameevent.TickEvent$PlayerTickEvent;
import l.p.l.H;

public class B extends H
{
    @Override
    public String b() {
        return "Gives you zero damage on fall.";
    }
    
    @SubscribeEvent
    public void b(final TickEvent$PlayerTickEvent a) {
        if (this.b()) {
            return;
        }
        if (!B.ALLATORIxDEMO.field_71439_g.field_70122_E && B.ALLATORIxDEMO.field_71439_g.field_70143_R > 3.0f) {
            B.ALLATORIxDEMO.func_147114_u().func_147297_a((Packet)new CPacketPlayer(true));
        }
    }
    
    public B() {
        super("NoFall", "", I.J);
    }
}
