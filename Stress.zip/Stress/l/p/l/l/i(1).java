// 
// Decompiled by Procyon v0.5.36
// 

package l.p.l.l;

import java.util.Iterator;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent$ClientTickEvent;
import l.p.l.I;
import l.p.l.H;

public class i extends H
{
    public i() {
        super("SelfDestruct", "", I.i);
    }
    
    @SubscribeEvent
    public void b(TickEvent$ClientTickEvent a) {
        i.ALLATORIxDEMO.field_71462_r = null;
        Object o = a = (TickEvent$ClientTickEvent)l.p.H.g.ALLATORIxDEMO.ALLATORIxDEMO().iterator();
        while (((Iterator)o).hasNext()) {
            final H h = ((Iterator<H>)a).next();
            o = a;
            final int a2 = 0;
            final H h2 = h;
            h2.B();
            h2.ALLATORIxDEMO(a2);
        }
        this.B();
    }
}
