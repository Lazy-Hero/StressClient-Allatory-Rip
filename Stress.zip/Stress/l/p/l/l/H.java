// 
// Decompiled by Procyon v0.5.36
// 

package l.p.l.l;

import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent$PlayerTickEvent;
import l.p.p.i;
import l.p.l.I;
import java.util.Random;

public class H extends l.p.l.H
{
    private int ALLATORIxDEMO;
    private String[] i;
    
    public static int ALLATORIxDEMO(final int a, final int a) {
        return new Random().nextInt(a - a + 1) + a;
    }
    
    public H() {
        final int n = 3;
        final int allatorIxDEMO = 0;
        super("Spammer", "", I.i);
        this.ALLATORIxDEMO = allatorIxDEMO;
        final String[] i = new String[n];
        i[0] = "!I'm playing with Stress Client!";
        i[1] = "!Buy Stress Client";
        i[2] = "!You poor bitch, if you don't buy Stress!";
        this.i = i;
        l.p.H.g.c.ALLATORIxDEMO(new i("Speed", this, 150.0, 70.0, 300.0, false));
    }
    
    @SubscribeEvent
    public void b(final TickEvent$PlayerTickEvent a) {
        l.p.H.g.c.ALLATORIxDEMO(this, "Speed").B();
        ++this.ALLATORIxDEMO;
        if (this.ALLATORIxDEMO > (float)l.p.H.g.c.ALLATORIxDEMO(this, "Speed").B()) {
            H.ALLATORIxDEMO.field_71439_g.func_71165_d(this.i[new Random().nextInt(this.i.length)] + " (Stress" + ALLATORIxDEMO(0, 100) + "Client)");
            this.ALLATORIxDEMO = 0;
        }
    }
}
