// 
// Decompiled by Procyon v0.5.36
// 

package l.p.l.l;

import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import java.lang.reflect.Field;
import net.minecraft.entity.Entity;
import net.minecraftforge.fml.common.gameevent.TickEvent$PlayerTickEvent;
import l.p.l.H;

public class I extends H
{
    public I() {
        super("NoWeb", "", l.p.l.I.J);
    }
    
    @SubscribeEvent
    public void b(TickEvent$PlayerTickEvent a) {
        a = (TickEvent$PlayerTickEvent)I.ALLATORIxDEMO.field_71439_g;
        try {
            final Field declaredField = Entity.class.getDeclaredField(l.p.H.ALLATORIxDEMO() ? "isInWeb" : "field_70134_J");
            final TickEvent$PlayerTickEvent obj = a;
            final boolean z = false;
            final Field field = declaredField;
            field.setAccessible(true);
            field.setBoolean(obj, z);
        }
        catch (ReflectiveOperationException ex) {}
    }
    
    @Override
    public void B() {
        MinecraftForge.EVENT_BUS.unregister((Object)this);
    }
    
    @Override
    public void b() {
        MinecraftForge.EVENT_BUS.register((Object)this);
    }
}
