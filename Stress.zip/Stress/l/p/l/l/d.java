// 
// Decompiled by Procyon v0.5.36
// 

package l.p.l.l;

import java.lang.reflect.Field;
import l.p.l.I;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraft.client.Minecraft;
import net.minecraftforge.fml.common.gameevent.TickEvent$PlayerTickEvent;
import l.p.l.H;

public class d extends H
{
    @SubscribeEvent
    public void b(TickEvent$PlayerTickEvent a2) {
        try {
            final TickEvent$PlayerTickEvent tickEvent$PlayerTickEvent = a2 = (TickEvent$PlayerTickEvent)Minecraft.class.getDeclaredField(l.p.H.ALLATORIxDEMO() ? "rightClickDelayTimer" : "field_71467_ac");
            ((Field)tickEvent$PlayerTickEvent).setAccessible(true);
            ((Field)tickEvent$PlayerTickEvent).setInt(d.ALLATORIxDEMO, 0);
        }
        catch (ReflectiveOperationException a2) {}
    }
    
    public d() {
        super("FastPlace", "", I.i);
    }
}
