// 
// Decompiled by Procyon v0.5.36
// 

package l.p.l.l;

import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraft.client.gui.inventory.GuiContainer;
import net.minecraftforge.fml.common.gameevent.TickEvent$ClientTickEvent;
import org.lwjgl.input.Keyboard;
import l.p.l.I;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.util.math.MathHelper;
import l.p.l.H;

public class F extends H
{
    void l(final double a) {
        final float allatorIxDEMO = ALLATORIxDEMO();
        final EntityPlayerSP allatorIxDEMO2 = l.p.t.H.ALLATORIxDEMO.ALLATORIxDEMO();
        allatorIxDEMO2.field_70179_y += MathHelper.func_76126_a(allatorIxDEMO) * a;
        final EntityPlayerSP allatorIxDEMO3 = l.p.t.H.ALLATORIxDEMO.ALLATORIxDEMO();
        allatorIxDEMO3.field_70159_w += MathHelper.func_76134_b(allatorIxDEMO) * a;
    }
    
    public F() {
        super("InventoryWalk", "", I.J);
    }
    
    void b(final double a) {
        final float allatorIxDEMO = ALLATORIxDEMO();
        final EntityPlayerSP allatorIxDEMO2 = l.p.t.H.ALLATORIxDEMO.ALLATORIxDEMO();
        allatorIxDEMO2.field_70179_y -= MathHelper.func_76126_a(allatorIxDEMO) * a;
        final EntityPlayerSP allatorIxDEMO3 = l.p.t.H.ALLATORIxDEMO.ALLATORIxDEMO();
        allatorIxDEMO3.field_70159_w -= MathHelper.func_76134_b(allatorIxDEMO) * a;
    }
    
    void E(final double a) {
        final float allatorIxDEMO = ALLATORIxDEMO();
        final EntityPlayerSP allatorIxDEMO2 = l.p.t.H.ALLATORIxDEMO.ALLATORIxDEMO();
        allatorIxDEMO2.field_70159_w -= MathHelper.func_76126_a(allatorIxDEMO) * a;
        final EntityPlayerSP allatorIxDEMO3 = l.p.t.H.ALLATORIxDEMO.ALLATORIxDEMO();
        allatorIxDEMO3.field_70179_y += MathHelper.func_76134_b(allatorIxDEMO) * a;
    }
    
    void D(final double a) {
        if (!Keyboard.isKeyDown(l.p.t.H.ALLATORIxDEMO.ALLATORIxDEMO().field_74370_x.func_151463_i())) {
            return;
        }
        this.l(a);
    }
    
    void ALLATORIxDEMO(final double a) {
        if (!Keyboard.isKeyDown(l.p.t.H.ALLATORIxDEMO.ALLATORIxDEMO().field_74368_y.func_151463_i())) {
            return;
        }
        this.C(a);
    }
    
    void l() {
        if (l.p.t.H.ALLATORIxDEMO.ALLATORIxDEMO().field_70122_E && Keyboard.isKeyDown(l.p.t.H.ALLATORIxDEMO.ALLATORIxDEMO().field_74314_A.func_151463_i())) {
            l.p.t.H.ALLATORIxDEMO.ALLATORIxDEMO().func_70664_aZ();
        }
    }
    
    @SubscribeEvent
    @Override
    public void ALLATORIxDEMO(final TickEvent$ClientTickEvent a) {
        if (this.b()) {
            return;
        }
        if (!(l.p.t.H.ALLATORIxDEMO.ALLATORIxDEMO().field_71462_r instanceof GuiContainer) && !(l.p.t.H.ALLATORIxDEMO.ALLATORIxDEMO().field_71462_r instanceof l.p.d.H)) {
            return;
        }
        double n = 0.05;
        if (!l.p.t.H.ALLATORIxDEMO.ALLATORIxDEMO().field_70122_E) {
            n /= 4.0;
        }
        final double a2 = n;
        this.l();
        this.a(a2);
        if (!l.p.t.H.ALLATORIxDEMO.ALLATORIxDEMO().field_70122_E) {
            n /= 2.0;
        }
        final double a3 = n;
        final double n2 = n;
        this.ALLATORIxDEMO(n2);
        this.D(n2);
        this.B(a3);
        super.ALLATORIxDEMO(a);
    }
    
    void a(final double a) {
        if (!Keyboard.isKeyDown(l.p.t.H.ALLATORIxDEMO.ALLATORIxDEMO().field_74351_w.func_151463_i())) {
            return;
        }
        this.E(a);
    }
    
    public static float ALLATORIxDEMO() {
        float field_70177_z = l.p.t.H.ALLATORIxDEMO.ALLATORIxDEMO().field_70177_z;
        if (l.p.t.H.ALLATORIxDEMO.ALLATORIxDEMO().field_191988_bg < 0.0f) {
            field_70177_z += 180.0f;
        }
        float n = 1.0f;
        if (l.p.t.H.ALLATORIxDEMO.ALLATORIxDEMO().field_191988_bg < 0.0f) {
            n = -0.5f;
        }
        else if (l.p.t.H.ALLATORIxDEMO.ALLATORIxDEMO().field_191988_bg > 0.0f) {
            n = 0.5f;
        }
        if (l.p.t.H.ALLATORIxDEMO.ALLATORIxDEMO().field_70702_br > 0.0f) {
            field_70177_z -= 90.0f * n;
        }
        if (l.p.t.H.ALLATORIxDEMO.ALLATORIxDEMO().field_70702_br < 0.0f) {
            field_70177_z += 90.0f * n;
        }
        return field_70177_z * 0.017453292f;
    }
    
    void C(final double a) {
        final float allatorIxDEMO = ALLATORIxDEMO();
        final EntityPlayerSP allatorIxDEMO2 = l.p.t.H.ALLATORIxDEMO.ALLATORIxDEMO();
        allatorIxDEMO2.field_70159_w += MathHelper.func_76126_a(allatorIxDEMO) * a;
        final EntityPlayerSP allatorIxDEMO3 = l.p.t.H.ALLATORIxDEMO.ALLATORIxDEMO();
        allatorIxDEMO3.field_70179_y -= MathHelper.func_76134_b(allatorIxDEMO) * a;
    }
    
    void B(final double a) {
        if (!Keyboard.isKeyDown(l.p.t.H.ALLATORIxDEMO.ALLATORIxDEMO().field_74366_z.func_151463_i())) {
            return;
        }
        this.b(a);
    }
}
