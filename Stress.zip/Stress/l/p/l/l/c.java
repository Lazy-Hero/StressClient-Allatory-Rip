// 
// Decompiled by Procyon v0.5.36
// 

package l.p.l.l;

import l.p.l.I;
import java.util.TimerTask;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraft.client.Minecraft;
import net.minecraftforge.client.event.sound.PlaySoundEvent;
import java.util.Timer;
import l.p.l.H;

public class c extends H
{
    private transient Timer ALLATORIxDEMO;
    
    @SubscribeEvent
    public void ALLATORIxDEMO(final PlaySoundEvent a) {
        if (Minecraft.func_71410_x().field_71439_g != null && Minecraft.func_71410_x().field_71439_g.field_71104_cf != null && a.getName().equals("entity.bobber.splash")) {
            final int a2 = 1000;
            this.b(500);
            this.b(a2);
        }
    }
    
    private /* synthetic */ void b(final int a) {
        this.ALLATORIxDEMO.schedule(new g(this), a);
    }
    
    public c() {
        super("Auto Fish", "Catches fish automatically with fishing rod", I.i);
        this.ALLATORIxDEMO = new Timer();
    }
}
