// 
// Decompiled by Procyon v0.5.36
// 

package l.p.l.l;

import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraft.entity.Entity;
import l.p.t.j;
import net.minecraftforge.fml.common.gameevent.TickEvent$PlayerTickEvent;
import net.minecraftforge.common.MinecraftForge;
import l.p.l.I;
import l.p.l.H;

public class A extends H
{
    public A() {
        super("FastLadder", "", I.i);
    }
    
    @Override
    public void b() {
        MinecraftForge.EVENT_BUS.register((Object)this);
    }
    
    @Override
    public void B() {
        MinecraftForge.EVENT_BUS.unregister((Object)this);
    }
    
    @SubscribeEvent
    public void b(TickEvent$PlayerTickEvent a) {
        if (!((EntityPlayerSP)(a = (TickEvent$PlayerTickEvent)A.ALLATORIxDEMO.field_71439_g)).func_70617_f_() || !j.b((Entity)a)) {
            return;
        }
        if (((EntityPlayerSP)a).field_71158_b.field_192832_b == 0.0f && ((EntityPlayerSP)a).field_71158_b.field_78902_a == 0.0f) {
            return;
        }
        if (((EntityPlayerSP)a).field_70181_x < 0.2) {
            ((EntityPlayerSP)a).field_70181_x = 0.2;
        }
    }
}
