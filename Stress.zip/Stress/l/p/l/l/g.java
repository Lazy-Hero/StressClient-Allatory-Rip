// 
// Decompiled by Procyon v0.5.36
// 

package l.p.l.l;

import net.minecraft.client.settings.KeyBinding;
import net.minecraft.client.Minecraft;
import java.util.TimerTask;

class g extends TimerTask
{
    final /* synthetic */ c ALLATORIxDEMO;
    
    g(final c a) {
        this.ALLATORIxDEMO = a;
    }
    
    @Override
    public void run() {
        KeyBinding.func_74507_a(Minecraft.func_71410_x().field_71474_y.field_74313_G.func_151463_i());
    }
}
