// 
// Decompiled by Procyon v0.5.36
// 

package l.p.l.l;

import l.p.l.I;
import net.minecraft.network.play.client.CPacketPlayer;
import net.minecraft.network.play.client.CPacketPlayer$Rotation;
import l.p.l.H;

public class L extends H
{
    @Override
    public void b() {
        if (this.b()) {
            return;
        }
        final l.p.t.H allatorIxDEMO = l.p.t.H.ALLATORIxDEMO;
        final float n = Float.NEGATIVE_INFINITY;
        allatorIxDEMO.ALLATORIxDEMO((CPacketPlayer)new CPacketPlayer$Rotation(n, n, false));
        this.B();
    }
    
    public L() {
        super("kick", "", I.i);
    }
}
