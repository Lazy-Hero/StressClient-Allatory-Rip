// 
// Decompiled by Procyon v0.5.36
// 

package l.p.l.t;

import net.minecraftforge.fml.common.gameevent.TickEvent$PlayerTickEvent;
import l.p.l.I;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraft.client.gui.Gui;
import java.awt.Color;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.Minecraft;
import net.minecraftforge.client.event.RenderGameOverlayEvent$Text;
import net.minecraft.entity.player.EntityPlayer;
import l.p.l.H;

public class L extends H
{
    EntityPlayer ALLATORIxDEMO;
    
    @SubscribeEvent
    public void b(RenderGameOverlayEvent$Text a) {
        a = (RenderGameOverlayEvent$Text)l.p.H.B;
        final float n = 4.5f;
        if (this.ALLATORIxDEMO == null) {
            return;
        }
        final ScaledResolution scaledResolution = new ScaledResolution(Minecraft.func_71410_x());
        final int func_78326_a = scaledResolution.func_78326_a();
        final int func_78328_b = scaledResolution.func_78328_b();
        final int n2 = func_78326_a / 2 - 50;
        final int n3 = func_78328_b - 70;
        final int n4 = func_78326_a / 2 + 50;
        final int n5 = func_78328_b - 110;
        final int n6 = 34;
        Gui.func_73734_a(n2, n3, n4, n5, new Color(n6, n6, n6, 150).getRGB());
        L.ALLATORIxDEMO.field_71466_p.func_175063_a(this.ALLATORIxDEMO.func_146103_bH().getName(), (float)(func_78326_a / 2 - 45), (float)(func_78328_b / 2 + 140), -1);
        L.ALLATORIxDEMO.field_71466_p.func_175063_a((int)this.ALLATORIxDEMO.func_110143_aJ() + "", (float)(func_78326_a / 2 - 45), (float)(func_78328_b / 2 + 155), 558252);
        if (this.ALLATORIxDEMO.func_110143_aJ() == 20.0f) {
            Gui.func_73734_a(func_78326_a / 2 - 45, func_78328_b / 2 + 175, func_78326_a / 2 + 45, func_78328_b / 2 + 167, (int)a);
        }
        if ((int)this.ALLATORIxDEMO.func_110143_aJ() == 24) {
            Gui.func_73734_a(func_78326_a / 2 - 45, func_78328_b / 2 + 175, func_78326_a / 2 + 45, func_78328_b / 2 + 167, (int)a);
        }
        if ((int)this.ALLATORIxDEMO.func_110143_aJ() == 23) {
            Gui.func_73734_a(func_78326_a / 2 - 45, func_78328_b / 2 + 175, func_78326_a / 2 + 45, func_78328_b / 2 + 167, (int)a);
        }
        if ((int)this.ALLATORIxDEMO.func_110143_aJ() == 22) {
            Gui.func_73734_a(func_78326_a / 2 - 45, func_78328_b / 2 + 175, func_78326_a / 2 + 45, func_78328_b / 2 + 167, (int)a);
        }
        if ((int)this.ALLATORIxDEMO.func_110143_aJ() == 21) {
            Gui.func_73734_a(func_78326_a / 2 - 45, func_78328_b / 2 + 175, func_78326_a / 2 + 45, func_78328_b / 2 + 167, (int)a);
        }
        if ((int)this.ALLATORIxDEMO.func_110143_aJ() == 25) {
            Gui.func_73734_a(func_78326_a / 2 - 45, func_78328_b / 2 + 175, func_78326_a / 2 + 45, func_78328_b / 2 + 167, (int)a);
        }
        if ((int)this.ALLATORIxDEMO.func_110143_aJ() == 26) {
            Gui.func_73734_a(func_78326_a / 2 - 45, func_78328_b / 2 + 175, func_78326_a / 2 + 45, func_78328_b / 2 + 167, (int)a);
        }
        if ((int)this.ALLATORIxDEMO.func_110143_aJ() == 27) {
            Gui.func_73734_a(func_78326_a / 2 - 45, func_78328_b / 2 + 175, func_78326_a / 2 + 45, func_78328_b / 2 + 167, (int)a);
        }
        if ((int)this.ALLATORIxDEMO.func_110143_aJ() == 28) {
            Gui.func_73734_a(func_78326_a / 2 - 45, func_78328_b / 2 + 175, func_78326_a / 2 + 45, func_78328_b / 2 + 167, (int)a);
        }
        if ((int)this.ALLATORIxDEMO.func_110143_aJ() == 29) {
            Gui.func_73734_a(func_78326_a / 2 - 45, func_78328_b / 2 + 175, func_78326_a / 2 + 45, func_78328_b / 2 + 167, (int)a);
        }
        if ((int)this.ALLATORIxDEMO.func_110143_aJ() == 30) {
            Gui.func_73734_a(func_78326_a / 2 - 45, func_78328_b / 2 + 175, func_78326_a / 2 + 45, func_78328_b / 2 + 167, (int)a);
        }
        if ((int)this.ALLATORIxDEMO.func_110143_aJ() == 31) {
            Gui.func_73734_a(func_78326_a / 2 - 45, func_78328_b / 2 + 175, func_78326_a / 2 + 45, func_78328_b / 2 + 167, (int)a);
        }
        if ((int)this.ALLATORIxDEMO.func_110143_aJ() == 32) {
            Gui.func_73734_a(func_78326_a / 2 - 45, func_78328_b / 2 + 175, func_78326_a / 2 + 45, func_78328_b / 2 + 167, (int)a);
        }
        if ((int)this.ALLATORIxDEMO.func_110143_aJ() == 33) {
            Gui.func_73734_a(func_78326_a / 2 - 45, func_78328_b / 2 + 175, func_78326_a / 2 + 45, func_78328_b / 2 + 167, (int)a);
        }
        if ((int)this.ALLATORIxDEMO.func_110143_aJ() == 34) {
            Gui.func_73734_a(func_78326_a / 2 - 45, func_78328_b / 2 + 175, func_78326_a / 2 + 45, func_78328_b / 2 + 167, (int)a);
        }
        if ((int)this.ALLATORIxDEMO.func_110143_aJ() == 35) {
            Gui.func_73734_a(func_78326_a / 2 - 45, func_78328_b / 2 + 175, func_78326_a / 2 + 45, func_78328_b / 2 + 167, (int)a);
        }
        if ((int)this.ALLATORIxDEMO.func_110143_aJ() == 36) {
            Gui.func_73734_a(func_78326_a / 2 - 45, func_78328_b / 2 + 175, func_78326_a / 2 + 45, func_78328_b / 2 + 167, (int)a);
        }
        if ((int)this.ALLATORIxDEMO.func_110143_aJ() == 19) {
            Gui.func_73734_a(func_78326_a / 2 - 45, func_78328_b / 2 + 175, (int)(func_78326_a / 2 + (45.0f - n)), func_78328_b / 2 + 167, (int)a);
        }
        if ((int)this.ALLATORIxDEMO.func_110143_aJ() == 18) {
            Gui.func_73734_a(func_78326_a / 2 - 45, func_78328_b / 2 + 175, (int)(func_78326_a / 2 + (45.0f - n - n)), func_78328_b / 2 + 167, (int)a);
        }
        if ((int)this.ALLATORIxDEMO.func_110143_aJ() == 17) {
            Gui.func_73734_a(func_78326_a / 2 - 45, func_78328_b / 2 + 175, (int)(func_78326_a / 2 + (45.0f - n - n - n)), func_78328_b / 2 + 167, (int)a);
        }
        if ((int)this.ALLATORIxDEMO.func_110143_aJ() == 16) {
            Gui.func_73734_a(func_78326_a / 2 - 45, func_78328_b / 2 + 175, (int)(func_78326_a / 2 + (45.0f - n - n - n - n)), func_78328_b / 2 + 167, (int)a);
        }
        if ((int)this.ALLATORIxDEMO.func_110143_aJ() == 15) {
            Gui.func_73734_a(func_78326_a / 2 - 45, func_78328_b / 2 + 175, (int)(func_78326_a / 2 + (45.0f - n - n - n - n - n)), func_78328_b / 2 + 167, (int)a);
        }
        if ((int)this.ALLATORIxDEMO.func_110143_aJ() == 14) {
            Gui.func_73734_a(func_78326_a / 2 - 45, func_78328_b / 2 + 175, (int)(func_78326_a / 2 + (45.0f - n - n - n - n - n - n)), func_78328_b / 2 + 167, (int)a);
        }
        if ((int)this.ALLATORIxDEMO.func_110143_aJ() == 13) {
            Gui.func_73734_a(func_78326_a / 2 - 45, func_78328_b / 2 + 175, (int)(func_78326_a / 2 + (45.0f - n - n - n - n - n - n - n)), func_78328_b / 2 + 167, (int)a);
        }
        if ((int)this.ALLATORIxDEMO.func_110143_aJ() == 12) {
            Gui.func_73734_a(func_78326_a / 2 - 45, func_78328_b / 2 + 175, (int)(func_78326_a / 2 + (45.0f - n - n - n - n - n - n - n - n)), func_78328_b / 2 + 167, (int)a);
        }
        if ((int)this.ALLATORIxDEMO.func_110143_aJ() == 11) {
            Gui.func_73734_a(func_78326_a / 2 - 45, func_78328_b / 2 + 175, (int)(func_78326_a / 2 + (45.0f - n - n - n - n - n - n - n - n - n)), func_78328_b / 2 + 167, (int)a);
        }
        if ((int)this.ALLATORIxDEMO.func_110143_aJ() == 10) {
            Gui.func_73734_a(func_78326_a / 2 - 45, func_78328_b / 2 + 175, (int)(func_78326_a / 2 + (45.0f - n - n - n - n - n - n - n - n - n - n)), func_78328_b / 2 + 167, (int)a);
        }
        if ((int)this.ALLATORIxDEMO.func_110143_aJ() == 9) {
            Gui.func_73734_a(func_78326_a / 2 - 45, func_78328_b / 2 + 175, (int)(func_78326_a / 2 + (45.0f - n - n - n - n - n - n - n - n - n - n - n)), func_78328_b / 2 + 167, (int)a);
        }
        if ((int)this.ALLATORIxDEMO.func_110143_aJ() == 8) {
            Gui.func_73734_a(func_78326_a / 2 - 45, func_78328_b / 2 + 175, (int)(func_78326_a / 2 + (45.0f - n - n - n - n - n - n - n - n - n - n - n - n)), func_78328_b / 2 + 167, (int)a);
        }
        if ((int)this.ALLATORIxDEMO.func_110143_aJ() == 7) {
            Gui.func_73734_a(func_78326_a / 2 - 45, func_78328_b / 2 + 175, (int)(func_78326_a / 2 + (45.0f - n - n - n - n - n - n - n - n - n - n - n - n - n)), func_78328_b / 2 + 167, (int)a);
        }
        if ((int)this.ALLATORIxDEMO.func_110143_aJ() == 6) {
            Gui.func_73734_a(func_78326_a / 2 - 45, func_78328_b / 2 + 175, (int)(func_78326_a / 2 + (45.0f - n - n - n - n - n - n - n - n - n - n - n - n - n - n)), func_78328_b / 2 + 167, (int)a);
        }
        if ((int)this.ALLATORIxDEMO.func_110143_aJ() == 5) {
            Gui.func_73734_a(func_78326_a / 2 - 45, func_78328_b / 2 + 175, (int)(func_78326_a / 2 + (45.0f - n - n - n - n - n - n - n - n - n - n - n - n - n - n - n)), func_78328_b / 2 + 167, (int)a);
        }
        if ((int)this.ALLATORIxDEMO.func_110143_aJ() == 4) {
            Gui.func_73734_a(func_78326_a / 2 - 45, func_78328_b / 2 + 175, (int)(func_78326_a / 2 + (45.0f - n - n - n - n - n - n - n - n - n - n - n - n - n - n - n - n)), func_78328_b / 2 + 167, (int)a);
        }
        if ((int)this.ALLATORIxDEMO.func_110143_aJ() == 3) {
            Gui.func_73734_a(func_78326_a / 2 - 45, func_78328_b / 2 + 175, (int)(func_78326_a / 2 + (45.0f - n - n - n - n - n - n - n - n - n - n - n - n - n - n - n - n - n)), func_78328_b / 2 + 167, (int)a);
        }
        if ((int)this.ALLATORIxDEMO.func_110143_aJ() == 2) {
            Gui.func_73734_a(func_78326_a / 2 - 45, func_78328_b / 2 + 175, (int)(func_78326_a / 2 + (45.0f - n - n - n - n - n - n - n - n - n - n - n - n - n - n - n - n - n - n)), func_78328_b / 2 + 167, (int)a);
        }
        if ((int)this.ALLATORIxDEMO.func_110143_aJ() == 1) {
            Gui.func_73734_a(func_78326_a / 2 - 45, func_78328_b / 2 + 175, (int)(func_78326_a / 2 + (45.0f - n - n - n - n - n - n - n - n - n - n - n - n - n - n - n - n - n - n - n)), func_78328_b / 2 + 167, (int)a);
        }
    }
    
    public L() {
        super("TargetHud", "", I.B);
    }
    
    @SubscribeEvent
    public void b(final TickEvent$PlayerTickEvent a) {
        if (this.b()) {
            return;
        }
        this.ALLATORIxDEMO = (EntityPlayer)L.ALLATORIxDEMO.field_71439_g.func_110144_aD();
    }
}
