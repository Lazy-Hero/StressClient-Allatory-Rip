// 
// Decompiled by Procyon v0.5.36
// 

package l.p.l.t;

import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import java.util.Iterator;
import net.minecraft.util.EnumHand;
import net.minecraft.network.Packet;
import net.minecraft.network.play.client.CPacketUseEntity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraftforge.fml.common.gameevent.TickEvent$Phase;
import net.minecraftforge.fml.common.gameevent.TickEvent$PlayerTickEvent;
import net.minecraftforge.common.MinecraftForge;
import l.p.p.i;
import l.p.l.I;
import net.minecraft.entity.Entity;
import l.p.l.H;

public class g extends H
{
    float i;
    float ALLATORIxDEMO;
    Entity B;
    
    public g() {
        final float i = 0.0f;
        final float allatorIxDEMO = 0.0f;
        final Entity b = null;
        super("KillAura", "", I.B);
        this.B = b;
        this.ALLATORIxDEMO = allatorIxDEMO;
        this.i = i;
        l.p.H.g.c.ALLATORIxDEMO(new i("Range", this, 2.6, 1.9, 5.0, false));
    }
    
    @Override
    public void b() {
        MinecraftForge.EVENT_BUS.register((Object)this);
        this.B = null;
    }
    
    @SubscribeEvent
    public void b(final TickEvent$PlayerTickEvent a) {
        if (a.phase == TickEvent$Phase.START) {
            final Iterator<Entity> iterator = g.ALLATORIxDEMO.field_71441_e.field_72996_f.iterator();
        Label_0025:
            while (true) {
                Iterator<Entity> iterator2 = iterator;
                while (iterator2.hasNext()) {
                    final Entity b = iterator.next();
                    l.p.H.g.c.ALLATORIxDEMO(this, "Range").B();
                    if (!(b instanceof EntityPlayer) || b == g.ALLATORIxDEMO.field_71439_g || g.ALLATORIxDEMO.field_71439_g.func_70032_d(b) > (float)l.p.H.g.c.ALLATORIxDEMO(this, "Range").B()) {
                        continue Label_0025;
                    }
                    iterator2 = iterator;
                    this.B = b;
                }
                break;
            }
        }
        if (this.B != null && g.ALLATORIxDEMO.field_71439_g.func_184825_o(0.0f) == 1.0f && a.phase == TickEvent$Phase.END && !this.B.field_70128_L) {
            g.ALLATORIxDEMO.field_71439_g.field_70177_z = l.p.t.i.ALLATORIxDEMO(this.B)[0];
            g.ALLATORIxDEMO.func_147114_u().func_147297_a((Packet)new CPacketUseEntity(this.B));
            g.ALLATORIxDEMO.field_71439_g.func_184609_a(EnumHand.MAIN_HAND);
            this.B = null;
            g.ALLATORIxDEMO.field_71439_g.func_184821_cY();
        }
    }
    
    @Override
    public void B() {
        MinecraftForge.EVENT_BUS.unregister((Object)this);
        this.B = null;
    }
}
