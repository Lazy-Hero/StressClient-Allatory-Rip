// 
// Decompiled by Procyon v0.5.36
// 

package l.p.l.t;

class E
{
    public float i;
    public float B;
    final /* synthetic */ F ALLATORIxDEMO;
    
    public E(final F a, final float a, final float a) {
        this.ALLATORIxDEMO = a;
        this.B = a;
        this.i = a;
    }
}
