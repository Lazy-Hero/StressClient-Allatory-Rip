// 
// Decompiled by Procyon v0.5.36
// 

package l.p.l.t;

import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraft.client.settings.GameSettings;
import net.minecraft.client.settings.KeyBinding;
import net.minecraftforge.fml.common.gameevent.TickEvent$PlayerTickEvent;
import l.p.l.I;
import l.p.l.H;

public class a extends H
{
    public a() {
        super("AutoShiftTap", "Auto press Shift when you press attack", I.B);
    }
    
    @SubscribeEvent
    public void b(final TickEvent$PlayerTickEvent a) {
        if (this.b()) {
            return;
        }
        try {
            if (a.ALLATORIxDEMO.field_71474_y.field_74312_F.func_151470_d()) {
                KeyBinding.func_74510_a(a.ALLATORIxDEMO.field_71474_y.field_74311_E.func_151463_i(), true);
                return;
            }
            KeyBinding.func_74510_a(a.ALLATORIxDEMO.field_71474_y.field_74311_E.func_151463_i(), GameSettings.func_100015_a(a.ALLATORIxDEMO.field_71474_y.field_74311_E));
        }
        catch (Exception a2) {}
    }
}
