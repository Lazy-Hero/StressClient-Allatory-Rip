// 
// Decompiled by Procyon v0.5.36
// 

package l.p.l.t;

import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import java.util.Iterator;
import net.minecraft.util.EnumHand;
import net.minecraft.network.Packet;
import net.minecraft.network.play.client.CPacketUseEntity;
import net.minecraft.entity.EntityLiving;
import net.minecraftforge.fml.common.gameevent.TickEvent$Phase;
import net.minecraftforge.fml.common.gameevent.TickEvent$PlayerTickEvent;
import l.p.l.I;
import net.minecraftforge.common.MinecraftForge;
import net.minecraft.util.math.MathHelper;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.Entity;
import l.p.l.H;

public class B extends H
{
    Entity ALLATORIxDEMO;
    float i;
    float B;
    
    public float[] ALLATORIxDEMO(Entity a) {
        final Entity entity = a;
        final double n = entity.field_70165_t - l.p.l.t.B.ALLATORIxDEMO.field_71439_g.field_70165_t;
        final double n2 = entity.field_70161_v - l.p.l.t.B.ALLATORIxDEMO.field_71439_g.field_70161_v;
        double n3;
        double n5;
        double n4;
        if (entity instanceof EntityLivingBase) {
            final EntityLivingBase entityLivingBase = (EntityLivingBase)a;
            n3 = entityLivingBase.field_70163_u + entityLivingBase.func_70047_e() - (l.p.l.t.B.ALLATORIxDEMO.field_71439_g.field_70163_u + l.p.l.t.B.ALLATORIxDEMO.field_71439_g.func_70047_e());
            n4 = (n5 = n);
        }
        else {
            n3 = (a.func_174813_aQ().field_72338_b + a.func_174813_aQ().field_72337_e) / 2.0 - (l.p.l.t.B.ALLATORIxDEMO.field_71439_g.field_70163_u + l.p.l.t.B.ALLATORIxDEMO.field_71439_g.func_70047_e());
            n4 = (n5 = n);
        }
        final double n6 = n5 * n4;
        final double n7 = n2;
        final double n8 = MathHelper.func_76133_a(n6 + n7 * n7);
        a = (Entity)((float)(MathHelper.func_181159_b(n2, n) * 57.29577951308232) - 90.0f);
        return new float[] { (float)a, (float)(-(MathHelper.func_181159_b(n3, n8) * 57.29577951308232)) };
    }
    
    @Override
    public void B() {
        MinecraftForge.EVENT_BUS.unregister((Object)this);
        this.ALLATORIxDEMO = null;
    }
    
    public B() {
        final float b = 0.0f;
        final float i = 0.0f;
        final Entity allatorIxDEMO = null;
        super("MobAura", "", I.B);
        this.ALLATORIxDEMO = allatorIxDEMO;
        this.i = i;
        this.B = b;
    }
    
    @Override
    public void b() {
        MinecraftForge.EVENT_BUS.register((Object)this);
        this.ALLATORIxDEMO = null;
    }
    
    @SubscribeEvent
    public void b(final TickEvent$PlayerTickEvent a) {
        if (a.phase == TickEvent$Phase.START) {
            final Iterator<Entity> iterator = l.p.l.t.B.ALLATORIxDEMO.field_71441_e.field_72996_f.iterator();
        Label_0025:
            while (true) {
                Iterator<Entity> iterator2 = iterator;
                while (iterator2.hasNext()) {
                    final Entity allatorIxDEMO;
                    if (!((allatorIxDEMO = iterator.next()) instanceof EntityLiving) || allatorIxDEMO == l.p.l.t.B.ALLATORIxDEMO.field_71439_g || l.p.l.t.B.ALLATORIxDEMO.field_71439_g.func_70032_d(allatorIxDEMO) > 3.0f) {
                        continue Label_0025;
                    }
                    iterator2 = iterator;
                    this.ALLATORIxDEMO = allatorIxDEMO;
                }
                break;
            }
        }
        if (this.ALLATORIxDEMO != null && l.p.l.t.B.ALLATORIxDEMO.field_71439_g.func_184825_o(0.0f) == 1.0f && a.phase == TickEvent$Phase.END && !this.ALLATORIxDEMO.field_70128_L) {
            l.p.l.t.B.ALLATORIxDEMO.field_71439_g.field_70177_z = this.ALLATORIxDEMO(this.ALLATORIxDEMO)[0];
            l.p.l.t.B.ALLATORIxDEMO.func_147114_u().func_147297_a((Packet)new CPacketUseEntity(this.ALLATORIxDEMO));
            l.p.l.t.B.ALLATORIxDEMO.field_71439_g.func_184609_a(EnumHand.MAIN_HAND);
            this.ALLATORIxDEMO = null;
            l.p.l.t.B.ALLATORIxDEMO.field_71439_g.func_184821_cY();
        }
    }
}
