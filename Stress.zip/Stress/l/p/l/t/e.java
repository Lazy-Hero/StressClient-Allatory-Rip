// 
// Decompiled by Procyon v0.5.36
// 

package l.p.l.t;

import java.util.Iterator;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraft.util.text.ITextComponent;
import net.minecraft.util.text.TextComponentString;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraftforge.fml.common.gameevent.TickEvent$ClientTickEvent;
import l.p.l.I;
import l.p.l.H;

public class e extends H
{
    public e() {
        super("AntiBot", "", I.B);
    }
    
    @SubscribeEvent
    public void b(TickEvent$ClientTickEvent a) {
        if (this.b()) {
            return;
        }
        a = (TickEvent$ClientTickEvent)e.ALLATORIxDEMO.field_71441_e.func_72910_y().iterator();
    Label_0025:
        while (true) {
            TickEvent$ClientTickEvent tickEvent$ClientTickEvent = a;
            while (((Iterator)tickEvent$ClientTickEvent).hasNext()) {
                final Entity entity;
                if (!((entity = ((Iterator<Entity>)a).next()) instanceof EntityPlayer) || !entity.func_82150_aj()) {
                    continue Label_0025;
                }
                e.ALLATORIxDEMO.field_71441_e.func_72900_e(entity);
                e.ALLATORIxDEMO.field_71439_g.func_146105_b((ITextComponent)new TextComponentString(new StringBuilder().insert(0, "\u0412§6Bot\u0412§4 ").append(entity.func_70005_c_()).append(" \u0412§6successfuly deleted! \u0412§r").toString()), false);
                tickEvent$ClientTickEvent = a;
            }
            break;
        }
    }
}
