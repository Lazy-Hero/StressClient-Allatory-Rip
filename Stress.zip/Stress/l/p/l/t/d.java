// 
// Decompiled by Procyon v0.5.36
// 

package l.p.l.t;

import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraft.network.play.client.CPacketPlayerTryUseItem;
import net.minecraft.network.Packet;
import net.minecraft.network.play.client.CPacketPlayerDigging;
import net.minecraft.util.math.BlockPos;
import net.minecraft.network.play.client.CPacketPlayerDigging$Action;
import net.minecraft.item.ItemBow;
import net.minecraft.client.Minecraft;
import net.minecraftforge.event.entity.living.LivingEvent$LivingUpdateEvent;
import l.p.p.i;
import l.p.l.I;
import l.p.l.H;

public class d extends H
{
    public d() {
        super("FastBow", "", I.B);
        l.p.H.g.c.ALLATORIxDEMO(new i("speed", this, 3.0, 0.1, 15.0, true));
    }
    
    @SubscribeEvent
    public void ALLATORIxDEMO(LivingEvent$LivingUpdateEvent a) {
        if (d.ALLATORIxDEMO.field_71439_g == null) {
            return;
        }
        a = (LivingEvent$LivingUpdateEvent)Minecraft.func_71410_x();
        final double b = l.p.H.g.c.ALLATORIxDEMO(this, "Speed").B();
        if (((Minecraft)a).field_71439_g.field_71071_by.func_70448_g().func_77973_b() instanceof ItemBow && ((Minecraft)a).field_71439_g.func_184587_cr() && ((Minecraft)a).field_71439_g.func_184612_cw() >= (float)b) {
            final LivingEvent$LivingUpdateEvent livingEvent$LivingUpdateEvent = a;
            ((Minecraft)livingEvent$LivingUpdateEvent).field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketPlayerDigging(CPacketPlayerDigging$Action.RELEASE_USE_ITEM, BlockPos.field_177992_a, ((Minecraft)a).field_71439_g.func_174811_aO()));
            ((Minecraft)livingEvent$LivingUpdateEvent).field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketPlayerTryUseItem(((Minecraft)a).field_71439_g.func_184600_cs()));
            ((Minecraft)livingEvent$LivingUpdateEvent).field_71439_g.func_184597_cx();
        }
    }
}
