// 
// Decompiled by Procyon v0.5.36
// 

package l.p.l.t;

import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraft.client.settings.KeyBinding;
import org.lwjgl.input.Mouse;
import net.minecraftforge.fml.common.gameevent.TickEvent$RenderTickEvent;
import l.p.p.i;
import l.p.l.I;
import io.netty.util.internal.ThreadLocalRandom;
import l.p.l.H;

public class c extends H
{
    private double B;
    private long J;
    private double c;
    private double h;
    private long i;
    private double ALLATORIxDEMO;
    
    private /* synthetic */ void l() {
        this.c = l.p.H.g.c.ALLATORIxDEMO(this, "MinCPS").B();
        this.h = l.p.H.g.c.ALLATORIxDEMO(this, "MaxCPS").B();
        if (this.c >= this.h) {
            this.h = this.c + 1.0;
        }
        this.ALLATORIxDEMO = 1.0 / ThreadLocalRandom.current().nextDouble(this.c - 0.2, this.h);
        this.B = this.ALLATORIxDEMO / ThreadLocalRandom.current().nextDouble(this.c, this.h);
    }
    
    public c() {
        super("AutoClicker", "Automatically clicks when you hold down left click", I.B);
        l.p.H.g.c.ALLATORIxDEMO(new i("MinCPS", this, 8.0, 1.0, 20.0, false));
        l.p.H.g.c.ALLATORIxDEMO(new i("MaxCPS", this, 12.0, 1.0, 20.0, false));
    }
    
    @SubscribeEvent
    public void ALLATORIxDEMO(TickEvent$RenderTickEvent a) {
        if (Mouse.isButtonDown(0)) {
            if (System.currentTimeMillis() - this.i > this.ALLATORIxDEMO * 1000.0) {
                this.i = System.currentTimeMillis();
                if (this.J < this.i) {
                    this.J = this.i;
                }
                KeyBinding.func_74510_a((int)(a = (TickEvent$RenderTickEvent)l.p.l.t.c.ALLATORIxDEMO.field_71474_y.field_74312_F.func_151463_i()), true);
                KeyBinding.func_74507_a((int)a);
                this.l();
                return;
            }
            if (System.currentTimeMillis() - this.J > this.B * 1000.0) {
                KeyBinding.func_74510_a(l.p.l.t.c.ALLATORIxDEMO.field_71474_y.field_74312_F.func_151463_i(), false);
                this.l();
            }
        }
    }
    
    @Override
    public void b() {
        super.b();
        this.l();
    }
}
