// 
// Decompiled by Procyon v0.5.36
// 

package l.p.l.t;

import java.util.ArrayList;
import java.util.List;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import java.util.Iterator;
import net.minecraftforge.fml.common.gameevent.TickEvent$PlayerTickEvent;
import java.lang.reflect.Field;
import l.p.t.e;
import net.minecraft.entity.Entity;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.entity.item.EntityArmorStand;
import net.minecraft.entity.EntityLivingBase;
import l.p.p.i;
import l.p.l.I;
import l.p.l.H;

public class F extends H
{
    public F() {
        super("HitBoxes", "", I.B);
        l.p.H.g.c.ALLATORIxDEMO(new i("Expand", this, 0.1, 0.0, 2.0, false));
    }
    
    public boolean ALLATORIxDEMO(final EntityLivingBase a) {
        return !(a instanceof EntityArmorStand) && !(a instanceof EntityPlayerSP) && a != l.p.t.H.ALLATORIxDEMO.ALLATORIxDEMO();
    }
    
    void ALLATORIxDEMO(final EntityPlayer a, double a) {
        a = (float)a / 2.0f;
        a.func_174826_a(new AxisAlignedBB(a.field_70165_t - a, a.field_70163_u, a.field_70161_v - a, a.field_70165_t + a, a.field_70163_u + a.field_70131_O, a.field_70161_v + a));
    }
    
    public void ALLATORIxDEMO(final Entity a, final int a) {
        try {
            final Field declaredField = Entity.class.getDeclaredField(e.ALLATORIxDEMO);
            declaredField.setAccessible(true);
            declaredField.setInt(a, a);
        }
        catch (Exception ex) {}
    }
    
    public static void ALLATORIxDEMO(final Entity a, final float a, final float a) {
        a.field_70130_N = a;
        a.field_70131_O = a;
    }
    
    public E ALLATORIxDEMO(final Entity a) {
        return new E(this, 0.6f, 1.8f);
    }
    
    @SubscribeEvent
    public void b(final TickEvent$PlayerTickEvent a) {
        final Iterator<EntityPlayer> iterator2;
        Iterator<EntityPlayer> iterator = iterator2 = this.ALLATORIxDEMO().iterator();
        while (iterator.hasNext()) {
            final EntityPlayer a2 = iterator2.next();
            final float n = 0.6f + (float)l.p.H.g.c.ALLATORIxDEMO(this, "Expand").B();
            iterator = iterator2;
            this.ALLATORIxDEMO(a2, n);
        }
        super.ALLATORIxDEMO(a);
    }
    
    public List<EntityPlayer> ALLATORIxDEMO() {
        final ArrayList<EntityPlayer> list = new ArrayList<EntityPlayer>();
        final Iterator<EntityPlayer> iterator2;
        Iterator<EntityPlayer> iterator = iterator2 = F.ALLATORIxDEMO.field_71441_e.func_72910_y().iterator();
        while (iterator.hasNext()) {
            final EntityPlayer next;
            if (!((next = iterator2.next()) instanceof EntityPlayer)) {
                iterator = iterator2;
            }
            else {
                final EntityPlayer a = next;
                if (!this.ALLATORIxDEMO((EntityLivingBase)a)) {
                    iterator = iterator2;
                }
                else {
                    list.add(a);
                    iterator = iterator2;
                }
            }
        }
        return list;
    }
    
    @Override
    public void B() {
        final Iterator<EntityPlayer> iterator2;
        Iterator<EntityPlayer> iterator = iterator2 = this.ALLATORIxDEMO().iterator();
        while (iterator.hasNext()) {
            final EntityPlayer a = iterator2.next();
            iterator = iterator2;
            this.ALLATORIxDEMO(a, 0.6000000238418579 + l.p.H.g.c.ALLATORIxDEMO(this, "Expand").B());
        }
        super.B();
    }
}
