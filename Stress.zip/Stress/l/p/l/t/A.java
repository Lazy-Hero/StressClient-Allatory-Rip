// 
// Decompiled by Procyon v0.5.36
// 

package l.p.l.t;

import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.inventory.ClickType;
import net.minecraftforge.fml.common.gameevent.TickEvent$PlayerTickEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraft.client.gui.FontRenderer;
import java.awt.Color;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraftforge.client.event.RenderGameOverlayEvent$ElementType;
import net.minecraftforge.client.event.RenderGameOverlayEvent;
import net.minecraft.init.Items;
import l.p.p.i;
import l.p.l.I;
import l.p.l.H;

public class A extends H
{
    public A() {
        super("AutoTotem", "RENDER BY GAMEV", I.B);
        l.p.H.g.c.ALLATORIxDEMO(new i("Counter", this, true));
    }
    
    public int B() {
        int n;
        int i = n = 0;
        while (i < 45) {
            if (A.ALLATORIxDEMO.field_71439_g.field_71069_bz.func_75139_a(n).func_75211_c().func_77973_b() == Items.field_190929_cY) {
                return n;
            }
            i = ++n;
        }
        return -1;
    }
    
    @SubscribeEvent
    public void ALLATORIxDEMO(RenderGameOverlayEvent a) {
        if (a.getType() != RenderGameOverlayEvent$ElementType.TEXT || !l.p.H.g.c.ALLATORIxDEMO(this, "Counter").E()) {
            return;
        }
        final ScaledResolution scaledResolution = new ScaledResolution(A.ALLATORIxDEMO);
        a = (RenderGameOverlayEvent)(scaledResolution.func_78326_a() / 2 + 2);
        final int n = scaledResolution.func_78328_b() / 2 + 2;
        final FontRenderer field_71466_p = A.ALLATORIxDEMO.field_71466_p;
        final String value = String.valueOf(this.b());
        final float n2 = (float)a;
        final float n3 = (float)n;
        final int n4 = 255;
        field_71466_p.func_175063_a(value, n2, n3, new Color(n4, n4, n4).getRGB());
    }
    
    public int b() {
        int n = 0;
        int n2;
        int i = n2 = 0;
        while (i < 45) {
            if (A.ALLATORIxDEMO.field_71439_g.field_71069_bz.func_75139_a(n2).func_75211_c().func_77973_b() == Items.field_190929_cY) {
                ++n;
            }
            i = ++n2;
        }
        if (A.ALLATORIxDEMO.field_71439_g.func_184592_cb().func_77973_b() == Items.field_190929_cY) {
            ++n;
        }
        return n;
    }
    
    @SubscribeEvent
    public void b(final TickEvent$PlayerTickEvent a) {
        if (this.b()) {
            return;
        }
        if (A.ALLATORIxDEMO.field_71439_g.func_184592_cb().func_77973_b() != Items.field_190929_cY && this.B() != -1) {
            A.ALLATORIxDEMO.field_71442_b.func_187098_a(0, this.B(), 1, ClickType.PICKUP, (EntityPlayer)A.ALLATORIxDEMO.field_71439_g);
            A.ALLATORIxDEMO.field_71442_b.func_187098_a(0, 45, 1, ClickType.PICKUP, (EntityPlayer)A.ALLATORIxDEMO.field_71439_g);
        }
    }
}
