// 
// Decompiled by Procyon v0.5.36
// 

package l.p.l.t;

import l.p.p.i;
import l.p.l.I;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraftforge.event.entity.living.LivingEvent$LivingUpdateEvent;

public class H extends l.p.l.H
{
    @SubscribeEvent
    public void ALLATORIxDEMO(LivingEvent$LivingUpdateEvent a) {
        a = (LivingEvent$LivingUpdateEvent)(float)l.p.H.g.c.ALLATORIxDEMO(this, "X").B();
        final float n = (float)l.p.H.g.c.ALLATORIxDEMO(this, "Y").B();
        if (H.ALLATORIxDEMO.field_71439_g.field_70737_aN == H.ALLATORIxDEMO.field_71439_g.field_70738_aO && H.ALLATORIxDEMO.field_71439_g.field_70738_aO > 0) {
            final EntityPlayerSP field_71439_g = H.ALLATORIxDEMO.field_71439_g;
            field_71439_g.field_70159_w *= (double)(a / 100.0f);
            final EntityPlayerSP field_71439_g2 = H.ALLATORIxDEMO.field_71439_g;
            field_71439_g2.field_70181_x *= n / 100.0f;
            final EntityPlayerSP field_71439_g3 = H.ALLATORIxDEMO.field_71439_g;
            field_71439_g3.field_70179_y *= (double)(a / 100.0f);
        }
    }
    
    public H() {
        super("Velocity", "Reduces knockback", I.B);
        l.p.H.g.c.ALLATORIxDEMO(new i("X", this, 20.0, 0.0, 100.0, true));
        l.p.H.g.c.ALLATORIxDEMO(new i("Y", this, 60.0, 0.0, 100.0, true));
    }
}
