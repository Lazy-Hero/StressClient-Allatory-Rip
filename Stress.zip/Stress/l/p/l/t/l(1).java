// 
// Decompiled by Procyon v0.5.36
// 

package l.p.l.t;

import l.p.l.I;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import java.util.Iterator;
import l.p.t.i;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraftforge.fml.common.gameevent.TickEvent$Phase;
import net.minecraftforge.fml.common.gameevent.TickEvent$PlayerTickEvent;
import net.minecraft.entity.Entity;
import l.p.l.H;

public class l extends H
{
    Entity ALLATORIxDEMO;
    
    @SubscribeEvent
    public void b(final TickEvent$PlayerTickEvent a) {
        if (this.b()) {
            return;
        }
        if (a.phase == TickEvent$Phase.START) {
            final Iterator<Entity> iterator = l.ALLATORIxDEMO.field_71441_e.field_72996_f.iterator();
        Label_0035:
            while (true) {
                Iterator<Entity> iterator2 = iterator;
                while (iterator2.hasNext()) {
                    final Entity allatorIxDEMO;
                    if (!((allatorIxDEMO = iterator.next()) instanceof EntityPlayer) || allatorIxDEMO == l.ALLATORIxDEMO.field_71439_g || l.ALLATORIxDEMO.field_71439_g.func_70032_d(allatorIxDEMO) > 3.4f) {
                        continue Label_0035;
                    }
                    iterator2 = iterator;
                    this.ALLATORIxDEMO = allatorIxDEMO;
                }
                break;
            }
        }
        if (this.ALLATORIxDEMO != null && l.ALLATORIxDEMO.field_71439_g.func_184825_o(0.0f) == 1.0f && a.phase == TickEvent$Phase.END && !this.ALLATORIxDEMO.field_70128_L) {
            final float[] allatorIxDEMO2 = l.p.t.i.ALLATORIxDEMO(this.ALLATORIxDEMO);
            l.ALLATORIxDEMO.field_71439_g.field_70177_z = allatorIxDEMO2[0];
            l.ALLATORIxDEMO.field_71439_g.field_70125_A = allatorIxDEMO2[1];
            this.ALLATORIxDEMO = null;
        }
    }
    
    @Override
    public void B() {
        MinecraftForge.EVENT_BUS.unregister((Object)this);
        this.ALLATORIxDEMO = null;
    }
    
    public l() {
        final Entity allatorIxDEMO = null;
        super("AimBot", "", I.B);
        this.ALLATORIxDEMO = allatorIxDEMO;
    }
    
    @Override
    public void b() {
        MinecraftForge.EVENT_BUS.register((Object)this);
        this.ALLATORIxDEMO = null;
    }
}
