// 
// Decompiled by Procyon v0.5.36
// 

package l.p.l.t;

import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import java.util.Iterator;
import l.p.t.i;
import net.minecraft.client.settings.KeyBinding;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraftforge.fml.common.gameevent.TickEvent$Phase;
import net.minecraftforge.fml.common.gameevent.TickEvent$PlayerTickEvent;
import net.minecraft.entity.Entity;
import l.p.l.H;

public class I extends H
{
    Entity ALLATORIxDEMO;
    public boolean i;
    
    public I() {
        final boolean i = false;
        final Entity allatorIxDEMO = null;
        super("Target", "", l.p.l.I.B);
        this.ALLATORIxDEMO = allatorIxDEMO;
        this.i = i;
    }
    
    @SubscribeEvent
    public void b(final TickEvent$PlayerTickEvent a) {
        if (this.b()) {
            return;
        }
        if (a.phase == TickEvent$Phase.START) {
            final Iterator<Entity> iterator = I.ALLATORIxDEMO.field_71441_e.field_72996_f.iterator();
        Label_0035:
            while (true) {
                Iterator<Entity> iterator2 = iterator;
                while (iterator2.hasNext()) {
                    final Entity allatorIxDEMO;
                    if (!((allatorIxDEMO = iterator.next()) instanceof EntityPlayer) || allatorIxDEMO == I.ALLATORIxDEMO.field_71439_g || I.ALLATORIxDEMO.field_71439_g.func_70032_d(allatorIxDEMO) > 3.4f) {
                        continue Label_0035;
                    }
                    iterator2 = iterator;
                    this.ALLATORIxDEMO = allatorIxDEMO;
                }
                break;
            }
        }
        if (this.ALLATORIxDEMO == null && !this.i) {
            KeyBinding.func_74510_a(I.ALLATORIxDEMO.field_71474_y.field_74366_z.func_151463_i(), false);
            KeyBinding.func_74510_a(I.ALLATORIxDEMO.field_71474_y.field_74351_w.func_151463_i(), false);
            KeyBinding.func_74510_a(I.ALLATORIxDEMO.field_71474_y.field_74314_A.func_151463_i(), false);
            this.i = true;
        }
        if (this.ALLATORIxDEMO != null && I.ALLATORIxDEMO.field_71439_g.func_184825_o(0.0f) == 1.0f && a.phase == TickEvent$Phase.END && !this.ALLATORIxDEMO.field_70128_L) {
            KeyBinding.func_74510_a(I.ALLATORIxDEMO.field_71474_y.field_74366_z.func_151463_i(), true);
            KeyBinding.func_74510_a(I.ALLATORIxDEMO.field_71474_y.field_74351_w.func_151463_i(), true);
            KeyBinding.func_74510_a(I.ALLATORIxDEMO.field_71474_y.field_74314_A.func_151463_i(), true);
            final float[] allatorIxDEMO2 = l.p.t.i.ALLATORIxDEMO(this.ALLATORIxDEMO);
            I.ALLATORIxDEMO.field_71439_g.field_70177_z = allatorIxDEMO2[0];
            I.ALLATORIxDEMO.field_71439_g.field_70125_A = allatorIxDEMO2[1];
            this.ALLATORIxDEMO = null;
        }
    }
    
    @Override
    public void B() {
        KeyBinding.func_74510_a(I.ALLATORIxDEMO.field_71474_y.field_74366_z.func_151463_i(), false);
        KeyBinding.func_74510_a(I.ALLATORIxDEMO.field_71474_y.field_74351_w.func_151463_i(), false);
        KeyBinding.func_74510_a(I.ALLATORIxDEMO.field_71474_y.field_74314_A.func_151463_i(), false);
        MinecraftForge.EVENT_BUS.unregister((Object)this);
        this.ALLATORIxDEMO = null;
    }
    
    @Override
    public void b() {
        MinecraftForge.EVENT_BUS.register((Object)this);
        this.ALLATORIxDEMO = null;
    }
}
