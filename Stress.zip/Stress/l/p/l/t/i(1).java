// 
// Decompiled by Procyon v0.5.36
// 

package l.p.l.t;

import net.minecraftforge.common.MinecraftForge;
import l.p.l.I;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import l.p.t.M;
import net.minecraft.entity.monster.EntityMob;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.Entity;
import net.minecraft.client.Minecraft;
import net.minecraftforge.fml.common.gameevent.TickEvent$PlayerTickEvent;
import l.p.l.H;

public class i extends H
{
    private transient long ALLATORIxDEMO;
    
    @SubscribeEvent
    public void b(TickEvent$PlayerTickEvent a) {
        final double b = l.p.H.g.c.ALLATORIxDEMO(this, "range").B();
        a = (TickEvent$PlayerTickEvent)Boolean.valueOf(l.p.H.g.c.ALLATORIxDEMO(this, "useCooldown").E());
        final Boolean value = l.p.H.g.c.ALLATORIxDEMO(this, "attackPlayers").E();
        final Boolean value2 = l.p.H.g.c.ALLATORIxDEMO(this, "attackMobs").E();
        final Boolean value3 = l.p.H.g.c.ALLATORIxDEMO(this, "attackAnimals").E();
        if (a) {
            if (Minecraft.func_71410_x().field_71439_g.func_184825_o(0.0f) < 1.0f) {
                return;
            }
        }
        else if (System.currentTimeMillis() - this.ALLATORIxDEMO < 142.85714285714286) {
            return;
        }
        if (Minecraft.func_71410_x().field_71476_x != null) {
            if ((a = (TickEvent$PlayerTickEvent)Minecraft.func_71410_x().field_71476_x.field_72308_g) == null) {
                return;
            }
            if (Minecraft.func_71410_x().field_71439_g.func_70032_d((Entity)a) > b) {
                return;
            }
            if (a instanceof EntityLivingBase && (((Entity)a).field_70128_L || ((EntityLivingBase)a).func_110143_aJ() < 0.0f)) {
                return;
            }
            if (a instanceof EntityPlayer) {
                if (!value) {
                    return;
                }
                final double n = (((Entity)a).field_70177_z + 180.0f) % 360.0f;
                final double n2 = Minecraft.func_71410_x().field_71439_g.field_70177_z % 360.0f;
                if (n < 0.0) {}
                if (n2 < 0.0) {}
                if (a instanceof EntityMob) {
                    if (!value2) {
                        return;
                    }
                }
                else {
                    if (!M.ALLATORIxDEMO((Entity)a)) {
                        return;
                    }
                    if (!value3) {
                        return;
                    }
                }
            }
        }
    }
    
    public i() {
        super("Trigger Bot", "Automatically attacks the entity you're looking at", I.B);
        l.p.H.g.c.ALLATORIxDEMO(new l.p.p.i("range", this, 3.2, 3.0, 5.0, false));
        l.p.H.g.c.ALLATORIxDEMO(new l.p.p.i("useCooldown", this, true));
        l.p.H.g.c.ALLATORIxDEMO(new l.p.p.i("attackPlayers", this, true));
        l.p.H.g.c.ALLATORIxDEMO(new l.p.p.i("attackMobs", this, true));
        l.p.H.g.c.ALLATORIxDEMO(new l.p.p.i("attackAnimals", this, false));
        l.p.H.g.c.ALLATORIxDEMO(new l.p.p.i("attackInvisibleEntities", this, true));
    }
    
    @Override
    public void B() {
        MinecraftForge.EVENT_BUS.unregister((Object)this);
    }
    
    @Override
    public void b() {
        MinecraftForge.EVENT_BUS.register((Object)this);
        this.ALLATORIxDEMO = System.currentTimeMillis();
    }
}
