// 
// Decompiled by Procyon v0.5.36
// 

package l.p.l.d;

import l.p.p.i;
import l.p.l.I;
import java.lang.reflect.Field;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraft.util.Timer;
import net.minecraft.client.Minecraft;
import net.minecraftforge.fml.common.gameevent.TickEvent$PlayerTickEvent;

public class H extends l.p.l.H
{
    @SubscribeEvent
    public void b(TickEvent$PlayerTickEvent a2) {
        final double b = l.p.H.g.c.ALLATORIxDEMO(this, "speed").B();
        try {
            final TickEvent$PlayerTickEvent tickEvent$PlayerTickEvent = a2 = (TickEvent$PlayerTickEvent)Minecraft.class.getDeclaredField(l.p.H.ALLATORIxDEMO() ? "timer" : "field_71428_T");
            ((Field)tickEvent$PlayerTickEvent).setAccessible(true);
            ((Field)tickEvent$PlayerTickEvent).set(H.ALLATORIxDEMO, new Timer((float)(20.0 * b)));
        }
        catch (Exception a2) {}
    }
    
    @Override
    public void B() {
        MinecraftForge.EVENT_BUS.unregister((Object)this);
        try {
            final Field declaredField = Minecraft.class.getDeclaredField(l.p.H.ALLATORIxDEMO() ? "timer" : "field_71428_T");
            declaredField.setAccessible(true);
            declaredField.set(H.ALLATORIxDEMO, new Timer(20.0f));
        }
        catch (Exception ex) {}
    }
    
    public H() {
        super("Timer", "", I.J);
        l.p.H.g.c.ALLATORIxDEMO(new i("speed", this, 1.0, 0.1, 5.0, false));
    }
}
