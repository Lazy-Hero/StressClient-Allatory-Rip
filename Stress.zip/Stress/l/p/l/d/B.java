// 
// Decompiled by Procyon v0.5.36
// 

package l.p.l.d;

import l.p.l.I;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.util.math.MathHelper;
import net.minecraftforge.fml.common.gameevent.TickEvent$PlayerTickEvent;
import l.p.l.H;

public class B extends H
{
    @SubscribeEvent
    public void b(final TickEvent$PlayerTickEvent a) {
        final boolean b = Math.abs(l.p.t.H.ALLATORIxDEMO.ALLATORIxDEMO().field_70759_as - l.p.t.H.ALLATORIxDEMO.ALLATORIxDEMO().field_70177_z) < 90.0f;
        B b2 = null;
        TickEvent$PlayerTickEvent a2 = null;
        Label_0256: {
            if (l.p.t.H.ALLATORIxDEMO.ALLATORIxDEMO().field_191988_bg > 0.0f && l.p.t.H.ALLATORIxDEMO.ALLATORIxDEMO().field_70737_aN < 5) {
                if (l.p.t.H.ALLATORIxDEMO.ALLATORIxDEMO().field_70122_E) {
                    l.p.t.H.ALLATORIxDEMO.ALLATORIxDEMO().func_70664_aZ();
                    l.p.t.H.ALLATORIxDEMO.ALLATORIxDEMO().field_70181_x = 0.2;
                    final float allatorIxDEMO = ALLATORIxDEMO();
                    final EntityPlayerSP allatorIxDEMO2 = l.p.t.H.ALLATORIxDEMO.ALLATORIxDEMO();
                    allatorIxDEMO2.field_70159_w -= MathHelper.func_76126_a(allatorIxDEMO) * 0.2f;
                    final EntityPlayerSP allatorIxDEMO3 = l.p.t.H.ALLATORIxDEMO.ALLATORIxDEMO();
                    allatorIxDEMO3.field_70179_y += MathHelper.func_76134_b(allatorIxDEMO) * 0.2f;
                    b2 = this;
                    a2 = a;
                    break Label_0256;
                }
                final double sqrt = Math.sqrt(l.p.t.H.ALLATORIxDEMO.ALLATORIxDEMO().field_70159_w * l.p.t.H.ALLATORIxDEMO.ALLATORIxDEMO().field_70159_w + l.p.t.H.ALLATORIxDEMO.ALLATORIxDEMO().field_70179_y * l.p.t.H.ALLATORIxDEMO.ALLATORIxDEMO().field_70179_y);
                final double n = b ? 1.0064 : 1.001;
                final double n2 = ALLATORIxDEMO();
                l.p.t.H.ALLATORIxDEMO.ALLATORIxDEMO().field_70159_w = -Math.sin(n2) * n * sqrt;
                l.p.t.H.ALLATORIxDEMO.ALLATORIxDEMO().field_70179_y = Math.cos(n2) * n * sqrt;
            }
            b2 = this;
            a2 = a;
        }
        b2.ALLATORIxDEMO(a2);
    }
    
    public static float ALLATORIxDEMO() {
        float field_70177_z = l.p.t.H.ALLATORIxDEMO.ALLATORIxDEMO().field_70177_z;
        if (l.p.t.H.ALLATORIxDEMO.ALLATORIxDEMO().field_191988_bg < 0.0f) {
            field_70177_z += 180.0f;
        }
        float n = 1.0f;
        if (l.p.t.H.ALLATORIxDEMO.ALLATORIxDEMO().field_191988_bg < 0.0f) {
            n = -0.5f;
        }
        else if (l.p.t.H.ALLATORIxDEMO.ALLATORIxDEMO().field_191988_bg > 0.0f) {
            n = 0.5f;
        }
        if (l.p.t.H.ALLATORIxDEMO.ALLATORIxDEMO().field_70702_br > 0.0f) {
            field_70177_z -= 90.0f * n;
        }
        if (l.p.t.H.ALLATORIxDEMO.ALLATORIxDEMO().field_70702_br < 0.0f) {
            field_70177_z += 90.0f * n;
        }
        return field_70177_z * 0.017453292f;
    }
    
    @Override
    public String b() {
        return "You move faster.";
    }
    
    public B() {
        super("Speed", "", I.J);
    }
}
