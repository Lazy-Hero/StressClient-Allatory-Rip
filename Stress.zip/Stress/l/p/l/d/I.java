// 
// Decompiled by Procyon v0.5.36
// 

package l.p.l.d;

import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraft.client.settings.KeyBinding;
import net.minecraftforge.fml.common.gameevent.TickEvent$PlayerTickEvent;
import l.p.l.H;

public class I extends H
{
    public I() {
        super("Sprint", "Always holds down the sprint key", l.p.l.I.J);
    }
    
    @SubscribeEvent
    @Override
    public void ALLATORIxDEMO(final TickEvent$PlayerTickEvent a) {
        KeyBinding.func_74510_a(I.ALLATORIxDEMO.field_71474_y.field_151444_V.func_151463_i(), true);
    }
    
    @Override
    public void B() {
        super.B();
        KeyBinding.func_74510_a(I.ALLATORIxDEMO.field_71474_y.field_151444_V.func_151463_i(), false);
    }
}
