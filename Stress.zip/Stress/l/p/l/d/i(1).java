// 
// Decompiled by Procyon v0.5.36
// 

package l.p.l.d;

import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent$PlayerTickEvent;
import l.p.l.I;
import l.p.l.H;

public class i extends H
{
    public i() {
        super("Strafe", "", I.J);
    }
    
    @SubscribeEvent
    @Override
    public void ALLATORIxDEMO(final TickEvent$PlayerTickEvent a) {
        if (i.ALLATORIxDEMO.field_71439_g.func_175144_cb() && !i.ALLATORIxDEMO.field_71439_g.func_184218_aH() && (i.ALLATORIxDEMO.field_71439_g.field_71158_b.field_78902_a != 0.0f || i.ALLATORIxDEMO.field_71439_g.field_71158_b.field_192832_b != 0.0f)) {
            i.ALLATORIxDEMO.field_71439_g.func_70031_b(true);
            final double allatorIxDEMO = this.ALLATORIxDEMO();
            i.ALLATORIxDEMO.field_71439_g.field_70159_w = -Math.sin(allatorIxDEMO) * 0.19;
            i.ALLATORIxDEMO.field_71439_g.field_70179_y = Math.cos(allatorIxDEMO) * 0.19;
        }
    }
    
    public double ALLATORIxDEMO() {
        float field_70177_z = i.ALLATORIxDEMO.field_71439_g.field_70177_z;
        float n = 1.0f;
        if (i.ALLATORIxDEMO.field_71439_g.field_191988_bg < 0.0f) {
            field_70177_z += 180.0f;
        }
        if (i.ALLATORIxDEMO.field_71439_g.field_191988_bg < 0.0f) {
            n = -0.51f;
        }
        else if (i.ALLATORIxDEMO.field_71439_g.field_191988_bg > 0.0f) {
            n = 0.51f;
        }
        if (i.ALLATORIxDEMO.field_71439_g.field_70702_br > 0.0f) {
            field_70177_z -= 90.0f * n;
        }
        if (i.ALLATORIxDEMO.field_71439_g.field_70702_br < 0.0f) {
            field_70177_z += 90.0f * n;
        }
        return Math.toRadians(field_70177_z);
    }
}
