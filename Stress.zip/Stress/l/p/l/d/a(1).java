// 
// Decompiled by Procyon v0.5.36
// 

package l.p.l.d;

import l.p.l.I;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraft.client.multiplayer.WorldClient;
import org.lwjgl.input.Keyboard;
import l.p.t.m;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraftforge.fml.common.gameevent.TickEvent$PlayerTickEvent;
import net.minecraft.client.settings.KeyBinding;
import net.minecraft.client.settings.GameSettings;
import net.minecraft.client.Minecraft;
import net.minecraftforge.common.MinecraftForge;
import l.p.l.H;

public class a extends H
{
    @Override
    public void b() {
        MinecraftForge.EVENT_BUS.register((Object)this);
        KeyBinding.func_74510_a(Minecraft.func_71410_x().field_71474_y.field_74311_E.func_151463_i(), GameSettings.func_100015_a(Minecraft.func_71410_x().field_71474_y.field_74311_E));
    }
    
    @SubscribeEvent
    public void b(final TickEvent$PlayerTickEvent a) {
        if (Minecraft.func_71410_x().field_71439_g.field_70122_E && !Minecraft.func_71410_x().field_71474_y.field_74314_A.func_151468_f()) {
            final WorldClient field_71441_e = Minecraft.func_71410_x().field_71441_e;
            final Vec3d func_174791_d = Minecraft.func_71410_x().field_71439_g.func_174791_d();
            final double n = -0.5;
            final double n2 = 0.0;
            if (!m.ALLATORIxDEMO(field_71441_e.func_180495_p(new BlockPos(func_174791_d.func_178787_e(new Vec3d(n2, n, n2)))).func_177230_c())) {
                KeyBinding.func_74510_a(Minecraft.func_71410_x().field_71474_y.field_74311_E.func_151463_i(), true);
                return;
            }
        }
        if (!Keyboard.isKeyDown(Minecraft.func_71410_x().field_71474_y.field_74311_E.func_151463_i())) {
            KeyBinding.func_74510_a(Minecraft.func_71410_x().field_71474_y.field_74311_E.func_151463_i(), false);
        }
    }
    
    @Override
    public void B() {
        MinecraftForge.EVENT_BUS.unregister((Object)this);
        KeyBinding.func_74510_a(Minecraft.func_71410_x().field_71474_y.field_74311_E.func_151463_i(), GameSettings.func_100015_a(Minecraft.func_71410_x().field_71474_y.field_74311_E));
    }
    
    public a() {
        super("Eagle", "Eagle Makes you sneak on edges", I.J);
    }
}
