// 
// Decompiled by Procyon v0.5.36
// 

package l.p.l.d;

import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraft.entity.Entity;
import net.minecraftforge.fml.common.gameevent.TickEvent$PlayerTickEvent;
import l.p.l.I;
import net.minecraftforge.common.MinecraftForge;
import l.p.l.H;

public class j extends H
{
    @Override
    public void b() {
        MinecraftForge.EVENT_BUS.register((Object)this);
    }
    
    public j() {
        super("Spider", "", I.J);
    }
    
    @SubscribeEvent
    public void b(final TickEvent$PlayerTickEvent a) {
        if (!l.p.t.j.b((Entity)j.ALLATORIxDEMO.field_71439_g)) {
            return;
        }
        if (j.ALLATORIxDEMO.field_71439_g.field_70181_x < 0.2) {
            j.ALLATORIxDEMO.field_71439_g.field_70181_x = 0.2;
        }
    }
    
    @Override
    public void B() {
        MinecraftForge.EVENT_BUS.unregister((Object)this);
    }
}
