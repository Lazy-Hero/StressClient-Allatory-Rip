// 
// Decompiled by Procyon v0.5.36
// 

package l.p.l.d;

import l.p.l.I;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent$PlayerTickEvent;
import net.minecraftforge.common.MinecraftForge;
import l.p.l.H;

public class L extends H
{
    float ALLATORIxDEMO;
    
    @Override
    public void B() {
        MinecraftForge.EVENT_BUS.unregister((Object)this);
        L.ALLATORIxDEMO.field_71439_g.field_70138_W = 0.5f;
    }
    
    @SubscribeEvent
    public void b(final TickEvent$PlayerTickEvent a) {
        if (this.b()) {
            return;
        }
        this.ALLATORIxDEMO = L.ALLATORIxDEMO.field_71439_g.field_70138_W;
        L.ALLATORIxDEMO.field_71439_g.field_70138_W = 2.0f;
    }
    
    public L() {
        super("Step", "PUPUPIPUP", I.B);
    }
}
