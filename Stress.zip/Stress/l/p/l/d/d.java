// 
// Decompiled by Procyon v0.5.36
// 

package l.p.l.d;

import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.client.Minecraft;
import net.minecraftforge.fml.common.gameevent.TickEvent$PlayerTickEvent;
import l.p.p.i;
import l.p.l.I;
import l.p.l.H;

public class d extends H
{
    public d() {
        super("Flight", "", I.J);
        final l.p.p.H c = l.p.H.g.c;
        final String a = "speed";
        final double n = 1.0;
        c.ALLATORIxDEMO(new i(a, this, n, n, 10.0, true));
    }
    
    @SubscribeEvent
    public void b(TickEvent$PlayerTickEvent a) {
        if (this.b()) {
            return;
        }
        a = (TickEvent$PlayerTickEvent)Minecraft.func_71410_x().field_71439_g.field_70177_z;
        int n = 0;
        int n2 = 0;
        int n3 = 0;
        if (Minecraft.func_71410_x().field_71474_y.field_74351_w.func_151470_d()) {
            --n3;
        }
        if (Minecraft.func_71410_x().field_71474_y.field_74368_y.func_151470_d()) {
            ++n3;
        }
        if (Minecraft.func_71410_x().field_71474_y.field_74370_x.func_151470_d()) {
            --n;
        }
        if (Minecraft.func_71410_x().field_71474_y.field_74366_z.func_151470_d()) {
            ++n;
        }
        if (Minecraft.func_71410_x().field_71474_y.field_74314_A.func_151470_d()) {
            ++n2;
        }
        if (Minecraft.func_71410_x().field_71474_y.field_74311_E.func_151470_d()) {
            --n2;
        }
        final double b = l.p.H.g.c.ALLATORIxDEMO(this, "Speed").B();
        Minecraft.func_71410_x().field_71439_g.field_70159_w = b * n3 * Math.sin(Math.toRadians((double)a));
        Minecraft.func_71410_x().field_71439_g.field_70179_y = b * n3 * -Math.cos(Math.toRadians((double)a));
        final EntityPlayerSP field_71439_g = Minecraft.func_71410_x().field_71439_g;
        field_71439_g.field_70159_w += b * n * -Math.cos(Math.toRadians((double)a));
        final EntityPlayerSP field_71439_g2 = Minecraft.func_71410_x().field_71439_g;
        field_71439_g2.field_70179_y += b * n * -Math.sin(Math.toRadians((double)a));
        Minecraft.func_71410_x().field_71439_g.field_70181_x = b * n2;
    }
}
