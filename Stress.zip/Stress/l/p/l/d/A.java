// 
// Decompiled by Procyon v0.5.36
// 

package l.p.l.d;

import l.p.l.I;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.client.Minecraft;
import net.minecraftforge.fml.common.gameevent.TickEvent$PlayerTickEvent;
import l.p.l.H;

public class A extends H
{
    @SubscribeEvent
    public void b(TickEvent$PlayerTickEvent a) {
        if (!Minecraft.func_71410_x().field_71439_g.func_184613_cA()) {
            return;
        }
        a = (TickEvent$PlayerTickEvent)Minecraft.func_71410_x().field_71439_g.field_70177_z;
        final float field_70125_A = Minecraft.func_71410_x().field_71439_g.field_70125_A;
        if (Minecraft.func_71410_x().field_71474_y.field_74351_w.func_151470_d()) {
            final EntityPlayerSP field_71439_g = Minecraft.func_71410_x().field_71439_g;
            field_71439_g.field_70159_w -= Math.sin(Math.toRadians((double)a)) * Math.cos(Math.toRadians(field_70125_A)) * 0.05;
            final EntityPlayerSP field_71439_g2 = Minecraft.func_71410_x().field_71439_g;
            field_71439_g2.field_70179_y += Math.cos(Math.toRadians((double)a)) * Math.cos(Math.toRadians(field_70125_A)) * 0.05;
            final EntityPlayerSP field_71439_g3 = Minecraft.func_71410_x().field_71439_g;
            field_71439_g3.field_70181_x += Math.sin(Math.toRadians(field_70125_A)) * 0.05;
        }
        if (Minecraft.func_71410_x().field_71474_y.field_74314_A.func_151470_d()) {
            final EntityPlayerSP field_71439_g4 = Minecraft.func_71410_x().field_71439_g;
            field_71439_g4.field_70181_x += 0.05;
        }
        if (Minecraft.func_71410_x().field_71474_y.field_74311_E.func_151470_d()) {
            final EntityPlayerSP field_71439_g5 = Minecraft.func_71410_x().field_71439_g;
            field_71439_g5.field_70181_x -= 0.05;
        }
    }
    
    public A() {
        super("Elytra Boost", "", I.J);
    }
}
