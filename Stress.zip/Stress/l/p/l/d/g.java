// 
// Decompiled by Procyon v0.5.36
// 

package l.p.l.d;

import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent$PlayerTickEvent;
import l.p.l.I;
import l.p.l.H;

public class g extends H
{
    public g() {
        super("NoSlowDown", "Always holds down the sprint key", I.J);
    }
    
    @SubscribeEvent
    @Override
    public void ALLATORIxDEMO(final TickEvent$PlayerTickEvent a) {
        if (g.ALLATORIxDEMO.field_71439_g.func_184587_cr() && !g.ALLATORIxDEMO.field_71439_g.func_184218_aH() && (g.ALLATORIxDEMO.field_71439_g.field_71158_b.field_78902_a != 0.0f || g.ALLATORIxDEMO.field_71439_g.field_71158_b.field_192832_b != 0.0f)) {
            g.ALLATORIxDEMO.field_71439_g.func_70031_b(true);
            final double allatorIxDEMO = this.ALLATORIxDEMO();
            g.ALLATORIxDEMO.field_71439_g.field_70159_w = -Math.sin(allatorIxDEMO) * 0.25;
            g.ALLATORIxDEMO.field_71439_g.field_70179_y = Math.cos(allatorIxDEMO) * 0.25;
        }
    }
    
    public double ALLATORIxDEMO() {
        float field_70177_z = g.ALLATORIxDEMO.field_71439_g.field_70177_z;
        float n = 1.0f;
        if (g.ALLATORIxDEMO.field_71439_g.field_191988_bg < 0.0f) {
            field_70177_z += 180.0f;
        }
        if (g.ALLATORIxDEMO.field_71439_g.field_191988_bg < 0.0f) {
            n = -0.5f;
        }
        else if (g.ALLATORIxDEMO.field_71439_g.field_191988_bg > 0.0f) {
            n = 0.5f;
        }
        if (g.ALLATORIxDEMO.field_71439_g.field_70702_br > 0.0f) {
            field_70177_z -= 90.0f * n;
        }
        if (g.ALLATORIxDEMO.field_71439_g.field_70702_br < 0.0f) {
            field_70177_z += 90.0f * n;
        }
        return Math.toRadians(field_70177_z);
    }
}
