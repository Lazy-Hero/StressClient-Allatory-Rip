// 
// Decompiled by Procyon v0.5.36
// 

package l.p.l.d;

import l.p.l.I;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.client.multiplayer.WorldClient;
import net.minecraft.entity.Entity;
import net.minecraft.client.Minecraft;
import net.minecraftforge.fml.common.gameevent.TickEvent$PlayerTickEvent;
import l.p.l.H;

public class E extends H
{
    @SubscribeEvent
    public void b(final TickEvent$PlayerTickEvent a) {
        if (E.ALLATORIxDEMO.field_71439_g == null) {
            return;
        }
        if (Minecraft.func_71410_x().field_71439_g.field_70122_E && !Minecraft.func_71410_x().field_71439_g.func_70093_af() && !Minecraft.func_71410_x().field_71474_y.field_74314_A.func_151468_f()) {
            final WorldClient field_71441_e = Minecraft.func_71410_x().field_71441_e;
            final EntityPlayerSP field_71439_g = Minecraft.func_71410_x().field_71439_g;
            final AxisAlignedBB func_174813_aQ = Minecraft.func_71410_x().field_71439_g.func_174813_aQ();
            final double n = -0.5;
            final double n2 = 0.0;
            final AxisAlignedBB func_72317_d = func_174813_aQ.func_72317_d(n2, n, n2);
            final double n3 = 0.0;
            final double n4 = -0.001;
            if (field_71441_e.func_184144_a((Entity)field_71439_g, func_72317_d.func_72321_a(n4, n3, n4)).isEmpty()) {
                Minecraft.func_71410_x().field_71439_g.func_70664_aZ();
            }
        }
    }
    
    public E() {
        super("Parkour", "", I.J);
    }
}
