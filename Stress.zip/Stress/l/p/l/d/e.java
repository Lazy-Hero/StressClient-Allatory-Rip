// 
// Decompiled by Procyon v0.5.36
// 

package l.p.l.d;

import l.p.p.i;
import l.p.l.I;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraftforge.event.entity.living.LivingEvent$LivingUpdateEvent;
import l.p.l.H;

public class e extends H
{
    @SubscribeEvent
    public void ALLATORIxDEMO(LivingEvent$LivingUpdateEvent a) {
        a = (LivingEvent$LivingUpdateEvent)(float)l.p.H.g.c.ALLATORIxDEMO(this, "X").B();
        if (e.ALLATORIxDEMO.field_71439_g.field_70737_aN == e.ALLATORIxDEMO.field_71439_g.field_70738_aO && e.ALLATORIxDEMO.field_71439_g.field_70738_aO > 0) {
            final EntityPlayerSP field_71439_g = e.ALLATORIxDEMO.field_71439_g;
            field_71439_g.field_70159_w *= (double)(a / 50.0f);
            final EntityPlayerSP field_71439_g2 = e.ALLATORIxDEMO.field_71439_g;
            field_71439_g2.field_70181_x *= 1.0;
            final EntityPlayerSP field_71439_g3 = e.ALLATORIxDEMO.field_71439_g;
            field_71439_g3.field_70179_y *= (double)(a / 50.0f);
        }
    }
    
    public e() {
        super("DamageBoost", "", I.J);
        l.p.H.g.c.ALLATORIxDEMO(new i("X", this, 0.0, 4.0, 100.0, true));
    }
}
