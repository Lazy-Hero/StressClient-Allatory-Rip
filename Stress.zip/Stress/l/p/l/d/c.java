// 
// Decompiled by Procyon v0.5.36
// 

package l.p.l.d;

import l.p.p.i;
import l.p.l.I;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraftforge.event.entity.living.LivingEvent$LivingUpdateEvent;
import l.p.l.H;

public class c extends H
{
    @SubscribeEvent
    public void ALLATORIxDEMO(LivingEvent$LivingUpdateEvent a) {
        a = (LivingEvent$LivingUpdateEvent)(float)l.p.H.g.c.ALLATORIxDEMO(this, "Y").B();
        if (c.ALLATORIxDEMO.field_71439_g.field_70737_aN == c.ALLATORIxDEMO.field_71439_g.field_70738_aO && c.ALLATORIxDEMO.field_71439_g.field_70738_aO > 0) {
            final EntityPlayerSP field_71439_g = c.ALLATORIxDEMO.field_71439_g;
            field_71439_g.field_70159_w *= 1.0;
            final EntityPlayerSP field_71439_g2 = c.ALLATORIxDEMO.field_71439_g;
            field_71439_g2.field_70181_x *= (double)(a / 2.35f);
            final EntityPlayerSP field_71439_g3 = c.ALLATORIxDEMO.field_71439_g;
            field_71439_g3.field_70179_y *= 1.0;
        }
    }
    
    public c() {
        super("DamageFly", "", I.B);
        final l.p.p.H c = l.p.H.g.c;
        final String a = "Y";
        final double n = 4.0;
        c.ALLATORIxDEMO(new i(a, this, n, n, 15.0, true));
    }
}
