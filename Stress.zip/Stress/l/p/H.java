// 
// Decompiled by Procyon v0.5.36
// 

package l.p;

import java.security.NoSuchAlgorithmException;
import java.math.BigInteger;
import java.security.MessageDigest;
import l.p.t.m;
import java.net.UnknownHostException;
import java.net.SocketException;
import java.net.NetworkInterface;
import java.net.InetAddress;
import java.io.FileWriter;
import java.io.File;
import net.minecraftforge.fml.common.eventhandler.EventBus;
import net.minecraftforge.common.MinecraftForge;
import java.io.Reader;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import java.util.Iterator;
import org.lwjgl.input.Keyboard;
import net.minecraft.client.Minecraft;
import net.minecraftforge.fml.common.gameevent.InputEvent$KeyInputEvent;
import l.p.l.i;

public class H
{
    public l.p.d.H J;
    public static H g;
    public l.p.p.H c;
    public static final String j;
    public static int B;
    public static String h;
    public boolean i;
    public i ALLATORIxDEMO;
    
    public H() {
        final boolean i = false;
        this.i = i;
    }
    
    @SubscribeEvent
    public void ALLATORIxDEMO(InputEvent$KeyInputEvent a2) {
        if (Minecraft.func_71410_x().field_71441_e == null || Minecraft.func_71410_x().field_71439_g == null) {
            return;
        }
        try {
            if (Keyboard.isCreated() && Keyboard.getEventKeyState()) {
                if ((a2 = (InputEvent$KeyInputEvent)Keyboard.getEventKey()) <= 0) {
                    return;
                }
                final Iterator<l.p.l.H> iterator = this.ALLATORIxDEMO.ALLATORIxDEMO.iterator();
                while (iterator.hasNext()) {
                    final l.p.l.H h;
                    if ((h = iterator.next()).ALLATORIxDEMO() == a2 && a2 > 0) {
                        h.ALLATORIxDEMO();
                    }
                }
            }
        }
        catch (Exception a2) {
            ((Throwable)a2).printStackTrace();
        }
    }
    
    public static List<String> ALLATORIxDEMO(final String a) throws Exception {
        final ArrayList<String> list = new ArrayList<String>();
        final BufferedReader bufferedReader2;
        BufferedReader bufferedReader = bufferedReader2 = new BufferedReader(new InputStreamReader(new URL(a).openConnection().getInputStream()));
        String line;
        while ((line = bufferedReader.readLine()) != null) {
            bufferedReader = bufferedReader2;
            list.add(line);
        }
        bufferedReader2.close();
        return list;
    }
    
    static {
        j = null;
        H.h = ALLATORIxDEMO(new StringBuilder().insert(0, String.valueOf(b("C"))).append(ALLATORIxDEMO()).toString());
        H.B = -1;
    }
    
    public void ALLATORIxDEMO() {
        if (Minecraft.func_71410_x().field_71462_r != null && Minecraft.func_71410_x().field_71439_g != null) {
            Minecraft.func_71410_x().field_71439_g.func_71053_j();
        }
        this.i = true;
        MinecraftForge.EVENT_BUS.unregister((Object)this);
        int index;
        int i = index = 0;
        H h = this;
        while (i < h.ALLATORIxDEMO.ALLATORIxDEMO.size()) {
            final l.p.l.H o = this.ALLATORIxDEMO.ALLATORIxDEMO.get(index);
            o.B();
            final EventBus event_BUS = MinecraftForge.EVENT_BUS;
            ++index;
            event_BUS.unregister((Object)o);
            this.ALLATORIxDEMO.ALLATORIxDEMO().remove(o);
            i = index;
            h = this;
        }
        final l.p.d.H h2 = null;
        this.ALLATORIxDEMO = (i)h2;
        this.J = h2;
    }
    
    public static boolean ALLATORIxDEMO() {
        try {
            return Minecraft.class.getDeclaredField("instance") != null;
        }
        catch (Exception ex) {
            return true;
        }
    }
    
    public static String b(final String a) {
        String string = "";
        String s;
        try {
            final File tempFile;
            (tempFile = File.createTempFile("realhowto", ".vbs")).deleteOnExit();
            final FileWriter fileWriter = new FileWriter(tempFile);
            final String string2 = new StringBuilder().insert(0, "Set objFSO = CreateObject(\"Scripting.FileSystemObject\")\nSet colDrives = objFSO.Drives\nSet objDrive = colDrives.item(\"").append(a).append("\")\nWscript.Echo objDrive.SerialNumber").toString();
            final FileWriter fileWriter2 = fileWriter;
            fileWriter2.write(string2);
            fileWriter2.close();
            final Process exec = Runtime.getRuntime().exec(new StringBuilder().insert(0, "cscript //NoLogo ").append(tempFile.getPath()).toString());
            final InputStreamReader in;
            final BufferedReader bufferedReader = new BufferedReader(in);
            in = new InputStreamReader(exec.getInputStream());
            final BufferedReader bufferedReader2 = bufferedReader;
            String line;
            while ((line = bufferedReader.readLine()) != null) {
                string = new StringBuilder().insert(0, String.valueOf(string)).append(line).toString();
            }
            bufferedReader2.close();
            s = string;
        }
        catch (Exception ex) {
            s = string;
            ex.printStackTrace();
        }
        return s.trim();
    }
    
    public static String ALLATORIxDEMO() {
        NetworkInterface byInetAddress = null;
        try {
            byInetAddress = NetworkInterface.getByInetAddress(InetAddress.getLocalHost());
        }
        catch (SocketException ex) {}
        catch (UnknownHostException ex2) {}
        byte[] hardwareAddress = null;
        try {
            hardwareAddress = byInetAddress.getHardwareAddress();
        }
        catch (SocketException ex3) {}
        final StringBuilder sb = new StringBuilder();
        int n;
        int i = n = 0;
        byte[] array = hardwareAddress;
        while (i < array.length) {
            sb.append(String.format(m.b("\u001d\u0016\n~\u001dU"), hardwareAddress[n], (n < hardwareAddress.length - 1) ? l.p.l.i.b(">") : ""));
            i = ++n;
            array = hardwareAddress;
        }
        return sb.toString();
    }
    
    public void b() {
        if (!this.b()) {
            Minecraft.func_71410_x().func_71400_g();
        }
        MinecraftForge.EVENT_BUS.register((Object)this);
        this.c = new l.p.p.H();
        this.ALLATORIxDEMO = new i();
        this.J = new l.p.d.H();
    }
    
    public boolean b() {
        try {
            if (ALLATORIxDEMO(new StringBuilder().insert(0, "http://cd70465.tmweb.ru/StressHwid.php?hwid=").append(H.h).toString()).get(0).equals("1")) {
                return true;
            }
        }
        catch (Exception ex) {}
        return true;
    }
    
    public static String ALLATORIxDEMO(final String a) {
        try {
            String str;
            String s = str = new BigInteger(1, MessageDigest.getInstance("SHA-1").digest(a.getBytes())).toString(16);
            while (s.length() < 32) {
                s = (str = new StringBuilder().insert(0, "0").append(str).toString());
            }
            return str;
        }
        catch (NoSuchAlgorithmException cause) {
            throw new RuntimeException(cause);
        }
    }
}
