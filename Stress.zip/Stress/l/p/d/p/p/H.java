// 
// Decompiled by Procyon v0.5.36
// 

package l.p.d.p.p;

import l.p.d.p.p.p.I;
import l.p.d.p.p.p.j;
import l.p.d.p.p.p.L;
import java.util.Iterator;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.client.Minecraft;
import org.lwjgl.opengl.GL11;
import net.minecraft.client.gui.Gui;
import java.awt.Color;
import l.p.d.p.i;
import java.util.ArrayList;

public class H extends l.p.d.p.H
{
    public int J;
    private ArrayList<l.p.d.p.H> ALLATORIxDEMO;
    private boolean B;
    public l.p.l.H i;
    public i h;
    public boolean g;
    private int c;
    
    @Override
    public int ALLATORIxDEMO() {
        if (this.g) {
            return 12 * (this.ALLATORIxDEMO.size() + 1);
        }
        return 12;
    }
    
    @Override
    public void ALLATORIxDEMO() {
        final int b = this.h.b();
        final int n = this.h.B() + this.J;
        final int n2 = this.h.b() + this.h.ALLATORIxDEMO();
        final int n3 = this.h.B() + 12 + this.J;
        int n5;
        if (this.B) {
            if (this.i.ALLATORIxDEMO()) {
                final int n4 = 34;
                n5 = new Color(n4, n4, n4, 200).getRGB();
            }
            else {
                final int n6 = 34;
                n5 = new Color(n6, n6, n6, 200).getRGB();
            }
        }
        else if (this.i.ALLATORIxDEMO()) {
            final int n7 = 14;
            final Color color = new Color(n7, n7, n7, 200);
            n5 = color.getRGB();
        }
        else {
            final int n8 = 17;
            final Color color = new Color(n8, n8, n8, 200);
            n5 = color.getRGB();
        }
        Gui.func_73734_a(b, n, n2, n3, n5);
        GL11.glPushMatrix();
        Minecraft.func_71410_x().field_71466_p.func_78276_b(this.i.ALLATORIxDEMO(), this.h.b() + 3, this.h.B() + this.J + 2, this.i.ALLATORIxDEMO() ? l.p.H.B : -1);
        if (this.ALLATORIxDEMO.size() > 2) {
            final FontRenderer field_71466_p = Minecraft.func_71410_x().field_71466_p;
            String s;
            H h;
            if (this.g) {
                s = "-";
                h = this;
            }
            else {
                s = "+";
                h = this;
            }
            field_71466_p.func_78276_b(s, h.h.b() + this.h.ALLATORIxDEMO() - 10 + 2, this.h.B() + this.J + 2, -1);
        }
        GL11.glPopMatrix();
        if (this.g && !this.ALLATORIxDEMO.isEmpty()) {
            final Iterator<l.p.d.p.H> iterator2;
            Iterator<l.p.d.p.H> iterator = iterator2 = this.ALLATORIxDEMO.iterator();
            while (iterator.hasNext()) {
                iterator2.next().ALLATORIxDEMO();
                iterator = iterator2;
            }
            Gui.func_73734_a(this.h.b() + 2, this.h.B() + this.J + 12, this.h.b() + 3, this.h.B() + this.J + (this.ALLATORIxDEMO.size() + 1) * 12, l.p.H.B);
        }
    }
    
    @Override
    public void ALLATORIxDEMO(final int a, final int a) {
        this.B = this.ALLATORIxDEMO(a, a);
        if (!this.ALLATORIxDEMO.isEmpty()) {
            final Iterator<l.p.d.p.H> iterator2;
            Iterator<l.p.d.p.H> iterator = iterator2 = this.ALLATORIxDEMO.iterator();
            while (iterator.hasNext()) {
                iterator2.next().ALLATORIxDEMO(a, a);
                iterator = iterator2;
            }
        }
    }
    
    @Override
    public void ALLATORIxDEMO(final int a, final int a, final int a) {
        final Iterator<l.p.d.p.H> iterator2;
        Iterator<l.p.d.p.H> iterator = iterator2 = this.ALLATORIxDEMO.iterator();
        while (iterator.hasNext()) {
            iterator2.next().ALLATORIxDEMO(a, a, a);
            iterator = iterator2;
        }
    }
    
    public boolean ALLATORIxDEMO(final int a, final int a) {
        return a > this.h.b() && a < this.h.b() + this.h.ALLATORIxDEMO() && a > this.h.B() + this.J && a < this.h.B() + 12 + this.J;
    }
    
    public H(final l.p.l.H a, i a, int a) {
        final int n = a;
        final int c = 12;
        final boolean g = false;
        final int j = a;
        final i h = a;
        this.i = a;
        this.h = h;
        this.J = j;
        this.ALLATORIxDEMO = new ArrayList<l.p.d.p.H>();
        this.g = g;
        this.c = c;
        a = (i)(n + 12);
        if (l.p.H.g.c.ALLATORIxDEMO(a) != null) {
            a = (int)l.p.H.g.c.ALLATORIxDEMO(a).iterator();
        Label_0073:
            while (true) {
                int n2 = a;
                while (((Iterator)n2).hasNext()) {
                    final l.p.p.i a2;
                    if ((a2 = ((Iterator<l.p.p.i>)a).next()).ALLATORIxDEMO()) {
                        this.ALLATORIxDEMO.add(new L(a2, this, a, (int)a));
                        a += (i)12;
                    }
                    if (a2.b()) {
                        this.ALLATORIxDEMO.add(new l.p.d.p.p.p.i(a2, this, (int)a));
                        a += (i)12;
                    }
                    if (!a2.l()) {
                        continue Label_0073;
                    }
                    n2 = a;
                    this.ALLATORIxDEMO.add(new j(a2, this, (int)a));
                    a += (i)12;
                }
                break;
            }
        }
        this.ALLATORIxDEMO.add(new I(this, (int)a));
        this.ALLATORIxDEMO.add(new l.p.d.p.p.p.H(this, a, (int)a));
    }
    
    @Override
    public void ALLATORIxDEMO(int a) {
        this.J = a;
        a = this.J + 12;
        final Iterator<l.p.d.p.H> iterator2;
        Iterator<l.p.d.p.H> iterator = iterator2 = this.ALLATORIxDEMO.iterator();
        while (iterator.hasNext()) {
            iterator2.next().ALLATORIxDEMO(a);
            iterator = iterator2;
            a += 12;
        }
    }
    
    @Override
    public void b(final int a, final int a, final int a) {
        if (this.ALLATORIxDEMO(a, a) && a == 0) {
            this.i.ALLATORIxDEMO();
        }
        if (this.ALLATORIxDEMO(a, a) && a == 1) {
            this.g = !this.g;
            this.h.ALLATORIxDEMO();
        }
        final Iterator<l.p.d.p.H> iterator2;
        Iterator<l.p.d.p.H> iterator = iterator2 = this.ALLATORIxDEMO.iterator();
        while (iterator.hasNext()) {
            iterator2.next().b(a, a, a);
            iterator = iterator2;
        }
    }
    
    @Override
    public void ALLATORIxDEMO(final char a, final int a) {
        final Iterator<l.p.d.p.H> iterator2;
        Iterator<l.p.d.p.H> iterator = iterator2 = this.ALLATORIxDEMO.iterator();
        while (iterator.hasNext()) {
            iterator2.next().ALLATORIxDEMO(a, a);
            iterator = iterator2;
        }
    }
}
