// 
// Decompiled by Procyon v0.5.36
// 

package l.p.d.p.p.p;

import java.math.RoundingMode;
import java.math.BigDecimal;
import net.minecraft.client.Minecraft;
import org.lwjgl.opengl.GL11;
import net.minecraft.client.gui.Gui;
import l.p.d.p.H;

public class i extends H
{
    private double c;
    private boolean ALLATORIxDEMO;
    private int i;
    private boolean B;
    private l.p.d.p.p.H j;
    private int h;
    private l.p.p.i g;
    private int J;
    
    public boolean b(final int a, final int a) {
        return a > this.h && a < this.h + (this.j.h.ALLATORIxDEMO() / 2 + 1) && a > this.i && a < this.i + 12;
    }
    
    public boolean ALLATORIxDEMO(final int a, final int a) {
        return a > this.h + this.j.h.ALLATORIxDEMO() / 2 && a < this.h + this.j.h.ALLATORIxDEMO() && a > this.i && a < this.i + 12;
    }
    
    @Override
    public void ALLATORIxDEMO() {
        Gui.func_73734_a(this.j.h.b() + 2, this.j.h.B() + this.J, this.j.h.b() + this.j.h.ALLATORIxDEMO(), this.j.h.B() + this.J + 12, this.ALLATORIxDEMO ? -14540254 : -15658735);
        final int n = (int)(this.g.B() / this.g.b() * this.j.h.ALLATORIxDEMO());
        Gui.func_73734_a(this.j.h.b() + 2, this.j.h.B() + this.J, this.j.h.b() + (int)this.c, this.j.h.B() + this.J + 12, l.p.H.B);
        Gui.func_73734_a(this.j.h.b(), this.j.h.B() + this.J, this.j.h.b() + 2, this.j.h.B() + this.J + 12, -15658735);
        GL11.glPushMatrix();
        Minecraft.func_71410_x().field_71466_p.func_175063_a(new StringBuilder().insert(0, this.g.b()).append(": ").append(this.g.B()).toString(), (float)(this.j.h.b() + 10), (float)(this.j.h.B() + this.J + 2), -1);
        GL11.glPopMatrix();
    }
    
    @Override
    public void ALLATORIxDEMO(final int a) {
        this.J = a;
    }
    
    @Override
    public void ALLATORIxDEMO(final int a, final int a, final int a) {
        this.B = false;
    }
    
    private static /* synthetic */ double ALLATORIxDEMO(final double a, final int a) {
        if (a < 0) {
            throw new IllegalArgumentException();
        }
        return new BigDecimal(a).setScale(a, RoundingMode.HALF_UP).doubleValue();
    }
    
    public i(final l.p.p.i a, final l.p.d.p.p.H a, final int a) {
        final boolean b = false;
        this.B = b;
        this.g = a;
        this.j = a;
        this.h = a.h.b() + a.h.ALLATORIxDEMO();
        this.i = a.h.B() + a.J;
        this.J = a;
    }
    
    @Override
    public void b(final int a, final int a, final int a) {
        if (this.b(a, a) && a == 0 && this.j.g) {
            this.B = true;
        }
        if (this.ALLATORIxDEMO(a, a) && a == 0 && this.j.g) {
            this.B = true;
        }
    }
    
    @Override
    public void ALLATORIxDEMO(final int a, final int a) {
        this.ALLATORIxDEMO = (this.b(a, a) || this.ALLATORIxDEMO(a, a));
        final int a2 = 88;
        this.i = this.j.h.B() + this.J;
        this.h = this.j.h.b();
        final double n = Math.min(a2, Math.max(0, a - this.h));
        final double allatorIxDEMO = this.g.ALLATORIxDEMO();
        final double b = this.g.b();
        this.c = 88.0 * (this.g.B() - allatorIxDEMO) / (b - allatorIxDEMO);
        if (this.B) {
            if (n == 0.0) {
                this.g.ALLATORIxDEMO(this.g.ALLATORIxDEMO());
                return;
            }
            this.g.ALLATORIxDEMO(ALLATORIxDEMO(n / 88.0 * (b - allatorIxDEMO) + allatorIxDEMO, 2));
        }
    }
}
