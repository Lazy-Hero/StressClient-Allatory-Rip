// 
// Decompiled by Procyon v0.5.36
// 

package l.p.d.p.p.p;

import net.minecraft.client.gui.FontRenderer;
import org.lwjgl.input.Keyboard;
import net.minecraft.client.Minecraft;
import org.lwjgl.opengl.GL11;
import net.minecraft.client.gui.Gui;
import l.p.d.p.H;

public class I extends H
{
    private boolean c;
    private l.p.d.p.p.H i;
    private int h;
    private int ALLATORIxDEMO;
    private int B;
    private boolean J;
    
    @Override
    public void ALLATORIxDEMO() {
        Gui.func_73734_a(this.i.h.b() + 2, this.i.h.B() + this.ALLATORIxDEMO, this.i.h.b() + this.i.h.ALLATORIxDEMO() * 1, this.i.h.B() + this.ALLATORIxDEMO + 12, this.c ? -14540254 : -15658735);
        Gui.func_73734_a(this.i.h.b(), this.i.h.B() + this.ALLATORIxDEMO, this.i.h.b() + 2, this.i.h.B() + this.ALLATORIxDEMO + 12, -15658735);
        GL11.glPushMatrix();
        final FontRenderer field_71466_p = Minecraft.func_71410_x().field_71466_p;
        String string;
        I i;
        if (this.J) {
            string = "Press a key...";
            i = this;
        }
        else {
            string = new StringBuilder().insert(0, "Key: ").append(Keyboard.getKeyName(this.i.i.ALLATORIxDEMO())).toString();
            i = this;
        }
        field_71466_p.func_175063_a(string, (float)(i.i.h.b() + 7), (float)(this.i.h.B() + this.ALLATORIxDEMO + 2), -1);
        GL11.glPopMatrix();
    }
    
    @Override
    public void b(final int a, final int a, final int a) {
        if (this.ALLATORIxDEMO(a, a) && a == 0 && this.i.g) {
            this.J = !this.J;
        }
    }
    
    @Override
    public void ALLATORIxDEMO(final int a) {
        this.ALLATORIxDEMO = a;
    }
    
    public I(final l.p.d.p.p.H a, final int a) {
        this.i = a;
        this.h = a.h.b() + a.h.ALLATORIxDEMO();
        this.B = a.h.B() + a.J;
        this.ALLATORIxDEMO = a;
    }
    
    @Override
    public void ALLATORIxDEMO(final int a, final int a) {
        this.c = this.ALLATORIxDEMO(a, a);
        this.B = this.i.h.B() + this.ALLATORIxDEMO;
        this.h = this.i.h.b();
    }
    
    public boolean ALLATORIxDEMO(final int a, final int a) {
        return a > this.h && a < this.h + 88 && a > this.B && a < this.B + 12;
    }
    
    @Override
    public void ALLATORIxDEMO(final char a, final int a) {
        if (this.J) {
            final boolean j = false;
            this.i.i.ALLATORIxDEMO(a);
            this.J = j;
        }
    }
}
