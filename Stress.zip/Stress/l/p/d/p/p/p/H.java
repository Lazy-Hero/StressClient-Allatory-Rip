// 
// Decompiled by Procyon v0.5.36
// 

package l.p.d.p.p.p;

import net.minecraft.client.Minecraft;
import org.lwjgl.opengl.GL11;
import net.minecraft.client.gui.Gui;

public class H extends l.p.d.p.H
{
    private int ALLATORIxDEMO;
    private l.p.l.H c;
    private int h;
    private int i;
    private boolean J;
    private l.p.d.p.p.H B;
    
    @Override
    public void ALLATORIxDEMO(final int a, final int a) {
        this.J = this.ALLATORIxDEMO(a, a);
        this.h = this.B.h.B() + this.ALLATORIxDEMO;
        this.i = this.B.h.b();
    }
    
    @Override
    public void ALLATORIxDEMO(final int a) {
        this.ALLATORIxDEMO = a;
    }
    
    public boolean ALLATORIxDEMO(final int a, final int a) {
        return a > this.i && a < this.i + 88 && a > this.h && a < this.h + 12;
    }
    
    public H(final l.p.d.p.p.H a, final l.p.l.H a, final int a) {
        this.B = a;
        this.c = a;
        this.i = a.h.b() + a.h.ALLATORIxDEMO();
        this.h = a.h.B() + a.J;
        this.ALLATORIxDEMO = a;
    }
    
    @Override
    public void ALLATORIxDEMO() {
        Gui.func_73734_a(this.B.h.b() + 2, this.B.h.B() + this.ALLATORIxDEMO, this.B.h.b() + this.B.h.ALLATORIxDEMO() * 1, this.B.h.B() + this.ALLATORIxDEMO + 12, this.J ? -14540254 : -15658735);
        Gui.func_73734_a(this.B.h.b(), this.B.h.B() + this.ALLATORIxDEMO, this.B.h.b() + 2, this.B.h.B() + this.ALLATORIxDEMO + 12, -15658735);
        GL11.glPushMatrix();
        Minecraft.func_71410_x().field_71466_p.func_175063_a(new StringBuilder().insert(0, "Visible: ").append(this.c.g).toString(), (float)(this.B.h.b() + 7), (float)(this.B.h.B() + this.ALLATORIxDEMO + 2), -1);
        GL11.glPopMatrix();
    }
    
    @Override
    public void b(final int a, final int a, final int a) {
        if (this.ALLATORIxDEMO(a, a) && a == 0 && this.B.g) {
            this.c.g = !this.c.g;
        }
    }
}
