// 
// Decompiled by Procyon v0.5.36
// 

package l.p.d.p.p.p;

import net.minecraft.client.Minecraft;
import org.lwjgl.opengl.GL11;
import net.minecraft.client.gui.Gui;
import l.p.p.i;
import l.p.d.p.H;

public class L extends H
{
    private i c;
    private int J;
    private int g;
    private int j;
    private int ALLATORIxDEMO;
    private l.p.d.p.p.H B;
    private boolean h;
    private l.p.l.H i;
    
    @Override
    public void ALLATORIxDEMO(final int a) {
        this.J = a;
    }
    
    public L(final i a, final l.p.d.p.p.H a, final l.p.l.H a, final int a) {
        final int g = 0;
        this.c = a;
        this.B = a;
        this.i = a;
        this.ALLATORIxDEMO = a.h.b() + a.h.ALLATORIxDEMO();
        this.j = a.h.B() + a.J;
        this.J = a;
        this.g = g;
    }
    
    @Override
    public void ALLATORIxDEMO(final int a, final int a) {
        this.h = this.ALLATORIxDEMO(a, a);
        this.j = this.B.h.B() + this.J;
        this.ALLATORIxDEMO = this.B.h.b();
    }
    
    @Override
    public void ALLATORIxDEMO() {
        Gui.func_73734_a(this.B.h.b() + 2, this.B.h.B() + this.J, this.B.h.b() + this.B.h.ALLATORIxDEMO() * 1, this.B.h.B() + this.J + 12, this.h ? -14540254 : -15658735);
        Gui.func_73734_a(this.B.h.b(), this.B.h.B() + this.J, this.B.h.b() + 2, this.B.h.B() + this.J + 12, -15658735);
        GL11.glPushMatrix();
        Minecraft.func_71410_x().field_71466_p.func_175063_a(new StringBuilder().insert(0, "Mode: ").append(this.c.ALLATORIxDEMO()).toString(), (float)(this.B.h.b() + 7), (float)(this.B.h.B() + this.J + 2), -1);
        GL11.glPopMatrix();
    }
    
    @Override
    public void b(int a, final int a, final int a) {
        if (this.ALLATORIxDEMO(a, a) && a == 0 && this.B.g) {
            a = this.c.ALLATORIxDEMO().size();
            L l;
            if (this.g + 1 > a) {
                l = this;
                this.g = 0;
            }
            else {
                l = this;
                ++this.g;
            }
            l.c.ALLATORIxDEMO(this.c.ALLATORIxDEMO().get(this.g));
        }
    }
    
    public boolean ALLATORIxDEMO(final int a, final int a) {
        return a > this.ALLATORIxDEMO && a < this.ALLATORIxDEMO + 88 && a > this.j && a < this.j + 12;
    }
}
