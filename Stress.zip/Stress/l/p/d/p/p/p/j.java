// 
// Decompiled by Procyon v0.5.36
// 

package l.p.d.p.p.p;

import net.minecraft.client.Minecraft;
import org.lwjgl.opengl.GL11;
import net.minecraft.client.gui.Gui;
import l.p.p.i;
import l.p.d.p.H;

public class j extends H
{
    private l.p.d.p.p.H ALLATORIxDEMO;
    private boolean J;
    private int i;
    private i c;
    private int h;
    private int B;
    
    public j(final i a, final l.p.d.p.p.H a, final int a) {
        this.c = a;
        this.ALLATORIxDEMO = a;
        this.i = a.h.b() + a.h.ALLATORIxDEMO();
        this.B = a.h.B() + a.J;
        this.h = a;
    }
    
    @Override
    public void ALLATORIxDEMO(final int a, final int a) {
        this.J = this.ALLATORIxDEMO(a, a);
        this.B = this.ALLATORIxDEMO.h.B() + this.h;
        this.i = this.ALLATORIxDEMO.h.b();
    }
    
    @Override
    public void ALLATORIxDEMO() {
        Gui.func_73734_a(this.ALLATORIxDEMO.h.b() + 2, this.ALLATORIxDEMO.h.B() + this.h, this.ALLATORIxDEMO.h.b() + this.ALLATORIxDEMO.h.ALLATORIxDEMO() * 1, this.ALLATORIxDEMO.h.B() + this.h + 12, this.J ? -14540254 : -15658735);
        Gui.func_73734_a(this.ALLATORIxDEMO.h.b(), this.ALLATORIxDEMO.h.B() + this.h, this.ALLATORIxDEMO.h.b() + 2, this.ALLATORIxDEMO.h.B() + this.h + 12, -15658735);
        GL11.glPushMatrix();
        Minecraft.func_71410_x().field_71466_p.func_175063_a(this.c.b(), (float)(this.ALLATORIxDEMO.h.b() + 10 + 4), (float)(this.ALLATORIxDEMO.h.B() + this.h + 2), -1);
        GL11.glPopMatrix();
        Gui.func_73734_a(this.ALLATORIxDEMO.h.b() + 3 + 4, this.ALLATORIxDEMO.h.B() + this.h + 3, this.ALLATORIxDEMO.h.b() + 9 + 4, this.ALLATORIxDEMO.h.B() + this.h + 9, -6710887);
        if (this.c.E()) {
            Gui.func_73734_a(this.ALLATORIxDEMO.h.b() + 4 + 4, this.ALLATORIxDEMO.h.B() + this.h + 4, this.ALLATORIxDEMO.h.b() + 8 + 4, this.ALLATORIxDEMO.h.B() + this.h + 8, l.p.H.B);
        }
    }
    
    @Override
    public void b(final int a, final int a, final int a) {
        if (this.ALLATORIxDEMO(a, a) && a == 0 && this.ALLATORIxDEMO.g) {
            this.c.ALLATORIxDEMO(!this.c.E());
        }
    }
    
    @Override
    public void ALLATORIxDEMO(final int a) {
        this.h = a;
    }
    
    public boolean ALLATORIxDEMO(final int a, final int a) {
        return a > this.i && a < this.i + 88 && a > this.B && a < this.B + 12;
    }
}
