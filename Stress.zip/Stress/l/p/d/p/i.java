// 
// Decompiled by Procyon v0.5.36
// 

package l.p.d.p;

import java.util.Iterator;
import org.lwjgl.opengl.GL11;
import net.minecraft.client.gui.Gui;
import java.awt.Color;
import net.minecraft.client.gui.FontRenderer;
import java.util.ArrayList;
import l.p.l.I;

public class i
{
    public I h;
    public ArrayList<H> g;
    public int B;
    private int i;
    private boolean J;
    private int F;
    private boolean ALLATORIxDEMO;
    private int j;
    public int A;
    private int c;
    
    public int b() {
        return this.F;
    }
    
    public boolean ALLATORIxDEMO() {
        return this.J;
    }
    
    public void b(final int a) {
        this.i = a;
    }
    
    public void ALLATORIxDEMO(final int a) {
        this.F = a;
    }
    
    public void ALLATORIxDEMO(FontRenderer a) {
        final int b = l.p.H.B;
        final int n = this.F + 2;
        final int n2 = this.i - 1;
        final int n3 = this.F + this.j - 2;
        final int i = this.i;
        final int r = 40;
        final int n4 = 30;
        Gui.func_73734_a(n, n2, n3, i, new Color(r, n4, n4).getRGB());
        final int f = this.F;
        final int j = this.i;
        final int n5 = this.F + this.j;
        final int n6 = this.i + this.c;
        final int r2 = 40;
        final int n7 = 30;
        Gui.func_73734_a(f, j, n5, n6, new Color(r2, n7, n7).getRGB());
        if (!this.J) {
            final int f2 = this.F;
            final int n8 = this.i + this.c;
            final int n9 = this.F + this.j;
            final int n10 = this.i + this.c + 1;
            final int r3 = 40;
            final int n11 = 30;
            Gui.func_73734_a(f2, n8, n9, n10, new Color(r3, n11, n11).getRGB());
            final int n12 = this.F + 2;
            final int n13 = this.i + this.c + 1;
            final int n14 = this.F + this.j - 2;
            final int n15 = this.i + this.c + 2;
            final int r4 = 40;
            final int n16 = 30;
            Gui.func_73734_a(n12, n13, n14, n15, new Color(r4, n16, n16).getRGB());
        }
        GL11.glPushMatrix();
        final FontRenderer fontRenderer = a;
        fontRenderer.func_175063_a(this.h.name(), (float)(this.F + 2), this.i + 2.5f, b);
        String s;
        i k;
        if (this.J) {
            s = "-";
            k = this;
        }
        else {
            s = "+";
            k = this;
        }
        fontRenderer.func_175063_a(s, (float)(k.F + this.j - 10), this.i + 2.5f, b);
        GL11.glPopMatrix();
        if (this.J && !this.g.isEmpty()) {
            Object o = a = (FontRenderer)this.g.iterator();
            while (((Iterator)o).hasNext()) {
                final H h = ((Iterator<H>)a).next();
                o = a;
                h.ALLATORIxDEMO();
            }
            a = (FontRenderer)0;
            final Iterator<H> iterator2;
            Iterator<H> iterator = iterator2 = this.ALLATORIxDEMO().iterator();
            while (iterator.hasNext()) {
                a += (FontRenderer)iterator2.next().ALLATORIxDEMO();
                iterator = iterator2;
            }
            Gui.func_73734_a(this.F, (int)(this.i + this.c + a), this.F + this.j, (int)(this.i + this.c + 1 + a), b);
            final int n17 = this.F + 2;
            final i l = this;
            Gui.func_73734_a(n17, (int)(l.i + l.c + a + 1), this.F + this.j - 2, (int)(this.i + this.c + 2 + a), b);
            Gui.func_73734_a(this.F, this.i + this.c, this.F + 1, (int)(this.i + this.c + a), b);
            final int n18 = this.F + this.j - 1;
            final i m = this;
            Gui.func_73734_a(n18, m.i + m.c, this.F + this.j, (int)(this.i + this.c + a), b);
        }
    }
    
    public boolean ALLATORIxDEMO(final int a, final int a) {
        return a >= this.F && a <= this.F + this.j && a >= this.i && a <= this.i + this.c;
    }
    
    public void ALLATORIxDEMO(final int a, final int a) {
        if (this.ALLATORIxDEMO) {
            this.ALLATORIxDEMO(a - this.A);
            this.b(a - this.B);
        }
    }
    
    public void ALLATORIxDEMO() {
        int c = this.c;
        final Iterator<H> iterator2;
        Iterator<H> iterator = iterator2 = this.g.iterator();
        while (iterator.hasNext()) {
            final H h = iterator2.next();
            iterator = iterator2;
            final H h2 = h;
            final int a = c;
            h2.ALLATORIxDEMO(a);
            c = a + h.ALLATORIxDEMO();
        }
    }
    
    public void ALLATORIxDEMO(final boolean a) {
        this.J = a;
    }
    
    public void b(final boolean a) {
        this.ALLATORIxDEMO = a;
    }
    
    public ArrayList<H> ALLATORIxDEMO() {
        return this.g;
    }
    
    public int B() {
        return this.i;
    }
    
    public i(I a) {
        final boolean allatorIxDEMO = false;
        final boolean b = false;
        final int c = 13;
        final int i = 5;
        final int f = 5;
        final int j = 90;
        final I h = a;
        this.g = new ArrayList<H>();
        this.h = h;
        this.j = j;
        this.F = f;
        this.i = i;
        this.c = c;
        this.A = (b ? 1 : 0);
        this.J = b;
        this.ALLATORIxDEMO = allatorIxDEMO;
        a = (I)this.c;
        final Iterator<l.p.l.H> iterator2;
        Iterator<l.p.l.H> iterator = iterator2 = l.p.H.g.ALLATORIxDEMO.ALLATORIxDEMO(this.h).iterator();
        while (iterator.hasNext()) {
            final l.p.d.p.p.H h2 = new l.p.d.p.p.H(iterator2.next(), this, (int)a);
            a += (I)12;
            final l.p.d.p.p.H e = h2;
            iterator = iterator2;
            this.g.add(e);
        }
    }
    
    public int ALLATORIxDEMO() {
        return this.j;
    }
}
