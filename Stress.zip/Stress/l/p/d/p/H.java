// 
// Decompiled by Procyon v0.5.36
// 

package l.p.d.p;

public class H
{
    public void ALLATORIxDEMO(final char a, final int a) {
    }
    
    public void ALLATORIxDEMO(final int a, final int a, final int a) {
    }
    
    public void ALLATORIxDEMO(final int a) {
    }
    
    public void ALLATORIxDEMO() {
    }
    
    public int ALLATORIxDEMO() {
        return 0;
    }
    
    public int b() {
        return 0;
    }
    
    public void b(final int a, final int a, final int a) {
    }
    
    public void ALLATORIxDEMO(final int a, final int a) {
    }
}
