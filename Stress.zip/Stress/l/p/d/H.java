// 
// Decompiled by Procyon v0.5.36
// 

package l.p.d;

import l.p.t.B;
import l.p.l.I;
import java.io.IOException;
import java.util.Iterator;
import l.p.d.p.i;
import java.util.ArrayList;
import net.minecraft.client.gui.GuiScreen;

public class H extends GuiScreen
{
    public static ArrayList<i> ALLATORIxDEMO;
    public static int i;
    
    public void func_73866_w_() {
    }
    
    protected void func_73864_a(final int a, final int a, final int a) throws IOException {
        final Iterator<i> iterator = H.ALLATORIxDEMO.iterator();
        while (iterator.hasNext()) {
            final i i;
            if ((i = iterator.next()).ALLATORIxDEMO(a, a) && a == 0) {
                final i j = i;
                j.b(true);
                j.A = a - j.b();
                final i k = i;
                k.B = a - k.B();
            }
            if (i.ALLATORIxDEMO(a, a) && a == 1) {
                final i l = i;
                l.ALLATORIxDEMO(!l.ALLATORIxDEMO());
            }
            if (i.ALLATORIxDEMO() && !i.ALLATORIxDEMO().isEmpty()) {
                final Iterator<l.p.d.p.H> iterator3;
                Iterator<l.p.d.p.H> iterator2 = iterator3 = i.ALLATORIxDEMO().iterator();
                while (iterator2.hasNext()) {
                    iterator3.next().b(a, a, a);
                    iterator2 = iterator3;
                }
            }
        }
    }
    
    protected void func_146286_b(final int a, final int a, final int a) {
        final Iterator<i> iterator2;
        Iterator<i> iterator = iterator2 = H.ALLATORIxDEMO.iterator();
        while (iterator.hasNext()) {
            final i i = iterator2.next();
            iterator = iterator2;
            i.b(false);
        }
        final Iterator<i> iterator3 = H.ALLATORIxDEMO.iterator();
        while (iterator3.hasNext()) {
            final i j;
            if ((j = iterator3.next()).ALLATORIxDEMO() && !j.ALLATORIxDEMO().isEmpty()) {
                final Iterator<l.p.d.p.H> iterator5;
                Iterator<l.p.d.p.H> iterator4 = iterator5 = j.ALLATORIxDEMO().iterator();
                while (iterator4.hasNext()) {
                    iterator5.next().ALLATORIxDEMO(a, a, a);
                    iterator4 = iterator5;
                }
            }
        }
    }
    
    public boolean func_73868_f() {
        return true;
    }
    
    protected void func_73869_a(final char a, final int a) {
        final Iterator<i> iterator = H.ALLATORIxDEMO.iterator();
        while (iterator.hasNext()) {
            final i i;
            if ((i = iterator.next()).ALLATORIxDEMO() && a != 1 && !i.ALLATORIxDEMO().isEmpty()) {
                final Iterator<l.p.d.p.H> iterator3;
                Iterator<l.p.d.p.H> iterator2 = iterator3 = i.ALLATORIxDEMO().iterator();
                while (iterator2.hasNext()) {
                    iterator3.next().ALLATORIxDEMO(a, a);
                    iterator2 = iterator3;
                }
            }
        }
        if (a == 1) {
            this.field_146297_k.func_147108_a((GuiScreen)null);
        }
    }
    
    public H() {
        final int n = 5;
        H.ALLATORIxDEMO = new ArrayList<i>();
        int a = n;
        final I[] values;
        final int length = (values = I.values()).length;
        int n2;
        int i = n2 = 0;
        int n3 = length;
        while (i < n3) {
            final i e;
            (e = new i(values[n2])).ALLATORIxDEMO(a);
            H.ALLATORIxDEMO.add(e);
            final int n4 = a;
            ++n2;
            a = n4 + (e.ALLATORIxDEMO() + 1);
            i = n2;
            n3 = length;
        }
    }
    
    public void func_73863_a(final int a, final int a, float a) {
        l.p.H.B = B.ALLATORIxDEMO(30000, 0);
        a = (float)H.ALLATORIxDEMO.iterator();
        while (((Iterator)a).hasNext()) {
            final i i = ((Iterator<i>)a).next();
            i.ALLATORIxDEMO(this.field_146289_q);
            i.ALLATORIxDEMO(a, a);
            final Iterator<l.p.d.p.H> iterator2;
            Iterator<l.p.d.p.H> iterator = iterator2 = i.ALLATORIxDEMO().iterator();
            while (iterator.hasNext()) {
                iterator2.next().ALLATORIxDEMO(a, a);
                iterator = iterator2;
            }
        }
    }
    
    static {
        H.i = -1;
    }
}
