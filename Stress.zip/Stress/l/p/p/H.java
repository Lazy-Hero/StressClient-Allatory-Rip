// 
// Decompiled by Procyon v0.5.36
// 

package l.p.p;

import java.util.Iterator;
import java.util.ArrayList;

public class H
{
    private ArrayList<i> ALLATORIxDEMO;
    
    public i ALLATORIxDEMO(final l.p.l.H a, final String a) {
        final Iterator<i> iterator = this.ALLATORIxDEMO().iterator();
        while (iterator.hasNext()) {
            final i i;
            if ((i = iterator.next()).b().equalsIgnoreCase(a) && i.ALLATORIxDEMO() == a) {
                return i;
            }
        }
        System.err.println(new StringBuilder().insert(0, "[Tutorial] Error Setting NOT found: '").append(a).append("'!").toString());
        return null;
    }
    
    public ArrayList<i> ALLATORIxDEMO(final l.p.l.H a) {
        final ArrayList<i> list = new ArrayList<i>();
        final Iterator<i> iterator = this.ALLATORIxDEMO().iterator();
    Label_0016:
        while (true) {
            Iterator<i> iterator2 = iterator;
            while (iterator2.hasNext()) {
                final i e;
                if (!(e = iterator.next()).ALLATORIxDEMO().equals(a)) {
                    continue Label_0016;
                }
                iterator2 = iterator;
                list.add(e);
            }
            break;
        }
        if (list.isEmpty()) {
            return null;
        }
        return list;
    }
    
    public ArrayList<i> ALLATORIxDEMO() {
        return this.ALLATORIxDEMO;
    }
    
    public void ALLATORIxDEMO(final i a) {
        this.ALLATORIxDEMO.add(a);
    }
    
    public H() {
        this.ALLATORIxDEMO = new ArrayList<i>();
    }
}
