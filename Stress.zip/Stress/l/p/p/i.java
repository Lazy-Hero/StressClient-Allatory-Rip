// 
// Decompiled by Procyon v0.5.36
// 

package l.p.p;

import l.p.l.H;
import java.util.ArrayList;

public class i
{
    private double i;
    private boolean F;
    private ArrayList<String> g;
    private double j;
    private String J;
    private double h;
    private String c;
    private boolean ALLATORIxDEMO;
    private H A;
    private String B;
    
    public double b() {
        return this.i;
    }
    
    public double B() {
        if (this.F) {
            this.h = (int)this.h;
        }
        return this.h;
    }
    
    public void ALLATORIxDEMO(final boolean a) {
        this.ALLATORIxDEMO = a;
    }
    
    public double ALLATORIxDEMO() {
        return this.j;
    }
    
    public String b() {
        return this.B;
    }
    
    public void ALLATORIxDEMO(final String a) {
        this.J = a;
    }
    
    public boolean l() {
        return this.c.equalsIgnoreCase("Check");
    }
    
    public i(final String a, final H a, final double a, final double a, final double a, final boolean a) {
        final String c = "Slider";
        final boolean f = false;
        this.F = f;
        this.B = a;
        this.A = a;
        this.h = a;
        this.j = a;
        this.i = a;
        this.F = a;
        this.c = c;
    }
    
    public boolean B() {
        return this.F;
    }
    
    public i(final String a, final H a, final boolean a) {
        final String c = "Check";
        final boolean f = false;
        this.F = f;
        this.B = a;
        this.A = a;
        this.ALLATORIxDEMO = a;
        this.c = c;
    }
    
    public i(final String a, final H a, final String a, final ArrayList<String> a) {
        final String c = "Combo";
        final boolean f = false;
        this.F = f;
        this.B = a;
        this.A = a;
        this.J = a;
        this.g = a;
        this.c = c;
    }
    
    public boolean E() {
        return this.ALLATORIxDEMO;
    }
    
    public boolean b() {
        return this.c.equalsIgnoreCase("Slider");
    }
    
    public ArrayList<String> ALLATORIxDEMO() {
        return this.g;
    }
    
    public boolean ALLATORIxDEMO() {
        return this.c.equalsIgnoreCase("Combo");
    }
    
    public H ALLATORIxDEMO() {
        return this.A;
    }
    
    public void ALLATORIxDEMO(final double a) {
        this.h = a;
    }
    
    public String ALLATORIxDEMO() {
        return this.J;
    }
}
