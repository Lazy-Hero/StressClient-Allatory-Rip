// 
// Decompiled by Procyon v0.5.36
// 

package l.p.t;

import net.minecraft.client.gui.Gui;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.GlStateManager;
import org.lwjgl.opengl.GL11;
import net.minecraft.util.ResourceLocation;

public class G
{
    public static void ALLATORIxDEMO(final int a, final int a, final int a, final int a, final ResourceLocation a) {
        GL11.glPushMatrix();
        GlStateManager.func_179147_l();
        GL11.glDisable(2929);
        GL11.glDepthMask(false);
        GL11.glBlendFunc(770, 771);
        final double n = 1.0;
        GL11.glColor3d(n, n, n);
        GL11.glDisable(3008);
        Minecraft.func_71410_x().field_71446_o.func_110577_a(a);
        final float n2 = 0.0f;
        Gui.func_146110_a(a, a, n2, n2, a, a, (float)a, (float)a);
        GL11.glDepthMask(true);
        GL11.glEnable(2929);
        GL11.glEnable(3008);
        final float n3 = 2.0f;
        GL11.glColor4f(n3, n3, n3, n3);
        GlStateManager.func_179084_k();
        GL11.glPopMatrix();
    }
}
