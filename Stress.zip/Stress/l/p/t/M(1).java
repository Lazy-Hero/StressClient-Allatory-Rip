// 
// Decompiled by Procyon v0.5.36
// 

package l.p.t;

import net.minecraft.entity.monster.EntityGolem;
import net.minecraft.entity.passive.EntityWaterMob;
import net.minecraft.entity.passive.EntityAmbientCreature;
import net.minecraft.entity.EntityAgeable;
import net.minecraft.util.math.Vec3d;
import net.minecraft.entity.Entity;

public class M
{
    public static Vec3d ALLATORIxDEMO(final Entity a, final float a) {
        return c.ALLATORIxDEMO(a.func_174791_d(), new Vec3d(a.field_70142_S, a.field_70137_T, a.field_70136_U), a);
    }
    
    public static boolean ALLATORIxDEMO(final Entity a) {
        return a instanceof EntityAgeable || a instanceof EntityAmbientCreature || a instanceof EntityWaterMob || a instanceof EntityGolem;
    }
}
