// 
// Decompiled by Procyon v0.5.36
// 

package l.p.t;

public class f
{
    private long ALLATORIxDEMO;
    
    public long ALLATORIxDEMO() {
        return System.nanoTime() / 1000000L;
    }
    
    public void ALLATORIxDEMO() {
        this.ALLATORIxDEMO = this.ALLATORIxDEMO();
    }
    
    public boolean ALLATORIxDEMO(final float a) {
        return this.ALLATORIxDEMO() - this.ALLATORIxDEMO >= a;
    }
    
    public void ALLATORIxDEMO(final long a) {
        this.ALLATORIxDEMO = a;
    }
    
    public boolean ALLATORIxDEMO(final long a) {
        return this.ALLATORIxDEMO() - this.ALLATORIxDEMO >= a;
    }
    
    public boolean ALLATORIxDEMO(final Float a) {
        return this.ALLATORIxDEMO() - this.ALLATORIxDEMO >= a;
    }
    
    public boolean ALLATORIxDEMO(final int a) {
        return this.ALLATORIxDEMO() - this.ALLATORIxDEMO >= a;
    }
    
    public long b() {
        return this.ALLATORIxDEMO;
    }
    
    public boolean ALLATORIxDEMO(final double a) {
        return this.ALLATORIxDEMO() - this.ALLATORIxDEMO >= a;
    }
    
    public long B() {
        return this.ALLATORIxDEMO() - this.ALLATORIxDEMO;
    }
}
