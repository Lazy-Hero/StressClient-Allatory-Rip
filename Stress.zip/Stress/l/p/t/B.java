// 
// Decompiled by Procyon v0.5.36
// 

package l.p.t;

import java.awt.Color;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.util.math.AxisAlignedBB;
import org.lwjgl.opengl.GL11;
import net.minecraft.util.math.BlockPos;

public class B
{
    public static void ALLATORIxDEMO(final BlockPos a, final float a, final float a, final float a) {
        GL11.glPushMatrix();
        GL11.glEnable(3042);
        GL11.glBlendFunc(770, 771);
        GL11.glEnable(2848);
        GL11.glLineWidth(1.0f);
        GL11.glDisable(3553);
        GL11.glEnable(2884);
        GL11.glDisable(2929);
        GL11.glDisable(2896);
        GL11.glTranslated(-H.ALLATORIxDEMO.ALLATORIxDEMO().func_175598_ae().field_78730_l, -H.ALLATORIxDEMO.ALLATORIxDEMO().func_175598_ae().field_78731_m, -H.ALLATORIxDEMO.ALLATORIxDEMO().func_175598_ae().field_78728_n);
        GL11.glColor4f(a, a, a, 0.3f);
        final AxisAlignedBB axisAlignedBB = new AxisAlignedBB(a);
        final float n = 1.0f;
        final AxisAlignedBB axisAlignedBB2 = axisAlignedBB;
        ALLATORIxDEMO(axisAlignedBB2);
        GL11.glColor4f(a, a, a, 1.0f);
        b(axisAlignedBB2);
        final float n2 = 0.2f;
        final float n3 = 1.0f;
        GL11.glColor4f(n, n2, n3, n3);
        GL11.glEnable(2896);
        GL11.glEnable(2929);
        GL11.glEnable(3553);
        GL11.glDisable(3042);
        GL11.glDisable(2848);
        GL11.glPopMatrix();
        GlStateManager.func_179117_G();
    }
    
    public static void ALLATORIxDEMO(final AxisAlignedBB a) {
        GL11.glBegin(7);
        GL11.glVertex3d(a.field_72340_a, a.field_72338_b, a.field_72339_c);
        GL11.glVertex3d(a.field_72336_d, a.field_72338_b, a.field_72339_c);
        GL11.glVertex3d(a.field_72336_d, a.field_72338_b, a.field_72334_f);
        GL11.glVertex3d(a.field_72340_a, a.field_72338_b, a.field_72334_f);
        GL11.glVertex3d(a.field_72340_a, a.field_72337_e, a.field_72339_c);
        GL11.glVertex3d(a.field_72340_a, a.field_72337_e, a.field_72334_f);
        GL11.glVertex3d(a.field_72336_d, a.field_72337_e, a.field_72334_f);
        GL11.glVertex3d(a.field_72336_d, a.field_72337_e, a.field_72339_c);
        GL11.glVertex3d(a.field_72340_a, a.field_72338_b, a.field_72339_c);
        GL11.glVertex3d(a.field_72340_a, a.field_72337_e, a.field_72339_c);
        GL11.glVertex3d(a.field_72336_d, a.field_72337_e, a.field_72339_c);
        GL11.glVertex3d(a.field_72336_d, a.field_72338_b, a.field_72339_c);
        GL11.glVertex3d(a.field_72336_d, a.field_72338_b, a.field_72339_c);
        GL11.glVertex3d(a.field_72336_d, a.field_72337_e, a.field_72339_c);
        GL11.glVertex3d(a.field_72336_d, a.field_72337_e, a.field_72334_f);
        GL11.glVertex3d(a.field_72336_d, a.field_72338_b, a.field_72334_f);
        GL11.glVertex3d(a.field_72340_a, a.field_72338_b, a.field_72334_f);
        GL11.glVertex3d(a.field_72336_d, a.field_72338_b, a.field_72334_f);
        GL11.glVertex3d(a.field_72336_d, a.field_72337_e, a.field_72334_f);
        GL11.glVertex3d(a.field_72340_a, a.field_72337_e, a.field_72334_f);
        GL11.glVertex3d(a.field_72340_a, a.field_72338_b, a.field_72339_c);
        GL11.glVertex3d(a.field_72340_a, a.field_72338_b, a.field_72334_f);
        GL11.glVertex3d(a.field_72340_a, a.field_72337_e, a.field_72334_f);
        GL11.glVertex3d(a.field_72340_a, a.field_72337_e, a.field_72339_c);
        GL11.glEnd();
    }
    
    public static void b(final AxisAlignedBB a) {
        GL11.glBegin(1);
        GL11.glVertex3d(a.field_72340_a, a.field_72338_b, a.field_72339_c);
        GL11.glVertex3d(a.field_72336_d, a.field_72338_b, a.field_72339_c);
        GL11.glVertex3d(a.field_72336_d, a.field_72338_b, a.field_72339_c);
        GL11.glVertex3d(a.field_72336_d, a.field_72338_b, a.field_72334_f);
        GL11.glVertex3d(a.field_72336_d, a.field_72338_b, a.field_72334_f);
        GL11.glVertex3d(a.field_72340_a, a.field_72338_b, a.field_72334_f);
        GL11.glVertex3d(a.field_72340_a, a.field_72338_b, a.field_72334_f);
        GL11.glVertex3d(a.field_72340_a, a.field_72338_b, a.field_72339_c);
        GL11.glVertex3d(a.field_72340_a, a.field_72338_b, a.field_72339_c);
        GL11.glVertex3d(a.field_72340_a, a.field_72337_e, a.field_72339_c);
        GL11.glVertex3d(a.field_72336_d, a.field_72338_b, a.field_72339_c);
        GL11.glVertex3d(a.field_72336_d, a.field_72337_e, a.field_72339_c);
        GL11.glVertex3d(a.field_72336_d, a.field_72338_b, a.field_72334_f);
        GL11.glVertex3d(a.field_72336_d, a.field_72337_e, a.field_72334_f);
        GL11.glVertex3d(a.field_72340_a, a.field_72338_b, a.field_72334_f);
        GL11.glVertex3d(a.field_72340_a, a.field_72337_e, a.field_72334_f);
        GL11.glVertex3d(a.field_72340_a, a.field_72337_e, a.field_72339_c);
        GL11.glVertex3d(a.field_72336_d, a.field_72337_e, a.field_72339_c);
        GL11.glVertex3d(a.field_72336_d, a.field_72337_e, a.field_72339_c);
        GL11.glVertex3d(a.field_72336_d, a.field_72337_e, a.field_72334_f);
        GL11.glVertex3d(a.field_72336_d, a.field_72337_e, a.field_72334_f);
        GL11.glVertex3d(a.field_72340_a, a.field_72337_e, a.field_72334_f);
        GL11.glVertex3d(a.field_72340_a, a.field_72337_e, a.field_72334_f);
        GL11.glVertex3d(a.field_72340_a, a.field_72337_e, a.field_72339_c);
        GL11.glEnd();
    }
    
    public static int ALLATORIxDEMO(final int a, final int a) {
        final float h = (System.currentTimeMillis() + a) % a / (float)a;
        final float n = 1.0f;
        return Color.getHSBColor(h, n, n).getRGB();
    }
}
