// 
// Decompiled by Procyon v0.5.36
// 

package l.p.t;

import net.minecraft.util.math.MathHelper;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.client.Minecraft;
import net.minecraft.entity.Entity;

public class i
{
    public static float[] ALLATORIxDEMO(final Entity a) {
        final double n = a.field_70165_t - Minecraft.func_71410_x().field_71439_g.field_70165_t;
        final double n2 = a.field_70161_v - Minecraft.func_71410_x().field_71439_g.field_70161_v;
        double n3;
        double n5;
        double n4;
        if (a instanceof EntityLivingBase) {
            final EntityLivingBase entityLivingBase = (EntityLivingBase)a;
            n3 = entityLivingBase.field_70163_u + entityLivingBase.func_70047_e() - (Minecraft.func_71410_x().field_71439_g.field_70163_u + Minecraft.func_71410_x().field_71439_g.func_70047_e());
            n4 = (n5 = n);
        }
        else {
            n3 = (a.func_174813_aQ().field_72338_b + a.func_174813_aQ().field_72337_e) / 2.0 - (Minecraft.func_71410_x().field_71439_g.field_70163_u + Minecraft.func_71410_x().field_71439_g.func_70047_e());
            n4 = (n5 = n);
        }
        final double n6 = n5 * n4;
        final double n7 = n2;
        return new float[] { (float)(MathHelper.func_181159_b(n2, n) * 57.29577951308232) - 90.0f, (float)(-(MathHelper.func_181159_b(n3, (double)MathHelper.func_76133_a(n6 + n7 * n7)) * 57.29577951308232)) };
    }
}
