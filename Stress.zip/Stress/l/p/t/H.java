// 
// Decompiled by Procyon v0.5.36
// 

package l.p.t;

import net.minecraft.client.multiplayer.PlayerControllerMP;
import net.minecraft.client.Minecraft;
import net.minecraft.entity.player.InventoryPlayer;
import net.minecraft.network.play.client.CPacketPlayer;
import net.minecraft.client.settings.GameSettings;
import net.minecraft.network.Packet;
import net.minecraft.network.play.client.CPacketAnimation;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.client.multiplayer.WorldClient;
import net.minecraft.client.entity.EntityPlayerSP;

public class H
{
    public static volatile H ALLATORIxDEMO;
    
    public EntityPlayerSP ALLATORIxDEMO() {
        return H.ALLATORIxDEMO.ALLATORIxDEMO().field_71439_g;
    }
    
    public WorldClient ALLATORIxDEMO() {
        return H.ALLATORIxDEMO.ALLATORIxDEMO().field_71441_e;
    }
    
    public FontRenderer ALLATORIxDEMO() {
        return H.ALLATORIxDEMO.ALLATORIxDEMO().field_71466_p;
    }
    
    public void ALLATORIxDEMO(final CPacketAnimation a) {
        this.ALLATORIxDEMO().field_71174_a.func_147297_a((Packet)a);
    }
    
    public GameSettings ALLATORIxDEMO() {
        return H.ALLATORIxDEMO.ALLATORIxDEMO().field_71474_y;
    }
    
    public void ALLATORIxDEMO(final CPacketPlayer a) {
    }
    
    static {
        H.ALLATORIxDEMO = new H();
    }
    
    public InventoryPlayer ALLATORIxDEMO() {
        return this.ALLATORIxDEMO().field_71071_by;
    }
    
    public Minecraft ALLATORIxDEMO() {
        return Minecraft.func_71410_x();
    }
    
    public PlayerControllerMP ALLATORIxDEMO() {
        return H.ALLATORIxDEMO.ALLATORIxDEMO().field_71442_b;
    }
}
