// 
// Decompiled by Procyon v0.5.36
// 

package l.p.t;

public class F<T>
{
    private String i;
    private T B;
    public T ALLATORIxDEMO;
    
    public String ALLATORIxDEMO() {
        return this.i;
    }
    
    public T ALLATORIxDEMO() {
        return this.ALLATORIxDEMO;
    }
    
    public void ALLATORIxDEMO(final T a) {
        this.ALLATORIxDEMO = a;
    }
    
    public T b() {
        return this.B;
    }
    
    public F(final String a, final T a) {
        this.i = a;
        this.B = a;
        this.ALLATORIxDEMO = a;
    }
}
