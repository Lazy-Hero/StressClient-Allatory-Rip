// 
// Decompiled by Procyon v0.5.36
// 

package l.p.t;

public class I
{
    private long ALLATORIxDEMO;
    private boolean i;
    
    public I() {
        final boolean i = true;
        final long allatorIxDEMO = 0L;
        this.ALLATORIxDEMO = allatorIxDEMO;
        this.i = i;
    }
    
    private /* synthetic */ long b() {
        return System.nanoTime() / 1000000L;
    }
    
    public void b() {
        this.i = true;
        this.ALLATORIxDEMO();
    }
    
    public boolean ALLATORIxDEMO() {
        return this.i;
    }
    
    public boolean ALLATORIxDEMO(final long a) {
        return !this.i && (System.nanoTime() / 1000000L - this.ALLATORIxDEMO >= a || a <= 0L);
    }
    
    public void B() {
        this.i = false;
        this.ALLATORIxDEMO();
    }
    
    public long ALLATORIxDEMO() {
        return this.b() - this.ALLATORIxDEMO;
    }
    
    public void ALLATORIxDEMO() {
        this.ALLATORIxDEMO = this.b();
    }
}
