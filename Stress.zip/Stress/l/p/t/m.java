// 
// Decompiled by Procyon v0.5.36
// 

package l.p.t;

import net.minecraft.init.Blocks;
import net.minecraft.block.Block;

public class m
{
    public static boolean ALLATORIxDEMO(final Block a) {
        return a != Blocks.field_150350_a && a != Blocks.field_185773_cZ && a != Blocks.field_150459_bM && a != Blocks.field_150330_I && a != Blocks.field_150398_cm && a != Blocks.field_150356_k && a != Blocks.field_150358_i && a != Blocks.field_150353_l && a != Blocks.field_150394_bc && a != Blocks.field_150388_bm && a != Blocks.field_150469_bN && a != Blocks.field_150393_bb && a != Blocks.field_150328_O && a != Blocks.field_150337_Q && a != Blocks.field_150429_aA && a != Blocks.field_150329_H && a != Blocks.field_150478_aa && a != Blocks.field_150437_az && a != Blocks.field_150327_N && a != Blocks.field_150395_bd && a != Blocks.field_150355_j && a != Blocks.field_150321_G && a != Blocks.field_150464_aj;
    }
}
