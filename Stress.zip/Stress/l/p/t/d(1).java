// 
// Decompiled by Procyon v0.5.36
// 

package l.p.t;

public class d extends F<Double>
{
    protected Double ALLATORIxDEMO;
    protected Double i;
    
    @Override
    public Double b() {
        return this.ALLATORIxDEMO;
    }
    
    public d(final String a, final Double a, final Double a, final Double a) {
        super(a, a);
        this.ALLATORIxDEMO = a;
        this.i = a;
    }
    
    @Override
    public Double ALLATORIxDEMO() {
        return this.i;
    }
}
