// 
// Decompiled by Procyon v0.5.36
// 

package l.p.t;

import net.minecraft.util.math.Vec3d;

public class c
{
    public static Vec3d ALLATORIxDEMO(final Vec3d a, final Vec3d a, final float a) {
        return a.func_178788_d(a).func_186678_a((double)a).func_178787_e(a);
    }
    
    public static float ALLATORIxDEMO(final float a, float a, final float a) {
        a = -(a - a) + (a - a) * a;
        return a + a;
    }
}
