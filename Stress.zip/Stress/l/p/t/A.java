// 
// Decompiled by Procyon v0.5.36
// 

package l.p.t;

public class A extends F<a>
{
    private String i;
    private a[] ALLATORIxDEMO;
    
    public A(final String a, final a... a) {
        super("+ " + a, null);
        this.i = a;
        this.ALLATORIxDEMO = a;
    }
    
    public a[] ALLATORIxDEMO() {
        return this.ALLATORIxDEMO;
    }
    
    public a ALLATORIxDEMO(final String a) {
        a a2 = null;
        final a[] allatorIxDEMO;
        final int length = (allatorIxDEMO = this.ALLATORIxDEMO).length;
        int n;
        int i = n = 0;
        int n2 = length;
        while (i < n2) {
            final a a3;
            if ((a3 = allatorIxDEMO[n]).ALLATORIxDEMO().equals(a)) {
                a2 = a3;
            }
            i = ++n;
            n2 = length;
        }
        return a2;
    }
    
    public String b() {
        return this.i;
    }
}
