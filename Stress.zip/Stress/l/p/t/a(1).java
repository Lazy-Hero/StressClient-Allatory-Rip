// 
// Decompiled by Procyon v0.5.36
// 

package l.p.t;

public class a
{
    private boolean i;
    private String ALLATORIxDEMO;
    
    public boolean ALLATORIxDEMO() {
        return this.i;
    }
    
    public a(final String a, final boolean a) {
        this.ALLATORIxDEMO = a;
        this.i = a;
    }
    
    public void ALLATORIxDEMO(final boolean a) {
        this.i = a;
    }
    
    public void ALLATORIxDEMO(final String a) {
        this.ALLATORIxDEMO = a;
    }
    
    public String ALLATORIxDEMO() {
        return this.ALLATORIxDEMO;
    }
}
