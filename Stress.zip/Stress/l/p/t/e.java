// 
// Decompiled by Procyon v0.5.36
// 

package l.p.t;

import net.minecraft.client.Minecraft;

public class e
{
    public static String E;
    public static String D;
    public static String G;
    public static String i;
    public static String j;
    public static String g;
    public static String c;
    public static String F;
    public static String J;
    public static String C;
    public static String B;
    public static String h;
    public static String ALLATORIxDEMO;
    public static String A;
    
    static {
        e.E = (ALLATORIxDEMO() ? "session" : "field_71449_j");
        e.G = (ALLATORIxDEMO() ? "yaw" : "field_149476_e");
        e.j = (ALLATORIxDEMO() ? "pitch" : "field_149473_f");
        e.J = (ALLATORIxDEMO() ? "rightClickDelayTimer" : "field_71467_ac");
        e.c = (ALLATORIxDEMO() ? "getPlayerInfo" : "func_175155_b");
        e.i = (ALLATORIxDEMO() ? "playerTextures" : "field_187107_a");
        e.g = (ALLATORIxDEMO() ? "currentGameType" : "field_78779_k");
        e.D = (ALLATORIxDEMO() ? "connection" : "field_78774_b");
        e.A = (ALLATORIxDEMO() ? "blockHitDelay" : "field_78781_i");
        e.h = (ALLATORIxDEMO() ? "isInWeb" : "field_70134_J");
        e.C = (ALLATORIxDEMO() ? "curBlockDamageMP" : "field_78770_f");
        e.F = (ALLATORIxDEMO() ? "isHittingBlock" : "field_78778_j");
        e.B = (ALLATORIxDEMO() ? "onUpdateWalkingPlayer" : "func_175161_p");
        e.ALLATORIxDEMO = (ALLATORIxDEMO() ? "fire" : "field_190534_ay");
    }
    
    public static boolean ALLATORIxDEMO() {
        try {
            return Minecraft.class.getDeclaredField("instance") != null;
        }
        catch (Exception ex) {
            return false;
        }
    }
}
