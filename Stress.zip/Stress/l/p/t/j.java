// 
// Decompiled by Procyon v0.5.36
// 

package l.p.t;

import net.minecraft.entity.passive.AbstractHorse;
import net.minecraft.entity.Entity;

public final class j
{
    public static double ALLATORIxDEMO(final Entity a, final Entity a) {
        return a.func_70068_e(a);
    }
    
    public static boolean ALLATORIxDEMO(final Entity a) {
        return a instanceof AbstractHorse && ((AbstractHorse)a).func_110248_bS();
    }
    
    public static float ALLATORIxDEMO(final Entity a, final Entity a) {
        return a.func_70032_d(a);
    }
    
    public static boolean b(final Entity a) {
        return a.field_70123_F;
    }
}
