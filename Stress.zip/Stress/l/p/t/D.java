// 
// Decompiled by Procyon v0.5.36
// 

package l.p.t;

import com.mojang.authlib.GameProfile;
import net.minecraft.world.World;
import net.minecraft.entity.MoverType;
import net.minecraft.util.MovementInput;
import net.minecraft.client.entity.EntityOtherPlayerMP;

public class D extends EntityOtherPlayerMP
{
    private static MovementInput ALLATORIxDEMO;
    
    static {
        D.ALLATORIxDEMO = null;
    }
    
    public void func_70636_d() {
        final boolean field_70145_X = false;
        final double n = 0.0;
        final double field_70159_w = 0.0;
        final boolean field_70145_X2 = true;
        super.func_70636_d();
        this.field_70145_X = field_70145_X2;
        this.field_70159_w = field_70159_w;
        this.field_70181_x = n;
        this.field_70179_y = n;
        this.field_70145_X = field_70145_X;
    }
    
    public void func_70091_d(final MoverType a, final double a, final double a, final double a) {
        final boolean field_70122_E = true;
        this.field_70122_E = true;
        super.func_70091_d(a, a, a, a);
        this.field_70122_E = field_70122_E;
    }
    
    public boolean func_70093_af() {
        return false;
    }
    
    public D(final World a, final GameProfile a) {
        super(a, a);
    }
    
    public void setMovementInput(final MovementInput a) {
        D.ALLATORIxDEMO = a;
        if (a.field_78901_c && this.field_70122_E) {
            super.func_70664_aZ();
        }
        super.func_191958_b(a.field_78902_a, this.field_70701_bs, a.field_192832_b, this.field_70764_aw);
    }
}
