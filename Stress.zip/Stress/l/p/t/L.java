// 
// Decompiled by Procyon v0.5.36
// 

package l.p.t;

public class L
{
    private long ALLATORIxDEMO;
    private long i;
    
    public boolean ALLATORIxDEMO(final long a) {
        return System.currentTimeMillis() - this.ALLATORIxDEMO >= a;
    }
    
    public void ALLATORIxDEMO(final long a) {
        this.ALLATORIxDEMO = a;
    }
    
    public boolean ALLATORIxDEMO(final float a) {
        return this.ALLATORIxDEMO() - this.i >= a;
    }
    
    public long ALLATORIxDEMO() {
        return System.nanoTime() / 1000000L;
    }
    
    public void ALLATORIxDEMO() {
        this.ALLATORIxDEMO = System.currentTimeMillis();
    }
    
    public long b() {
        return System.nanoTime() / 1000000L;
    }
    
    public boolean b(final float a) {
        return this.b() - this.ALLATORIxDEMO >= a;
    }
    
    public void b() {
        this.ALLATORIxDEMO = this.b();
    }
    
    public L() {
        final long i = 0L;
        final long allatorIxDEMO = 0L;
        this.ALLATORIxDEMO = allatorIxDEMO;
        this.i = i;
    }
    
    public int ALLATORIxDEMO(final int a) {
        return 1000 / a;
    }
}
